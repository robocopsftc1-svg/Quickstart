package org.firstinspires.ftc.teamcode.mechanisms.turret;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.CRServoImplEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;

import java.util.List;

public class TurretTracker
{
    public enum State
    {
        MANUAL,
        TRACKING,
        SEARCHING,
        POSE_AIM,
        NO_TAG
    }

    public interface PoseSource
    {
        double[] pose();
    }

    public static final int APRIL_TAG_PIPELINE = 0;

    public static final DcMotorSimple.Direction LEFT_SERVO_DIRECTION = DcMotorSimple.Direction.FORWARD;
    public static final DcMotorSimple.Direction RIGHT_SERVO_DIRECTION = DcMotorSimple.Direction.FORWARD;

    public static final boolean LEFT_SERVO_ENABLED = false;
    public static final boolean RIGHT_SERVO_ENABLED = true;

    public static final double SERVO_FULL_RANGE_DEG = 350.0;
    public static final double SERVO_PULSE_MIN_US = 500.0;
    public static final double SERVO_PULSE_MAX_US = 2500.0;
    public static final double SERVO_GEAR_TEETH = 48.0;
    public static final double TURRET_GEAR_TEETH = 96.0;
    public static final double MAX_RATE_DEG_PER_S = 450.0;

    public static final int[] RED_TAG_IDS = {30, 31, 32, 33, 34, 35, 36, 37};
    public static final int[] BLUE_TAG_IDS = {38, 39, 40, 41, 42, 43, 44, 45};
    public static final double MAX_STALENESS_MS = 150.0;
    public static final double AIM_OFFSET_DEG = 0.0;

    private static final double DERIVATIVE_MIN_DT_S = 0.02;

    public static final double SEARCH_POWER = 0.15;
    public static final double SEARCH_MAX_S = 1.5;
    public static final double SEARCH_MIN_ERROR_DEG = 2.0;

    public static final double LOCK_TOLERANCE_DEG = 1.5;

    // True if the Limelight is mounted on the turret and turns with it (the tag error then goes to
    // zero when the turret is aimed). Set false if the Limelight is fixed to the robot body; the turret
    // angle is then set directly from where the tag is seen.
    public static final boolean LIMELIGHT_ON_TURRET = true;

    // Distance to the hive from how high the tag appears in the Limelight image. Measure CAMERA_HEIGHT_IN from
    // the floor to the middle of the Limelight lens, and CAMERA_PITCH_DEG as how far the lens points above
    // level. TAG_HEIGHT_IN is the middle of the hive tags (1.075 m). Check it in Turret Tracking Test.
    public static final boolean USE_LIMELIGHT_DISTANCE = true;
    public static final double TAG_HEIGHT_IN = 42.3;
    public static final double CAMERA_HEIGHT_IN = 12.0;
    public static final double CAMERA_PITCH_DEG = 20.0;
    public static final double DISTANCE_FILTER = 0.3;
    public static final double MAX_DISTANCE_DISAGREE_IN = 30.0;

    // While the robot drives or turns, the turret turns the opposite way by the same angle so the tag stays
    // in view. 1.0 is full help, 0.0 turns it off. Heading jumps bigger than the limit (like a corner fix) are ignored.
    public static final double HEADING_FEEDFORWARD = 1.0;
    public static final double MAX_HEADING_JUMP_DEG = 30.0;

    public static final double HIVE_X_IN = 72.0;
    public static final double HIVE_Y_IN = 72.0;
    public static final double HIVE_FRAME_WIDTH_IN = 49.46;
    public static final double HIVE_CELL_SPACING_IN = 18.8;
    public static final double RED_HIVE_X_IN = HIVE_X_IN - HIVE_FRAME_WIDTH_IN / 4.0;
    public static final double TURRET_CENTER_OFFSET_DEG = 0.0;
    public static final double POSE_AIM_DELAY_S = 0.3;
    public static final double POSE_LOCK_TOLERANCE_DEG = 2.0;
    public static final double POSE_SETTLE_S = 0.25;

    private static final double TURRET_DEG_PER_SERVO_DEG = SERVO_GEAR_TEETH / TURRET_GEAR_TEETH;
    public static final double TURRET_HALF_RANGE_DEG = SERVO_FULL_RANGE_DEG / 2.0 * TURRET_DEG_PER_SERVO_DEG;
    public static final double LIMIT_MARGIN_DEG = 3.0;
    private static final double LIMIT_MAX_DT_S = 0.1;
    private static final double OUTPUT_WRITE_EPSILON = 0.0005;

    public double kP = 0.035;
    public double kD = 0.0008;
    public double minPower = 0.04;
    public double maxPower = 1.0;
    public double deadbandDeg = 0.4;
    public boolean invert = true;
    public boolean limitsEnabled = true;

    private final CRServo leftServo;
    private final CRServo rightServo;
    private Limelight3A limelight;

    private final ElapsedTime derivativeTimer = new ElapsedTime();
    private final ElapsedTime lostTimer = new ElapsedTime();
    private final ElapsedTime limitTimer = new ElapsedTime();
    private final ElapsedTime poseSettleTimer = new ElapsedTime();
    private PoseSource poseSource = null;
    private double poseError = 0.0;
    private double targetAngleDeg = 0.0;
    private double lastLeftOutput = Double.NaN;
    private double lastRightOutput = Double.NaN;
    private boolean atLimit = false;
    private boolean bothForced = false;
    private int[] allowedIds = new int[0];
    private State state = State.NO_TAG;
    private boolean hadTargetLastLoop = false;
    private boolean blueAlliance = false;
    private boolean hiveFlipped = false;
    private double lastSide = 0.0;
    private boolean hasLastError = false;
    private double lastError = 0.0;
    private double derivative = 0.0;
    private double directError = 0.0;
    private double limelightDistanceIn = -1.0;
    private boolean hasLastHeading = false;
    private double lastHeadingRad = 0.0;

    private boolean hasTarget = false;
    private int targetId = -1;
    private double error = 0.0;
    private double commandedPower = 0.0;

    public TurretTracker(HardwareMap hardwareMap)
    {
        leftServo = hardwareMap.get(CRServo.class, HardwareNames.TURRET_LEFT);
        rightServo = hardwareMap.get(CRServo.class, HardwareNames.TURRET_RIGHT);
        leftServo.setDirection(LEFT_SERVO_DIRECTION);
        rightServo.setDirection(RIGHT_SERVO_DIRECTION);
        configurePulseRange(leftServo);
        configurePulseRange(rightServo);
        applyEnabledServos();

        limelight = null;
        try
        {
            limelight = hardwareMap.get(Limelight3A.class, HardwareNames.LIMELIGHT);
            limelight.setPollRateHz(100);
            limelight.pipelineSwitch(APRIL_TAG_PIPELINE);
        }
        catch (Exception e)
        {
            limelight = null;
        }
    }

    public boolean hasLimelight()
    {
        return limelight != null;
    }

    private void configurePulseRange(CRServo servo)
    {
        if (servo instanceof CRServoImplEx)
        {
            ((CRServoImplEx) servo).setPwmRange(new PwmControl.PwmRange(SERVO_PULSE_MIN_US, SERVO_PULSE_MAX_US));
        }
    }

    private void applyEnabledServos()
    {
        setServoEnabled(leftServo, LEFT_SERVO_ENABLED);
        setServoEnabled(rightServo, RIGHT_SERVO_ENABLED);
    }

    private void setServoEnabled(CRServo servo, boolean enabled)
    {
        if (!(servo instanceof CRServoImplEx))
        {
            if (!enabled)
            {
                servo.setPower(0.0);
            }
            return;
        }
        CRServoImplEx ex = (CRServoImplEx) servo;
        if (enabled)
        {
            ex.setPwmEnable();
        }
        else
        {
            ex.setPwmDisable();
        }
    }

    private void enableBothServos()
    {
        setServoEnabled(leftServo, true);
        setServoEnabled(rightServo, true);
    }

    public void start()
    {
        applyEnabledServos();
        if (limelight != null)
        {
            limelight.start();
        }
        state = State.NO_TAG;
        hadTargetLastLoop = false;
        lastSide = 0.0;
        targetAngleDeg = 0.0;
        lastLeftOutput = Double.NaN;
        lastRightOutput = Double.NaN;
        limitTimer.reset();
        setPower(0.0);
    }

    public void stop()
    {
        setPower(0.0);
        if (limelight != null)
        {
            limelight.stop();
        }
        state = State.NO_TAG;
    }

    public State getState()
    {
        return state;
    }

    public void setHiveFlipped(boolean flipped)
    {
        hiveFlipped = flipped;
    }

    public void toggleHiveFlipped()
    {
        hiveFlipped = !hiveFlipped;
    }

    public boolean isHiveFlipped()
    {
        return hiveFlipped;
    }

    public double getHiveX()
    {
        if (blueAlliance)
        {
            return 2.0 * HIVE_X_IN - RED_HIVE_X_IN;
        }
        return RED_HIVE_X_IN;
    }

    public double getHiveY()
    {
        double redY = HIVE_Y_IN - HIVE_CELL_SPACING_IN / 2.0;
        if (hiveFlipped)
        {
            redY = HIVE_Y_IN + HIVE_CELL_SPACING_IN / 2.0;
        }
        if (blueAlliance)
        {
            return 2.0 * HIVE_Y_IN - redY;
        }
        return redY;
    }

    public void setAlliance(boolean blue)
    {
        blueAlliance = blue;
        if (blue)
        {
            allowedIds = BLUE_TAG_IDS;
        }
        else
        {
            allowedIds = RED_TAG_IDS;
        }
    }

    public void clearAlliance()
    {
        allowedIds = new int[0];
    }

    public boolean isAiming()
    {
        return state == State.TRACKING || state == State.SEARCHING || state == State.POSE_AIM;
    }

    public boolean isLockedOn()
    {
        if (state == State.POSE_AIM)
        {
            return Math.abs(poseError) <= POSE_LOCK_TOLERANCE_DEG && poseSettleTimer.seconds() >= POSE_SETTLE_S;
        }
        if (state == State.TRACKING && !LIMELIGHT_ON_TURRET)
        {
            return Math.abs(directError) <= LOCK_TOLERANCE_DEG;
        }
        return state == State.TRACKING && Math.abs(error) <= LOCK_TOLERANCE_DEG;
    }

    public void setPoseSource(PoseSource source)
    {
        poseSource = source;
    }

    public boolean hasPoseSource()
    {
        return poseSource != null;
    }

    public double getPoseError()
    {
        return poseError;
    }

    public double getPoseAimAngle(double x, double y, double headingRad)
    {
        double bearing = Math.atan2(getHiveY() - y, getHiveX() - x);
        double relativeDeg = Math.toDegrees(bearing - headingRad);
        double angle = TURRET_CENTER_OFFSET_DEG - relativeDeg;
        while (angle > 180.0)
        {
            angle -= 360.0;
        }
        while (angle <= -180.0)
        {
            angle += 360.0;
        }
        return angle;
    }

    public boolean aimAtPose(double x, double y, double headingRad)
    {
        double desired = getPoseAimAngle(x, y, headingRad);
        if (Math.abs(desired) > getUpperLimit())
        {
            return false;
        }
        leaveForcedMode();
        double dt = Math.min(limitTimer.seconds(), LIMIT_MAX_DT_S);
        limitTimer.reset();
        double maxStep = MAX_RATE_DEG_PER_S * dt;
        double step = Math.max(-maxStep, Math.min(maxStep, desired - targetAngleDeg));
        commandAngle(targetAngleDeg + step, 0.0);
        poseError = desired - targetAngleDeg;
        if (Math.abs(poseError) > POSE_LOCK_TOLERANCE_DEG)
        {
            poseSettleTimer.reset();
        }
        return true;
    }

    public void setTargetAngle(double angleDeg)
    {
        leaveForcedMode();
        limitTimer.reset();
        commandAngle(angleDeg, 0.0);
    }

    public void manual(double power)
    {
        state = State.MANUAL;
        hadTargetLastLoop = false;
        lastSide = 0.0;
        hasLastError = false;
        setPower(power);
    }

    public boolean hasTarget()
    {
        return hasTarget;
    }

    public int getTargetId()
    {
        return targetId;
    }

    public double getError()
    {
        return error;
    }

    public double getCommandedPower()
    {
        return commandedPower;
    }

    public boolean limitsActive()
    {
        return limitsEnabled;
    }

    public double getUpperLimit()
    {
        if (limitsEnabled)
        {
            return TURRET_HALF_RANGE_DEG - LIMIT_MARGIN_DEG;
        }
        return TURRET_HALF_RANGE_DEG;
    }

    public double getLowerLimit()
    {
        return -getUpperLimit();
    }

    public double getPositionDegrees()
    {
        return targetAngleDeg;
    }

    public double getPositionEstimate()
    {
        return targetAngleDeg;
    }

    public void zeroPositionEstimate()
    {
        targetAngleDeg = 0.0;
    }

    public boolean isAtLimit()
    {
        return atLimit;
    }

    private void leaveForcedMode()
    {
        if (bothForced)
        {
            bothForced = false;
            applyEnabledServos();
            lastLeftOutput = Double.NaN;
            lastRightOutput = Double.NaN;
        }
    }

    public void setPower(double power)
    {
        leaveForcedMode();
        double dt = Math.min(limitTimer.seconds(), LIMIT_MAX_DT_S);
        limitTimer.reset();
        commandAngle(targetAngleDeg + power * MAX_RATE_DEG_PER_S * dt, power);
    }

    private void commandAngle(double angle, double power)
    {
        double next = angle;
        double upper = getUpperLimit();
        double lower = getLowerLimit();
        atLimit = false;
        if (next > upper)
        {
            next = upper;
            atLimit = power > 0.0;
        }
        else if (next < lower)
        {
            next = lower;
            atLimit = power < 0.0;
        }
        targetAngleDeg = next;
        commandedPower = power;

        double servoDeg = targetAngleDeg / TURRET_DEG_PER_SERVO_DEG;
        double command = servoDeg / (SERVO_FULL_RANGE_DEG / 2.0);
        command = Math.max(-1.0, Math.min(1.0, command));
        double output = invert ? -command : command;

        if (LEFT_SERVO_ENABLED && !(Math.abs(output - lastLeftOutput) <= OUTPUT_WRITE_EPSILON))
        {
            leftServo.setPower(output);
            lastLeftOutput = output;
        }
        if (RIGHT_SERVO_ENABLED && !(Math.abs(output - lastRightOutput) <= OUTPUT_WRITE_EPSILON))
        {
            rightServo.setPower(output);
            lastRightOutput = output;
        }
    }

    public void setServoPowers(double left, double right)
    {
        limitTimer.reset();
        enableBothServos();
        bothForced = true;
        commandedPower = Math.max(Math.abs(left), Math.abs(right));
        leftServo.setPower(left);
        rightServo.setPower(right);
    }

    public void track()
    {
        hasTarget = false;
        targetId = -1;
        LLResultTypes.FiducialResult bestTag = null;
        double headingStepDeg = nextHeadingStepDeg();

        LLResult result = null;
        if (limelight != null)
        {
            result = limelight.getLatestResult();
        }
        if (result != null && result.isValid() && result.getStaleness() < MAX_STALENESS_MS)
        {
            List<LLResultTypes.FiducialResult> tags = result.getFiducialResults();
            double best = 0.0;
            for (LLResultTypes.FiducialResult tag : tags)
            {
                if (!isAllowed(tag.getFiducialId()))
                {
                    continue;
                }
                double tagError = tag.getTargetXDegrees() - AIM_OFFSET_DEG;
                if (!hasTarget || Math.abs(tagError) < Math.abs(best))
                {
                    hasTarget = true;
                    best = tagError;
                    targetId = tag.getFiducialId();
                    bestTag = tag;
                }
            }
            error = best;
        }
        updateLimelightDistance(bestTag);

        if (!hasTarget)
        {
            hasLastError = false;
            derivative = 0.0;
            if (hadTargetLastLoop)
            {
                hadTargetLastLoop = false;
                lostTimer.reset();
            }
            if (lostTimer.seconds() >= POSE_AIM_DELAY_S && tryPoseAim())
            {
                state = State.POSE_AIM;
                return;
            }
            if (lastSide != 0.0 && lostTimer.seconds() < SEARCH_MAX_S)
            {
                state = State.SEARCHING;
                setPower(lastSide * SEARCH_POWER);
            }
            else
            {
                state = State.NO_TAG;
                setPower(0.0);
            }
            return;
        }

        state = State.TRACKING;
        hadTargetLastLoop = true;
        if (Math.abs(error) >= SEARCH_MIN_ERROR_DEG)
        {
            lastSide = Math.signum(error);
        }

        if (!hasLastError)
        {
            hasLastError = true;
            lastError = error;
            derivative = 0.0;
            derivativeTimer.reset();
        }
        else if (derivativeTimer.seconds() >= DERIVATIVE_MIN_DT_S)
        {
            derivative = (error - lastError) / derivativeTimer.seconds();
            lastError = error;
            derivativeTimer.reset();
        }

        if (!LIMELIGHT_ON_TURRET)
        {
            aimDirect(TURRET_CENTER_OFFSET_DEG + error);
            return;
        }

        if (Math.abs(error) <= deadbandDeg)
        {
            setPower(0.0);
            applyHeadingStep(headingStepDeg);
            return;
        }

        double power = kP * error + kD * derivative;
        power = Math.max(-maxPower, Math.min(maxPower, power));
        if (Math.abs(power) < minPower)
        {
            power = Math.signum(error) * minPower;
        }
        setPower(power);
        applyHeadingStep(headingStepDeg);
    }

    // For a Limelight fixed to the robot body: the turret angle is the tag angle itself, moved at a limited rate.
    private void aimDirect(double desired)
    {
        leaveForcedMode();
        double dt = Math.min(limitTimer.seconds(), LIMIT_MAX_DT_S);
        limitTimer.reset();
        double maxStep = MAX_RATE_DEG_PER_S * dt;
        double step = Math.max(-maxStep, Math.min(maxStep, desired - targetAngleDeg));
        commandAngle(targetAngleDeg + step, Math.signum(step));
        directError = desired - targetAngleDeg;
    }

    // Change in robot heading since the last loop, scaled. Zero if the pose is not available or jumped.
    private double nextHeadingStepDeg()
    {
        if (poseSource == null || HEADING_FEEDFORWARD == 0.0)
        {
            hasLastHeading = false;
            return 0.0;
        }
        double[] pose = poseSource.pose();
        if (pose == null || pose.length < 3)
        {
            hasLastHeading = false;
            return 0.0;
        }
        double heading = pose[2];
        double step = 0.0;
        if (hasLastHeading)
        {
            double deltaDeg = Math.toDegrees(heading - lastHeadingRad);
            while (deltaDeg > 180.0)
            {
                deltaDeg -= 360.0;
            }
            while (deltaDeg <= -180.0)
            {
                deltaDeg += 360.0;
            }
            if (Math.abs(deltaDeg) <= MAX_HEADING_JUMP_DEG)
            {
                step = HEADING_FEEDFORWARD * deltaDeg;
            }
        }
        lastHeadingRad = heading;
        hasLastHeading = true;
        return step;
    }

    private void applyHeadingStep(double stepDeg)
    {
        if (stepDeg != 0.0)
        {
            commandAngle(targetAngleDeg + stepDeg, commandedPower);
        }
    }

    private void updateLimelightDistance(LLResultTypes.FiducialResult tag)
    {
        if (tag == null)
        {
            limelightDistanceIn = -1.0;
            return;
        }
        double angleDeg = CAMERA_PITCH_DEG + tag.getTargetYDegrees();
        double rise = TAG_HEIGHT_IN - CAMERA_HEIGHT_IN;
        if (angleDeg < 1.0 || angleDeg > 85.0 || rise <= 0.0)
        {
            limelightDistanceIn = -1.0;
            return;
        }
        double flat = rise / Math.tan(Math.toRadians(angleDeg));
        if (limelightDistanceIn <= 0.0)
        {
            limelightDistanceIn = flat;
        }
        else
        {
            limelightDistanceIn += DISTANCE_FILTER * (flat - limelightDistanceIn);
        }
    }

    public double getLimelightDistance()
    {
        return limelightDistanceIn;
    }

    public double getPoseDistance()
    {
        if (poseSource == null)
        {
            return -1.0;
        }
        double[] pose = poseSource.pose();
        if (pose == null || pose.length < 3)
        {
            return -1.0;
        }
        return Math.hypot(getHiveX() - pose[0], getHiveY() - pose[1]);
    }

    // Distance to the hive in inches. Uses the Limelight tag when one is seen (it does not drift),
    // otherwise the Pinpoint position. Returns -1 if neither is available.
    public double getHiveDistance()
    {
        double fromPose = getPoseDistance();
        if (USE_LIMELIGHT_DISTANCE && hasTarget && limelightDistanceIn > 0.0)
        {
            if (fromPose < 0.0 || Math.abs(limelightDistanceIn - fromPose) <= MAX_DISTANCE_DISAGREE_IN)
            {
                return limelightDistanceIn;
            }
        }
        return fromPose;
    }

    private boolean tryPoseAim()
    {
        if (poseSource == null)
        {
            return false;
        }
        double[] pose = poseSource.pose();
        if (pose == null || pose.length < 3)
        {
            return false;
        }
        return aimAtPose(pose[0], pose[1], pose[2]);
    }

    private boolean isAllowed(int id)
    {
        if (allowedIds.length == 0)
        {
            return true;
        }
        for (int allowed : allowedIds)
        {
            if (allowed == id)
            {
                return true;
            }
        }
        return false;
    }
}
