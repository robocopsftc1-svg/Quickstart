package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;

@TeleOp(name = "Counter Roller PIDF Tuner", group = "Tuning")
public class CounterRollerPidfTuner extends RollerPidfTunerBase
{
    @Override
    protected String rollerName()
    {
        return "Counter roller";
    }

    @Override
    protected String fileName()
    {
        return "Shooter.java";
    }

    @Override
    protected String constantPrefix()
    {
        return "COUNTER";
    }

    @Override
    protected double rampTimeS()
    {
        return 0.0;
    }

    @Override
    protected Gains startingGains()
    {
        return new Gains(Shooter.COUNTER_KS, Shooter.COUNTER_MAX_TICKS_PER_SEC, Shooter.COUNTER_KP, Shooter.COUNTER_KD);
    }

    @Override
    protected Roller createRoller()
    {
        final Shooter shooter;
        try
        {
            shooter = new Shooter(hardwareMap);
        }
        catch (Exception e)
        {
            return null;
        }
        return new Roller()
        {
            @Override
            public void raw(double power)
            {
                shooter.setCounterRawPower(power);
            }

            @Override
            public double velocity()
            {
                return shooter.getCounterVelocityTicksPerSec();
            }

            @Override
            public boolean present()
            {
                return shooter.hasCounterRoller();
            }
        };
    }
}
