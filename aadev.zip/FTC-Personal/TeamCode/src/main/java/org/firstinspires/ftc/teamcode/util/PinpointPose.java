package org.firstinspires.ftc.teamcode.util;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;

public class PinpointPose implements TurretTracker.PoseSource
{
    public static final double UPDATE_PERIOD_S = 0.05;

    private final GoBildaPinpointDriver pinpoint;
    private final double[] pose = new double[3];
    private final ElapsedTime timer = new ElapsedTime();
    private boolean hasRead = false;
    private boolean valid = false;

    public PinpointPose(HardwareMap hardwareMap)
    {
        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, HardwareNames.PINPOINT);
    }

    public void setValid(boolean isValid)
    {
        valid = isValid;
    }

    public void setPose(double xIn, double yIn, double headingRad)
    {
        pinpoint.setPosition(new Pose2D(DistanceUnit.INCH, xIn, yIn, AngleUnit.RADIANS, headingRad));
        pose[0] = xIn;
        pose[1] = yIn;
        pose[2] = headingRad;
        hasRead = false;
        valid = true;
    }

    public boolean isValid()
    {
        return valid;
    }

    @Override
    public double[] pose()
    {
        if (!valid)
        {
            return null;
        }
        if (!hasRead || timer.seconds() >= UPDATE_PERIOD_S)
        {
            hasRead = true;
            timer.reset();
            pinpoint.update();
            pose[0] = pinpoint.getPosX(DistanceUnit.INCH);
            pose[1] = pinpoint.getPosY(DistanceUnit.INCH);
            pose[2] = pinpoint.getHeading(AngleUnit.RADIANS);
        }
        return pose;
    }
}
