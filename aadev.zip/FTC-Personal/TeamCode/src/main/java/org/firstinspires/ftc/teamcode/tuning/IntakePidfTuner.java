package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;

@TeleOp(name = "Intake PIDF Tuner", group = "Tuning")
public class IntakePidfTuner extends RollerPidfTunerBase
{
    @Override
    protected String rollerName()
    {
        return "Intake";
    }

    @Override
    protected String fileName()
    {
        return "Intake.java";
    }

    @Override
    protected String constantPrefix()
    {
        return "INTAKE";
    }

    @Override
    protected double rampTimeS()
    {
        return Intake.RAMP_TIME_S;
    }

    @Override
    protected Gains startingGains()
    {
        return new Gains(Intake.INTAKE_KS, Intake.INTAKE_MAX_TICKS_PER_SEC, Intake.INTAKE_KP, Intake.INTAKE_KD);
    }

    @Override
    protected Roller createRoller()
    {
        final Intake intake;
        try
        {
            intake = new Intake(hardwareMap);
        }
        catch (Exception e)
        {
            return null;
        }
        return new Roller()
        {
            @Override
            public void raw(double power)
            {
                intake.setPowers(power, power);
            }

            @Override
            public double velocity()
            {
                return intake.getInnerVelocityTicksPerSec();
            }

            @Override
            public boolean present()
            {
                return true;
            }
        };
    }
}
