package org.firstinspires.ftc.teamcode.mechanisms.shooter;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.util.VelocityController;

public class Shooter
{
    public enum State
    {
        OFF,
        SPINNING_UP,
        HOLDING
    }

    public static final double SPINUP_EXIT_FRACTION = 0.9;
    public static final double SHOOTER_SPEED_FRACTION = 0.41;
    public static final double[] SHOT_DISTANCES_IN = {60.0, 100.0};
    public static final double[] SHOT_FRACTIONS = {0.55, 0.55};
    public static final double MAX_SPEED_FRACTION = 0.95;
    public static final double COUNTER_ROLLER_POWER = 0.80;
    public static final double COUNTER_KS = 0.1;
    public static final double COUNTER_MAX_TICKS_PER_SEC = 0.0;
    public static final double COUNTER_KP = 0.002;
    public static final double COUNTER_KD = 0.0;
    public static final double TICKS_PER_REV = 28.0;

    // Battery voltage compensation: the feedforward is scaled by NOMINAL_BATTERY_V / battery voltage,
    // so the same target speed needs the same power as the battery drains. Set NOMINAL_BATTERY_V to the
    // Battery reading that was shown on the phone while running the kS/kV tuner.
    public static final boolean USE_VOLTAGE_COMP = true;
    public static final double NOMINAL_BATTERY_V = 13.2;
    public static final double BATTERY_FILTER_S = 1.0;
    public static final double BATTERY_READ_PERIOD_S = 0.1;
    public static final double BATTERY_SCALE_MIN = 0.85;
    public static final double BATTERY_SCALE_MAX = 1.2;
    public static final double BATTERY_UPDATE_BAND = 0.05;

    public static final double FEEDFORWARD_KS = 0.132;
    public static final double MAX_TICKS_PER_SEC = 2437.0;
    public static final double FEEDBACK_KP = 0.0026;
    public static final double FEEDBACK_KD = 0.0;

    private static final double ENCODER_CHECK_S = 0.8;
    private static final double ENCODER_MIN_TICKS_PER_SEC = 0.8;
    private static final double VELOCITY_FILTER = 0.3;
    private static final double MIN_CONTROL_DT_S = 0.005;
    private static final double MAX_CONTROL_DT_S = 0.1;

    private static final DcMotorSimple.Direction SHOOTER_DRIVER_DIRECTION = DcMotorSimple.Direction.FORWARD;
    private static final DcMotorSimple.Direction COUNTER_ROLLER_DIRECTION = DcMotorSimple.Direction.FORWARD;

    private DcMotor shooterDriver;
    private DcMotorEx shooterEx;
    private DcMotor counterRoller;
    private DcMotorEx counterEx = null;
    private final VelocityController counterController = new VelocityController(COUNTER_KS, COUNTER_MAX_TICKS_PER_SEC, COUNTER_KP, COUNTER_KD);
    private final ElapsedTime counterClock = new ElapsedTime();
    private double counterLowSpeedS = 0.0;
    private boolean counterEncoderFailed = false;
    private ElapsedTime spinTimer = new ElapsedTime();
    private ElapsedTime controlTimer = new ElapsedTime();
    private boolean spinning = false;
    private State state = State.OFF;
    private boolean speedControl = true;
    private boolean controlStarted = false;
    private double maxTicksPerSec = MAX_TICKS_PER_SEC;
    private double targetFraction = SHOOTER_SPEED_FRACTION;
    private double counterPower = COUNTER_ROLLER_POWER;
    private double feedbackKp = FEEDBACK_KP;
    private double feedbackKd = FEEDBACK_KD;
    private double filteredVelocity = 0.0;
    private VoltageSensor batterySensor = null;
    private ElapsedTime batteryTimer = new ElapsedTime();
    private double batteryFiltered = 0.0;
    private double lastShooterPower = Double.NaN;
    private double lastCounterPower = Double.NaN;

    public Shooter(HardwareMap hardwareMap)
    {
        try
        {
            batterySensor = hardwareMap.voltageSensor.iterator().next();
            double resting = batterySensor.getVoltage();
            if (resting > 1.0)
            {
                batteryFiltered = resting;
            }
        }
        catch (Exception e)
        {
            batterySensor = null;
        }

        shooterDriver = hardwareMap.get(DcMotor.class, HardwareNames.SHOOTER_DRIVER);
        shooterDriver.setDirection(SHOOTER_DRIVER_DIRECTION);
        shooterDriver.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        if (shooterDriver instanceof DcMotorEx)
        {
            shooterEx = (DcMotorEx) shooterDriver;
        }
        else
        {
            shooterEx = null;
        }

        counterRoller = null;
        try
        {
            counterRoller = hardwareMap.get(DcMotor.class, HardwareNames.SHOOTER_COUNTER);
            counterRoller.setDirection(COUNTER_ROLLER_DIRECTION);
            counterRoller.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            counterRoller.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            if (counterRoller instanceof DcMotorEx)
            {
                counterEx = (DcMotorEx) counterRoller;
            }
        }
        catch (Exception e)
        {
            counterRoller = null;
        }
    }

    public boolean hasCounterRoller()
    {
        return counterRoller != null;
    }

    public void shoot()
    {
        if (!spinning)
        {
            spinning = true;
            state = State.SPINNING_UP;
            controlStarted = false;
            spinTimer.reset();
            controlTimer.reset();
            filteredVelocity = getVelocityTicksPerSec();
            shooterDriver.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        driveAtTarget();
        driveCounter();
    }

    public void update()
    {
        if (!spinning)
        {
            return;
        }
        if (speedControl && spinTimer.seconds() > ENCODER_CHECK_S)
        {
            if (getVelocityTicksPerSec() < ENCODER_MIN_TICKS_PER_SEC)
            {
                speedControl = false;
            }
        }
        driveAtTarget();
        driveCounter();
    }

    private void driveCounter()
    {
        if (counterRoller == null)
        {
            return;
        }
        if (!isCounterVelocityControlled())
        {
            writeCounter(counterPower);
            return;
        }

        double measured = counterEx.getVelocity();
        double dt = counterClock.seconds();
        if (dt < MIN_CONTROL_DT_S)
        {
            return;
        }
        counterClock.reset();
        dt = Math.min(dt, MAX_CONTROL_DT_S);

        if (counterPower >= 0.3 && Math.abs(measured) < ENCODER_MIN_TICKS_PER_SEC)
        {
            counterLowSpeedS += dt;
            if (counterLowSpeedS >= ENCODER_CHECK_S)
            {
                counterEncoderFailed = true;
                writeCounter(counterPower);
                return;
            }
        }
        else
        {
            counterLowSpeedS = 0.0;
        }
        writeCounter(counterController.calculate(counterPower * counterController.getMaxTicksPerSec(), measured, dt));
    }

    private void driveAtTarget()
    {
        if (!usesVelocityControl())
        {
            state = State.HOLDING;
            writeShooter(targetFraction);
            return;
        }

        double dt = controlTimer.seconds();
        if (controlStarted && dt < MIN_CONTROL_DT_S)
        {
            return;
        }
        controlStarted = true;
        dt = Math.min(Math.max(dt, MIN_CONTROL_DT_S), MAX_CONTROL_DT_S);
        controlTimer.reset();

        double raw = getVelocityTicksPerSec();
        double previous = filteredVelocity;
        filteredVelocity = previous + VELOCITY_FILTER * (raw - previous);
        double acceleration = (filteredVelocity - previous) / dt;

        double target = getTargetTicksPerSec();
        if (state == State.SPINNING_UP)
        {
            if (filteredVelocity < SPINUP_EXIT_FRACTION * target)
            {
                writeShooter(1.0);
                return;
            }
            state = State.HOLDING;
        }
        double kV = (1.0 - FEEDFORWARD_KS) / maxTicksPerSec;
        double error = target - filteredVelocity;

        double scale = batteryScale(Math.abs(error) <= BATTERY_UPDATE_BAND * target);
        double power = scale * (FEEDFORWARD_KS + kV * target) + feedbackKp * error - feedbackKd * acceleration;
        power = Math.max(0.0, Math.min(1.0, power));
        writeShooter(power);
    }

    // Smoothed battery voltage scale for the feedforward. The voltage is only updated while the
    // flywheel is near its target, so the dip during a shot is not mistaken for a dead battery.
    private double batteryScale(boolean steady)
    {
        if (!USE_VOLTAGE_COMP || batterySensor == null)
        {
            return 1.0;
        }
        if (batteryFiltered <= 0.0 || (steady && batteryTimer.seconds() >= BATTERY_READ_PERIOD_S))
        {
            double reading = batterySensor.getVoltage();
            if (reading > 1.0)
            {
                if (batteryFiltered <= 0.0)
                {
                    batteryFiltered = reading;
                }
                else
                {
                    double alpha = Math.min(1.0, BATTERY_READ_PERIOD_S / BATTERY_FILTER_S);
                    batteryFiltered += alpha * (reading - batteryFiltered);
                }
            }
            batteryTimer.reset();
        }
        if (batteryFiltered <= 0.0)
        {
            return 1.0;
        }
        return Math.max(BATTERY_SCALE_MIN, Math.min(BATTERY_SCALE_MAX, NOMINAL_BATTERY_V / batteryFiltered));
    }

    public double getBatteryVoltage()
    {
        return batteryFiltered;
    }

    private void writeShooter(double power)
    {
        if (power == lastShooterPower)
        {
            return;
        }
        lastShooterPower = power;
        shooterDriver.setPower(power);
    }

    private void writeCounter(double power)
    {
        if (counterRoller == null || power == lastCounterPower)
        {
            return;
        }
        lastCounterPower = power;
        counterRoller.setPower(power);
    }

    public boolean usesVelocityControl()
    {
        return shooterEx != null && speedControl && maxTicksPerSec > 0.0;
    }

    public double getTargetTicksPerSec()
    {
        return targetFraction * maxTicksPerSec;
    }

    public void setTargetFraction(double fraction)
    {
        targetFraction = Math.max(0.0, Math.min(MAX_SPEED_FRACTION, fraction));
    }

    public double getTargetFraction()
    {
        return targetFraction;
    }

    public void setCounterPower(double power)
    {
        counterPower = Math.max(0.0, Math.min(1.0, power));
        if (spinning)
        {
            driveCounter();
        }
    }

    public void setCounterVelocityGains(double kS, double maxTicksPerSec, double kP, double kD)
    {
        counterController.setGains(kS, maxTicksPerSec, kP, kD);
    }

    public boolean isCounterVelocityControlled()
    {
        return counterEx != null && counterController.getMaxTicksPerSec() > 0.0 && !counterEncoderFailed;
    }

    public void setCounterRawPower(double power)
    {
        counterController.reset();
        writeCounter(power);
    }

    public double getCounterVelocityTicksPerSec()
    {
        if (counterEx == null)
        {
            return 0.0;
        }
        return counterEx.getVelocity();
    }

    public double getCounterPower()
    {
        return counterPower;
    }

    public void setDistance(double distanceIn)
    {
        if (distanceIn < 0.0 || SHOT_DISTANCES_IN.length == 0 || SHOT_DISTANCES_IN.length != SHOT_FRACTIONS.length)
        {
            targetFraction = SHOOTER_SPEED_FRACTION;
            return;
        }
        int last = SHOT_DISTANCES_IN.length - 1;
        if (distanceIn <= SHOT_DISTANCES_IN[0])
        {
            setTargetFraction(SHOT_FRACTIONS[0]);
            return;
        }
        if (distanceIn >= SHOT_DISTANCES_IN[last])
        {
            setTargetFraction(SHOT_FRACTIONS[last]);
            return;
        }
        for (int i = 0; i < last; i++)
        {
            double lo = SHOT_DISTANCES_IN[i];
            double hi = SHOT_DISTANCES_IN[i + 1];
            if (distanceIn >= lo && distanceIn <= hi)
            {
                double t = (distanceIn - lo) / (hi - lo);
                setTargetFraction(SHOT_FRACTIONS[i] + t * (SHOT_FRACTIONS[i + 1] - SHOT_FRACTIONS[i]));
                return;
            }
        }
    }

    public void setMaxTicksPerSec(double value)
    {
        maxTicksPerSec = value;
        if (spinning)
        {
            driveAtTarget();
        }
    }

    public void setFeedback(double kP, double kD)
    {
        feedbackKp = kP;
        feedbackKd = kD;
    }

    public double getFeedbackKp()
    {
        return feedbackKp;
    }

    public double getFeedbackKd()
    {
        return feedbackKd;
    }

    public double getMaxTicksPerSec()
    {
        return maxTicksPerSec;
    }

    public State getState()
    {
        return state;
    }

    public boolean isSpinningUp()
    {
        return state == State.SPINNING_UP;
    }

    public boolean isHolding()
    {
        return state == State.HOLDING;
    }

    public boolean isOn()
    {
        return spinning;
    }

    public void spinFullPower()
    {
        spinning = false;
        state = State.OFF;
        shooterDriver.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        lastShooterPower = Double.NaN;
        writeShooter(1.0);
    }

    public void setRawPower(double power)
    {
        spinning = false;
        state = State.OFF;
        if (shooterDriver.getMode() != DcMotor.RunMode.RUN_WITHOUT_ENCODER)
        {
            shooterDriver.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            lastShooterPower = Double.NaN;
        }
        writeShooter(power);
    }

    public boolean isSpeedControlled()
    {
        return speedControl;
    }

    public void stopShooter()
    {
        spinning = false;
        state = State.OFF;
        writeShooter(0.0);
        writeCounter(0.0);
        counterController.reset();
        counterLowSpeedS = 0.0;
    }

    public void stopAll()
    {
        stopShooter();
    }

    public double getShooterPower()
    {
        return shooterDriver.getPower();
    }

    public double getVelocityTicksPerSec()
    {
        if (shooterEx == null)
        {
            return 0.0;
        }
        return Math.abs(shooterEx.getVelocity());
    }

    public double getRpm()
    {
        return getVelocityTicksPerSec() / TICKS_PER_REV * 60.0;
    }
}
