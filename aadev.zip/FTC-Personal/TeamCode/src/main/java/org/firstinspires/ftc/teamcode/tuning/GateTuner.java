package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Gate;

@TeleOp(name = "Gate Tuner", group = "Tuning")
public class GateTuner extends LinearOpMode
{
    private static final double[] STEPS = {0.05, 0.01, 0.002};

    private final boolean[] wasDown = new boolean[8];

    private boolean pressed(int index, boolean down)
    {
        boolean result = down && !wasDown[index];
        wasDown[index] = down;
        return result;
    }

    @Override
    public void runOpMode()
    {
        Gate gate;
        try
        {
            gate = new Gate(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Gate", "stopper servo not found in the config");
            telemetry.update();
            waitForStart();
            return;
        }

        double closed = gate.getClosedPosition();
        double open = gate.getOpenPosition();
        int stepIndex = 1;

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addLine("Gate Tuner - keep clear of the gate");
            telemetry.addLine("A: go to the open position");
            telemetry.addLine("B: go to the closed position");
            telemetry.addLine("D-pad up/down: open position up / down");
            telemetry.addLine("D-pad right/left: closed position up / down");
            telemetry.addLine("X: change the step size (0.05, 0.01, 0.002)");
            telemetry.addLine("Changes move the servo right away if it is already at that position.");
            telemetry.update();
            idle();
        }

        while (opModeIsActive())
        {
            if (pressed(0, gamepad1.x))
            {
                stepIndex = (stepIndex + 1) % STEPS.length;
            }
            double step = STEPS[stepIndex];

            if (pressed(1, gamepad1.dpad_up))
            {
                open += step;
            }
            if (pressed(2, gamepad1.dpad_down))
            {
                open -= step;
            }
            if (pressed(3, gamepad1.dpad_right))
            {
                closed += step;
            }
            if (pressed(4, gamepad1.dpad_left))
            {
                closed -= step;
            }
            open = Math.max(0.0, Math.min(1.0, open));
            closed = Math.max(0.0, Math.min(1.0, closed));

            gate.setOpenPosition(open);
            gate.setClosedPosition(closed);

            if (pressed(5, gamepad1.a))
            {
                gate.open();
            }
            if (pressed(6, gamepad1.b))
            {
                gate.close();
            }

            telemetry.addData("Gate is", gate.isOpen() ? "OPEN" : "CLOSED");
            telemetry.addData("Open position", "%.3f (about %.0f deg)", open, open * Gate.SERVO_RANGE_DEG);
            telemetry.addData("Closed position", "%.3f (about %.0f deg)", closed, closed * Gate.SERVO_RANGE_DEG);
            telemetry.addData("Travel between them", "about %.0f deg", Math.abs(open - closed) * Gate.SERVO_RANGE_DEG);
            telemetry.addData("Step size", "%.3f", step);
            telemetry.addLine("Copy into Gate.java:");
            telemetry.addLine(String.format("CLOSED_POSITION = %.3f", closed));
            telemetry.addLine(String.format("OPEN_POSITION = %.3f", open));
            telemetry.update();
        }

        gate.close();
    }
}
