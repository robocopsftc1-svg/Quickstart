package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.util.BulkReads;
import org.firstinspires.ftc.teamcode.util.LimelightRelocalizer;
import org.firstinspires.ftc.teamcode.util.PinpointPose;

@TeleOp(name = "Limelight Pose Check", group = "Test")
public class LimelightPoseCheck extends LinearOpMode
{
    private static final double START_X_IN = 56.0;
    private static final double START_Y_IN = 8.0;
    private static final double START_HEADING_DEG = 90.0;

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);

        LimelightRelocalizer relocalizer = new LimelightRelocalizer(hardwareMap);
        PinpointPose pinpoint = null;
        String pinpointStatus = "ok";
        try
        {
            pinpoint = new PinpointPose(hardwareMap);
        }
        catch (Exception e)
        {
            pinpointStatus = "pinpoint not found in the config";
        }

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addLine("Limelight Pose Check");
            telemetry.addLine("Put the robot at a spot where you know the exact position and heading, facing a tag.");
            telemetry.addLine(String.format("A: tell the Pinpoint the robot is at (%.0f, %.0f) facing %.0f deg. Change START_X_IN, START_Y_IN, START_HEADING_DEG at the top of this file to match where you put it.", START_X_IN, START_Y_IN, START_HEADING_DEG));
            telemetry.addData("Limelight", relocalizer.hasLimelight() ? "ok" : "not found in the config");
            telemetry.addData("Pinpoint", pinpointStatus);
            telemetry.update();
            idle();
        }

        relocalizer.start();

        while (opModeIsActive())
        {
            BulkReads.clear();

            if (pinpoint != null && gamepad1.a)
            {
                pinpoint.setPose(START_X_IN, START_Y_IN, Math.toRadians(START_HEADING_DEG));
            }

            double[] robot = pinpoint == null ? null : pinpoint.pose();
            double headingRad = robot == null ? Math.toRadians(START_HEADING_DEG) : robot[2];
            double[] raw = relocalizer.rawPoseInches(headingRad);
            double[] mapped = raw == null ? null : relocalizer.toFieldFrame(raw[0], raw[1]);

            telemetry.addData("Tags seen", relocalizer.tagCount());
            if (robot == null)
            {
                telemetry.addLine("Pinpoint: press A first");
            }
            else
            {
                telemetry.addData("Pinpoint", "x %.1f in, y %.1f in, heading %.0f deg", robot[0], robot[1], Math.toDegrees(robot[2]));
            }
            if (raw == null)
            {
                telemetry.addLine("Limelight position: none (no tag in view, stale, or no limelight)");
            }
            else
            {
                telemetry.addData("Limelight raw (its own field frame)", "x %.1f in, y %.1f in", raw[0], raw[1]);
                telemetry.addData("Limelight in our field frame", "x %.1f in, y %.1f in", mapped[0], mapped[1]);
                if (robot != null)
                {
                    telemetry.addData("Difference from Pinpoint", "x %.1f in, y %.1f in", mapped[0] - robot[0], mapped[1] - robot[1]);
                }
            }
            telemetry.addLine("If the difference is large: x and y swapped means set LL_SWAP_XY = true; an axis that is mirrored means flip LL_X_SIGN or LL_Y_SIGN; all in LimelightRelocalizer.java.");
            telemetry.addLine("If the position is right but turns wrong when you rotate the robot, set LL_HEADING_OFFSET_DEG.");
            telemetry.update();
        }

        relocalizer.stop();
    }
}
