package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.util.BulkReads;

@TeleOp(name = "Intake Power Tuner", group = "Tuning")
public class IntakePowerTuner extends LinearOpMode
{
    private static final double POWER_STEP = 0.01;
    private static final double RAMP_STEP_S = 0.01;

    private final boolean[] wasDown = new boolean[8];

    private boolean pressed(int index, boolean down)
    {
        boolean result = down && !wasDown[index];
        wasDown[index] = down;
        return result;
    }

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);

        Intake intake;
        try
        {
            intake = new Intake(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Intake", "intake motor not found in the config");
            telemetry.update();
            waitForStart();
            return;
        }

        double intakePower = Intake.INTAKE_POWER;
        double outtakePower = Intake.REVERSE_POWER;
        double rampS = Intake.RAMP_TIME_S;

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addLine("Right bumper (hold): intake");
            telemetry.addLine("Left bumper (hold): outtake");
            telemetry.addLine("D-pad up/down: intake power");
            telemetry.addLine("B / A: outtake power up / down");
            telemetry.addLine("D-pad right/left: ramp time (how long it takes to reach full power)");
            telemetry.addLine("Copy the values into INTAKE_POWER, REVERSE_POWER and RAMP_TIME_S in Intake.java");
            telemetry.update();
            idle();
        }

        while (opModeIsActive())
        {
            BulkReads.clear();

            if (pressed(1, gamepad1.dpad_up))
            {
                intakePower += POWER_STEP;
            }
            if (pressed(2, gamepad1.dpad_down))
            {
                intakePower -= POWER_STEP;
            }
            if (pressed(3, gamepad1.b))
            {
                outtakePower += POWER_STEP;
            }
            if (pressed(4, gamepad1.a))
            {
                outtakePower -= POWER_STEP;
            }
            if (pressed(5, gamepad1.dpad_right))
            {
                rampS += RAMP_STEP_S;
            }
            if (pressed(6, gamepad1.dpad_left))
            {
                rampS -= RAMP_STEP_S;
            }
            intakePower = Math.max(0.0, Math.min(1.0, intakePower));
            outtakePower = Math.max(0.0, Math.min(1.0, outtakePower));
            rampS = Math.max(0.01, rampS);

            intake.setIntakePower(intakePower);
            intake.setReversePower(outtakePower);
            intake.setRampTime(rampS);

            String mode = "stopped";
            if (gamepad1.left_bumper)
            {
                intake.out();
                mode = "outtake";
            }
            else if (gamepad1.right_bumper)
            {
                intake.in();
                mode = "intake";
            }
            else
            {
                intake.stop();
            }

            telemetry.addData("Mode", mode);
            telemetry.addData("Intake power", "%.2f", intakePower);
            telemetry.addData("Outtake power", "%.2f", outtakePower);
            telemetry.addData("Ramp time", "%.2f s", rampS);
            telemetry.addData("Actual power now", "%.2f", intake.getPower());
            telemetry.addData("Current", "%.1f A (peak %.1f A)", intake.getCurrentAmps(), intake.getPeakCurrentAmps());
            telemetry.addData("Copy", "INTAKE_POWER = %.2f, REVERSE_POWER = %.2f, RAMP_TIME_S = %.2f", intakePower, outtakePower, rampS);
            telemetry.update();
        }

        intake.stop();
    }
}
