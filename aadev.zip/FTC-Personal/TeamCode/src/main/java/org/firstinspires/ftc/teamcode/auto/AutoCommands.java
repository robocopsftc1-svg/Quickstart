package org.firstinspires.ftc.teamcode.auto;

import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.commands.Commands.waitUntil;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.pedropathing.follower.Follower;
import com.pedropathing.ivy.Command;
import com.pedropathing.math.Pose;
import com.pedropathing.paths.Path;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Gate;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.ShootingCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.FlowerCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;
import org.firstinspires.ftc.teamcode.robot.Robot;
import org.firstinspires.ftc.teamcode.util.MecanumWheelPowers;

public class AutoCommands
{
    public static final double LAUNCH_SPINUP_S = ShootingCycle.SPINUP_S;
    public static final double LAUNCH_FEED_S = ShootingCycle.INTAKE_LEAD_S + ShootingCycle.FEED_S;

    private final DcMotor frontLeft;
    private final DcMotor backLeft;
    private final DcMotor frontRight;
    private final DcMotor backRight;

    public final Robot robot;
    public Shooter shooter;
    public Intake intake;
    public Gate gate;
    public TurretTracker turret;
    public Sweeper sweeper;
    public ShootingCycle cycle;
    public FlowerCycle flowerCycle;

    private final ElapsedTime revTimer = new ElapsedTime();
    private boolean revving = false;
    private boolean turretActive = false;
    private boolean sweeperActive = false;

    public AutoCommands(HardwareMap hardwareMap)
    {
        robot = new Robot(hardwareMap);
        frontLeft = robot.frontLeft;
        backLeft = robot.backLeft;
        frontRight = robot.frontRight;
        backRight = robot.backRight;

        shooter = robot.shooter;
        intake = robot.intake;
        gate = robot.gate;
        turret = robot.turret;
        sweeper = robot.sweeper;
        cycle = robot.shootingCycle;
        flowerCycle = robot.flowerCycle;
    }

    public void setPoseSource(TurretTracker.PoseSource source)
    {
        robot.setPoseSource(source);
    }

    public Follower createFollower()
    {
        return robot.createFollower();
    }

    public boolean hasFollower()
    {
        return robot.hasFollower();
    }

    public String getFollowerStatus()
    {
        return robot.followerStatus;
    }

    public void setStartPose(Pose pose)
    {
        robot.setStartPose(pose);
    }

    public Pose getPose()
    {
        return robot.getPose();
    }

    public void updateFollower()
    {
        robot.updateFollower();
    }

    public Path createPath(Pose start, Pose end)
    {
        return robot.createPath(start, end);
    }

    public Path createPath(Pose start, Pose control, Pose end)
    {
        return robot.createPath(start, control, end);
    }

    public Command executePath(Path path)
    {
        return robot.executePath(path);
    }

    public Command executePath(Path path, double blendIn)
    {
        return robot.executePath(path, blendIn);
    }

    public Command driveCommand(Path path, Pose endPose, double blendIn)
    {
        return robot.driveCommand(path, endPose, blendIn);
    }

    public Command followPath(Pose start, Pose end, boolean collect, boolean shoot)
    {
        return robot.followPath(start, end, collect, shoot);
    }

    public Command followPathAvoidingHive(Pose start, Pose end, boolean collect, boolean shoot)
    {
        return robot.followPathAvoidingHive(start, end, collect, shoot);
    }

    public Command followPath(Pose start, Pose control, Pose end, boolean collect, boolean shoot)
    {
        return robot.followPath(start, control, end, collect, shoot);
    }

    public boolean hasSweeper()
    {
        return sweeper != null;
    }

    public void startSweeper()
    {
        if (sweeper != null)
        {
            robot.startSweeper();
            sweeperActive = true;
        }
    }

    public Command sweeperDown()
    {
        return sequential(
                instant(() ->
                {
                    if (sweeper != null)
                    {
                        sweeper.deploy();
                    }
                }),
                waitUntil(() -> sweeper == null || !sweeperActive || !sweeper.isMoving()));
    }

    public Command sweeperLower()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.deploy();
            }
        });
    }

    public Command collectFlower()
    {
        if (flowerCycle == null)
        {
            return waitMs(FlowerCycle.COLLECT_S * 1000.0);
        }
        return sequential(
                instant(() -> flowerCycle.start(false)),
                waitUntil(() -> flowerCycle.isDone()));
    }

    public Command shooterOff()
    {
        return robot.shooterOff();
    }

    public Command sweeperUp()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.stow();
            }
        });
    }

    public boolean hasTurret()
    {
        return turret != null;
    }

    public void setAlliance(boolean blue)
    {
        if (turret != null)
        {
            turret.setAlliance(blue);
        }
    }

    public void startTurret()
    {
        if (turret != null)
        {
            robot.startTurret();
            turretActive = true;
        }
    }

    public boolean canLaunch()
    {
        return shooter != null && intake != null;
    }

    public void update()
    {
        robot.update(null);
    }

    public void update(Telemetry telemetry)
    {
        robot.update(telemetry);
    }

    public void stopAll()
    {
        robot.haltAuto();
        stopDrive();
        revving = false;
        if (cycle != null)
        {
            cycle.cancel();
        }
        if (flowerCycle != null)
        {
            flowerCycle.cancel();
        }
        if (shooter != null)
        {
            shooter.stopAll();
        }
        if (intake != null)
        {
            intake.stop();
        }
        if (gate != null)
        {
            gate.close();
        }
        if (turret != null && turretActive)
        {
            turretActive = false;
            turret.stop();
        }
        if (sweeper != null && sweeperActive)
        {
            sweeper.stow();
        }
    }

    public void setDrive(double axial, double lateral, double yaw)
    {
        double[] power = MecanumWheelPowers.calculate(axial, lateral, yaw);

        frontLeft.setPower(power[0]);
        frontRight.setPower(power[1]);
        backLeft.setPower(power[2]);
        backRight.setPower(power[3]);
    }

    public void stopDrive()
    {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }

    public Command nothing()
    {
        return instant(() ->
        {
        });
    }

    public Command rev()
    {
        return robot.rev();
    }

    public Command intakeOn()
    {
        return robot.intakeOn();
    }

    public Command intakeOff()
    {
        return robot.intakeOff();
    }

    public Command driveFor(double axial, double lateral, double seconds)
    {
        return sequential(
                instant(() -> setDrive(axial, lateral, 0.0)),
                waitMs(seconds * 1000.0),
                instant(this::stopDrive));
    }

    public Command launch()
    {
        return robot.launch();
    }

    private void startRev()
    {
        if (!revving && shooter != null)
        {
            shooter.shoot();
            revTimer.reset();
            revving = true;
        }
    }
}
