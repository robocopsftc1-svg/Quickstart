package org.firstinspires.ftc.teamcode.mechanisms.intake;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.util.VelocityController;

public class Intake
{
    public static final double INTAKE_POWER  = 1.0;
    public static final double REVERSE_POWER = 1.0;
    public static final double RAMP_TIME_S = 0.08;

    public static final double INTAKE_KS = 0.1;
    public static final double INTAKE_MAX_TICKS_PER_SEC = 0.0;
    public static final double INTAKE_KP = 0.002;
    public static final double INTAKE_KD = 0.0;
    private static final double CONTROL_MIN_DT_S = 0.005;
    private static final double ENCODER_CHECK_S = 0.8;
    private static final double ENCODER_MIN_TICKS_PER_SEC = 0.8;
    private static final double ENCODER_CHECK_MIN_SPEED = 0.3;
    private static final double MAX_STEP_TIME_S = 0.1;

    public static final double JAM_CURRENT_AMPS = 0.0;
    public static final double JAM_DETECT_S = 0.3;
    public static final double JAM_REVERSE_S = 0.4;
    public static final double JAM_COOLDOWN_S = 1.0;
    private static final double CURRENT_READ_PERIOD_S = 0.1;
    private static final double RAMP_DONE_MARGIN = 0.05;

    // "Up to speed" check used by the shooting cycle before the gate opens.
    public static final double SPEED_READY_FRACTION = 0.9;
    public static final double SPEED_CHECK_PERIOD_S = 0.03;
    public static final double SPEED_STABLE_FRACTION = 0.03;
    public static final double SPEED_MIN_TICKS_PER_SEC = 50.0;
    private static final int SPEED_STABLE_CHECKS = 2;

    private static final DcMotorSimple.Direction INNER_DIRECTION    = DcMotorSimple.Direction.REVERSE;
    private static final DcMotorSimple.Direction OUTER_DIRECTION    = DcMotorSimple.Direction.FORWARD;
    private static final DcMotorSimple.Direction TRANSFER_DIRECTION = DcMotorSimple.Direction.FORWARD;

    private static class Stage
    {
        private DcMotor[] motors;
        private DcMotorEx lead = null;
        private VelocityController controller = null;
        private double power = 0.0;
        private double target = 0.0;
        private double lastWritten = Double.NaN;
        private double lowSpeedS = 0.0;
        private boolean encoderFailed = false;
        private ElapsedTime clock = new ElapsedTime();
        private ElapsedTime controlClock = new ElapsedTime();

        Stage(DcMotor[] motors)
        {
            this.motors = motors;
        }

        void attach(DcMotorEx leadMotor, VelocityController velocityController)
        {
            lead = leadMotor;
            controller = velocityController;
        }

        boolean velocityControlled()
        {
            return lead != null && controller != null && controller.getMaxTicksPerSec() > 0.0 && !encoderFailed;
        }

        void setTarget(double t)
        {
            if (t == 0.0)
            {
                stop();
            }
            else
            {
                target = t;
            }
        }

        // Jump the power straight to the target with no ramp.
        void snap()
        {
            if (target != 0.0 && power != target)
            {
                power = target;
                if (!velocityControlled())
                {
                    writePower(target);
                }
            }
        }

        void stop()
        {
            target = 0.0;
            clock.reset();
            lowSpeedS = 0.0;
            if (controller != null)
            {
                controller.reset();
            }
            apply(0.0);
        }

        void update(double rampTimeS)
        {
            double dt = Math.min(clock.seconds(), MAX_STEP_TIME_S);
            clock.reset();

            if (target == 0.0)
            {
                apply(0.0);
                return;
            }

            double step = dt / rampTimeS;
            double next = power;
            if (next < target)
            {
                next = Math.min(target, next + step);
            }
            else if (next > target)
            {
                next = Math.max(target, next - step);
            }
            power = next;

            if (velocityControlled())
            {
                double measured = lead.getVelocity();
                if (Math.abs(next) >= ENCODER_CHECK_MIN_SPEED && Math.abs(measured) < ENCODER_MIN_TICKS_PER_SEC)
                {
                    lowSpeedS += dt;
                    if (lowSpeedS >= ENCODER_CHECK_S)
                    {
                        encoderFailed = true;
                    }
                }
                else
                {
                    lowSpeedS = 0.0;
                }
                if (!encoderFailed)
                {
                    double controlDt = controlClock.seconds();
                    if (controlDt >= CONTROL_MIN_DT_S)
                    {
                        controlClock.reset();
                        writePower(controller.calculate(next * controller.getMaxTicksPerSec(), measured, Math.min(controlDt, MAX_STEP_TIME_S)));
                    }
                    return;
                }
            }
            writePower(next);
        }

        void apply(double p)
        {
            power = p;
            writePower(p);
        }

        void writePower(double p)
        {
            if (p == lastWritten)
            {
                return;
            }
            lastWritten = p;
            for (int i = 0; i < motors.length; i++)
            {
                motors[i].setPower(p);
            }
        }
    }

    private double intakePower = INTAKE_POWER;
    private double reversePower = REVERSE_POWER;
    private double rampTimeS = RAMP_TIME_S;

    private DcMotor inner;
    private DcMotor outer;
    private DcMotor transfer;
    private Stage innerStage;
    private Stage outerStage;

    private DcMotorEx innerEx = null;
    private DcMotorEx outerEx = null;
    private final ElapsedTime currentTimer = new ElapsedTime();
    private final ElapsedTime jamTimer = new ElapsedTime();
    private final ElapsedTime reverseTimer = new ElapsedTime();
    private final ElapsedTime cooldownTimer = new ElapsedTime();
    private boolean reversing = false;
    private boolean jamProtection = true;
    private boolean wasRunning = false;
    private double currentAmps = 0.0;
    private double innerAmps = 0.0;
    private double outerAmps = 0.0;
    private boolean readInnerNext = true;
    private final ElapsedTime speedTimer = new ElapsedTime();
    private double lastSpeed = 0.0;
    private int stableChecks = 0;
    private double peakAmps = 0.0;
    private int jamCount = 0;

    public Intake(HardwareMap hardwareMap)
    {
        inner = hardwareMap.get(DcMotor.class, HardwareNames.INTAKE_LEFT);

        outer = null;
        try
        {
            outer = hardwareMap.get(DcMotor.class, HardwareNames.INTAKE_RIGHT);
        }
        catch (Exception e)
        {
            outer = null;
        }

        transfer = null;
        try
        {
            transfer = hardwareMap.get(DcMotor.class, HardwareNames.TRANSFER);
        }
        catch (Exception e)
        {
            transfer = null;
        }

        inner.setDirection(INNER_DIRECTION);
        if (outer != null)
        {
            outer.setDirection(OUTER_DIRECTION);
        }
        if (transfer != null)
        {
            transfer.setDirection(TRANSFER_DIRECTION);
        }

        setupMotor(inner);
        if (outer != null)
        {
            setupMotor(outer);
        }
        if (transfer != null)
        {
            setupMotor(transfer);
        }

        if (transfer != null)
        {
            innerStage = new Stage(new DcMotor[] {inner, transfer});
        }
        else
        {
            innerStage = new Stage(new DcMotor[] {inner});
        }
        if (outer != null)
        {
            outerStage = new Stage(new DcMotor[] {outer});
        }
        else
        {
            outerStage = new Stage(new DcMotor[0]);
        }

        if (inner instanceof DcMotorEx)
        {
            innerEx = (DcMotorEx) inner;
        }
        if (outer instanceof DcMotorEx)
        {
            outerEx = (DcMotorEx) outer;
        }

        innerStage.attach(innerEx, new VelocityController(INTAKE_KS, INTAKE_MAX_TICKS_PER_SEC, INTAKE_KP, INTAKE_KD));
        outerStage.attach(outerEx, new VelocityController(INTAKE_KS, INTAKE_MAX_TICKS_PER_SEC, INTAKE_KP, INTAKE_KD));
    }

    private void setupMotor(DcMotor motor)
    {
        motor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }

    public void control(boolean innerButton, boolean outerButton, boolean reverseButton)
    {
        if (reverseButton)
        {
            innerStage.setTarget(-reversePower);
            outerStage.setTarget(-reversePower);
        }
        else if (innerButton && outerButton)
        {
            innerStage.stop();
            outerStage.stop();
        }
        else
        {
            double innerTarget = 0.0;
            if (innerButton)
            {
                innerTarget = intakePower;
            }
            double outerTarget = 0.0;
            if (outerButton)
            {
                outerTarget = intakePower;
            }
            innerStage.setTarget(innerTarget);
            outerStage.setTarget(outerTarget);
        }
        update();
    }

    public void in()
    {
        innerStage.setTarget(intakePower);
        outerStage.setTarget(intakePower);
        update();
    }

    // Full intake power at once with no ramp. Used by the shooting cycle so the intake gets up to speed fast.
    public void inFull()
    {
        innerStage.setTarget(intakePower);
        outerStage.setTarget(intakePower);
        innerStage.snap();
        outerStage.snap();
        update();
    }

    // True once the intake motor has actually reached its speed, not just the power command.
    // With the max speed known (INTAKE_MAX_TICKS_PER_SEC) it checks 90% of the expected speed.
    // Otherwise it waits until the measured speed stops changing.
    public boolean isUpToSpeed()
    {
        if (!forwardRequested() || reversing)
        {
            stableChecks = 0;
            return false;
        }
        if (!rampDone())
        {
            stableChecks = 0;
            return false;
        }
        if (innerEx == null || innerStage.encoderFailed)
        {
            return true;
        }
        double speed = Math.abs(innerEx.getVelocity());
        double max = 0.0;
        if (innerStage.controller != null)
        {
            max = innerStage.controller.getMaxTicksPerSec();
        }
        if (max > 0.0)
        {
            double fraction = Math.max(0.0, (intakePower - INTAKE_KS) / (1.0 - INTAKE_KS));
            return speed >= SPEED_READY_FRACTION * fraction * max;
        }
        if (speedTimer.seconds() >= SPEED_CHECK_PERIOD_S)
        {
            speedTimer.reset();
            if (speed >= SPEED_MIN_TICKS_PER_SEC && Math.abs(speed - lastSpeed) <= SPEED_STABLE_FRACTION * speed)
            {
                stableChecks++;
            }
            else
            {
                stableChecks = 0;
            }
            lastSpeed = speed;
        }
        return stableChecks >= SPEED_STABLE_CHECKS;
    }

    public void out()
    {
        innerStage.setTarget(-reversePower);
        outerStage.setTarget(-reversePower);
        update();
    }

    public void stop()
    {
        innerStage.stop();
        outerStage.stop();
    }

    public void update()
    {
        if (reversing)
        {
            continueReverse();
            return;
        }
        innerStage.update(rampTimeS);
        outerStage.update(rampTimeS);
        checkJam();
    }

    public void setIntakePower(double power)
    {
        intakePower = Math.max(0.0, Math.min(1.0, power));
    }

    public double getIntakePower()
    {
        return intakePower;
    }

    public void setReversePower(double power)
    {
        reversePower = Math.max(0.0, Math.min(1.0, power));
    }

    public double getReversePower()
    {
        return reversePower;
    }

    public void setRampTime(double seconds)
    {
        rampTimeS = Math.max(0.01, seconds);
    }

    public double getRampTime()
    {
        return rampTimeS;
    }

    public void setVelocityGains(double kS, double maxTicksPerSec, double kP, double kD)
    {
        if (innerStage.controller != null)
        {
            innerStage.controller.setGains(kS, maxTicksPerSec, kP, kD);
        }
        if (outerStage.controller != null)
        {
            outerStage.controller.setGains(kS, maxTicksPerSec, kP, kD);
        }
    }

    public boolean isVelocityControlled()
    {
        return innerStage.velocityControlled();
    }

    public double getInnerVelocityTicksPerSec()
    {
        if (innerEx == null)
        {
            return 0.0;
        }
        return innerEx.getVelocity();
    }

    public void setJamProtection(boolean enabled)
    {
        jamProtection = enabled;
        jamTimer.reset();
    }

    public boolean isClearingJam()
    {
        return reversing;
    }

    public int getJamCount()
    {
        return jamCount;
    }

    public double getCurrentAmps()
    {
        return currentAmps;
    }

    public double getPeakCurrentAmps()
    {
        return peakAmps;
    }

    private boolean forwardRequested()
    {
        return innerStage.target > 0.0 || outerStage.target > 0.0;
    }

    private boolean rampDone()
    {
        boolean done = true;
        if (innerStage.target > 0.0 && innerStage.power < innerStage.target - RAMP_DONE_MARGIN)
        {
            done = false;
        }
        if (outerStage.target > 0.0 && outerStage.power < outerStage.target - RAMP_DONE_MARGIN)
        {
            done = false;
        }
        return done;
    }

    private double readCurrentAmps()
    {
        boolean readInner = innerEx != null && (outerEx == null || readInnerNext);
        if (readInner)
        {
            innerAmps = innerEx.getCurrent(CurrentUnit.AMPS);
        }
        else if (outerEx != null)
        {
            outerAmps = outerEx.getCurrent(CurrentUnit.AMPS);
        }
        readInnerNext = !readInnerNext;
        return Math.max(innerAmps, outerAmps);
    }

    private void checkJam()
    {
        if (!forwardRequested())
        {
            wasRunning = false;
            jamTimer.reset();
            return;
        }
        if (!wasRunning)
        {
            wasRunning = true;
            peakAmps = 0.0;
            currentTimer.reset();
            jamTimer.reset();
            return;
        }
        if (currentTimer.seconds() < CURRENT_READ_PERIOD_S)
        {
            return;
        }
        currentTimer.reset();

        currentAmps = readCurrentAmps();
        boolean steady = rampDone();
        if (steady)
        {
            peakAmps = Math.max(peakAmps, currentAmps);
        }

        boolean jammed = JAM_CURRENT_AMPS > 0.0
                && jamProtection
                && steady
                && cooldownTimer.seconds() >= JAM_COOLDOWN_S
                && currentAmps >= JAM_CURRENT_AMPS;
        if (!jammed)
        {
            jamTimer.reset();
            return;
        }
        if (jamTimer.seconds() >= JAM_DETECT_S)
        {
            reversing = true;
            jamCount++;
            reverseTimer.reset();
            innerStage.apply(-reversePower);
            outerStage.apply(-reversePower);
        }
    }

    private void continueReverse()
    {
        if (!forwardRequested() || reverseTimer.seconds() >= JAM_REVERSE_S)
        {
            reversing = false;
            innerStage.apply(0.0);
            outerStage.apply(0.0);
            innerStage.clock.reset();
            outerStage.clock.reset();
            cooldownTimer.reset();
            jamTimer.reset();
            return;
        }
        innerStage.apply(-reversePower);
        outerStage.apply(-reversePower);
    }

    public double getInnerPower()
    {
        return innerStage.power;
    }

    public double getOuterPower()
    {
        return outerStage.power;
    }

    public boolean hasOuter()
    {
        return outer != null;
    }

    public boolean hasTransfer()
    {
        return transfer != null;
    }

    public double getPower()
    {
        double a = innerStage.power;
        double b = outerStage.power;
        if (Math.abs(a) >= Math.abs(b))
        {
            return a;
        }
        return b;
    }

    public void setPowers(double innerPower, double outerPower)
    {
        innerStage.target = 0.0;
        outerStage.target = 0.0;
        innerStage.apply(innerPower);
        outerStage.apply(outerPower);
    }
}
