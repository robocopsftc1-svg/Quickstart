package org.firstinspires.ftc.teamcode.util;

import java.util.ArrayList;
import java.util.List;

// Finds extra waypoints so a drive from one spot to another goes around the hive instead of through it.
// Coordinates are the same field inches the autos use (0 to 144, origin in the bottom left corner).
public class HiveRoutePlanner
{
    public static final double HIVE_LEFT_IN = 47.0;
    public static final double HIVE_RIGHT_IN = 97.0;
    public static final double HIVE_BOTTOM_IN = 52.5;
    public static final double HIVE_TOP_IN = 91.5;

    public static final double ROBOT_HALF_LENGTH_IN = 11.0;
    public static final double ROBOT_HALF_WIDTH_IN = 9.0;
    public static final double CLEARANCE_IN = 2.0;

    private static final double EPS = 1e-6;

    private HiveRoutePlanner()
    {
    }

    // Distance the robot center must stay from the hive so no part of the robot can touch it, at any heading.
    public static double cornerMargin()
    {
        return Math.hypot(ROBOT_HALF_LENGTH_IN, ROBOT_HALF_WIDTH_IN) + CLEARANCE_IN;
    }

    // Closest the robot center may get to a hive side when driving straight past it.
    public static double edgeMargin()
    {
        return ROBOT_HALF_WIDTH_IN;
    }

    // Returns the waypoints between the start and the end, in order. An empty list means the straight
    // line is already clear. Returns null if the start or end is already too close to the hive to plan.
    public static List<double[]> waypoints(double startX, double startY, double endX, double endY)
    {
        double[][] corners = bigCorners();
        double[][] nodes = new double[2 + corners.length][];
        nodes[0] = new double[] {startX, startY};
        nodes[1] = new double[] {endX, endY};
        for (int i = 0; i < corners.length; i++)
        {
            nodes[2 + i] = corners[i];
        }

        if (insideSmall(startX, startY) || insideSmall(endX, endY))
        {
            return null;
        }
        if (clear(nodes[0], nodes[1]))
        {
            return new ArrayList<>();
        }

        int count = nodes.length;
        double[] best = new double[count];
        int[] previous = new int[count];
        boolean[] done = new boolean[count];
        for (int i = 0; i < count; i++)
        {
            best[i] = Double.MAX_VALUE;
            previous[i] = -1;
        }
        best[0] = 0.0;

        for (int step = 0; step < count; step++)
        {
            int current = -1;
            for (int i = 0; i < count; i++)
            {
                if (!done[i] && best[i] < Double.MAX_VALUE && (current < 0 || best[i] < best[current]))
                {
                    current = i;
                }
            }
            if (current < 0)
            {
                break;
            }
            done[current] = true;
            for (int next = 0; next < count; next++)
            {
                if (done[next] || !clear(nodes[current], nodes[next]))
                {
                    continue;
                }
                double length = Math.hypot(nodes[next][0] - nodes[current][0], nodes[next][1] - nodes[current][1]);
                if (best[current] + length < best[next])
                {
                    best[next] = best[current] + length;
                    previous[next] = current;
                }
            }
        }

        if (previous[1] < 0)
        {
            return null;
        }
        ArrayList<double[]> reversed = new ArrayList<>();
        int node = previous[1];
        while (node > 0)
        {
            reversed.add(nodes[node]);
            node = previous[node];
        }
        ArrayList<double[]> result = new ArrayList<>();
        for (int i = reversed.size() - 1; i >= 0; i--)
        {
            result.add(reversed.get(i));
        }
        return result;
    }

    public static double routeLength(double startX, double startY, double endX, double endY, List<double[]> via)
    {
        double length = 0.0;
        double x = startX;
        double y = startY;
        if (via != null)
        {
            for (double[] point : via)
            {
                length += Math.hypot(point[0] - x, point[1] - y);
                x = point[0];
                y = point[1];
            }
        }
        return length + Math.hypot(endX - x, endY - y);
    }

    private static double[][] bigCorners()
    {
        double m = cornerMargin();
        double left = HIVE_LEFT_IN - m;
        double right = HIVE_RIGHT_IN + m;
        double bottom = HIVE_BOTTOM_IN - m;
        double top = HIVE_TOP_IN + m;
        return new double[][] {{left, bottom}, {right, bottom}, {right, top}, {left, top}};
    }

    private static boolean insideSmall(double x, double y)
    {
        double m = edgeMargin();
        return x > HIVE_LEFT_IN - m + EPS && x < HIVE_RIGHT_IN + m - EPS
                && y > HIVE_BOTTOM_IN - m + EPS && y < HIVE_TOP_IN + m - EPS;
    }

    // True if the straight line between two points does not pass through the edge-margin box around the hive.
    private static boolean clear(double[] a, double[] b)
    {
        double m = edgeMargin();
        double left = HIVE_LEFT_IN - m + EPS;
        double right = HIVE_RIGHT_IN + m - EPS;
        double bottom = HIVE_BOTTOM_IN - m + EPS;
        double top = HIVE_TOP_IN + m - EPS;

        double dx = b[0] - a[0];
        double dy = b[1] - a[1];
        double t0 = 0.0;
        double t1 = 1.0;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {a[0] - left, right - a[0], a[1] - bottom, top - a[1]};
        for (int i = 0; i < 4; i++)
        {
            if (Math.abs(p[i]) < 1e-12)
            {
                if (q[i] < 0.0)
                {
                    return true;
                }
            }
            else
            {
                double t = q[i] / p[i];
                if (p[i] < 0.0)
                {
                    t0 = Math.max(t0, t);
                }
                else
                {
                    t1 = Math.min(t1, t);
                }
            }
        }
        return t0 >= t1;
    }
}
