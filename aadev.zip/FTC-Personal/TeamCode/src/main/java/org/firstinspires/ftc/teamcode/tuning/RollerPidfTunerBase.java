package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.util.BulkReads;
import org.firstinspires.ftc.teamcode.util.VelocityController;

public abstract class RollerPidfTunerBase extends LinearOpMode
{
    private static final double KP_STEP = 0.0001;
    private static final double KD_STEP = 0.00001;
    private static final double FRACTION_STEP = 0.05;
    private static final double MOVE_TICKS_PER_SEC = 15.0;
    private static final double KS_RAMP_PER_S = 0.15;
    private static final double KS_GIVE_UP_POWER = 0.6;
    private static final double SETTLE_S = 1.0;
    private static final double MEASURE_S = 1.0;
    private static final double MIN_DT_S = 0.005;
    private static final double REACHED_FRACTION = 0.03;
    private static final double TRIGGER_THRESHOLD = 0.5;

    private static final int PHASE_IDLE = 0;
    private static final int PHASE_KS = 1;
    private static final int PHASE_MAX = 2;
    private static final int PHASE_STEP_REST = 3;
    private static final int PHASE_STEP_RUN = 4;

    private static final double STEP_REST_TICKS_PER_SEC = 20.0;
    private static final double STEP_REST_MAX_S = 2.0;
    private static final double STEP_RUN_S = 2.5;
    private static final double STEP_TAIL_S = 0.5;
    private static final double RISE_FRACTION = 0.9;
    private static final double SETTLE_BAND = 0.05;

    private static final int AUTO_OFF = 0;
    private static final int AUTO_MEASURE = 1;
    private static final int AUTO_KP = 2;
    private static final int AUTO_KD = 3;
    private static final int AUTO_VERIFY = 4;

    private static final double[] AUTO_KP_MULTIPLES = {0.25, 0.5, 1.0, 2.0, 4.0, 8.0};
    private static final double[] AUTO_KD_MULTIPLES = {0.0, 0.5, 1.0, 2.0, 4.0};
    private static final double AUTO_KD_UNIT = 0.03;
    private static final double AUTO_TARGET_FRACTION = 0.5;
    private static final double OVERSHOOT_WEIGHT = 2.0;
    private static final double ERROR_WEIGHT = 3.0;
    private static final double RISE_WEIGHT = 10.0;
    private static final double NEVER_RISE_COST = 40.0;
    private static final double NOT_SETTLED_COST = 30.0;

    protected interface Roller
    {
        void raw(double power);

        double velocity();

        boolean present();
    }

    protected static class Gains
    {
        double kS;
        double maxTicks;
        double kP;
        double kD;
        double fraction = 0.5;

        Gains(double kS, double maxTicks, double kP, double kD)
        {
            this.kS = kS;
            this.maxTicks = maxTicks;
            this.kP = kP;
            this.kD = kD;
        }
    }

    protected abstract String rollerName();

    protected abstract String fileName();

    protected abstract String constantPrefix();

    protected abstract Roller createRoller();

    protected abstract Gains startingGains();

    protected abstract double rampTimeS();

    private final boolean[] wasDown = new boolean[12];
    private final VelocityController controller = new VelocityController(0.0, 0.0, 0.0, 0.0);
    private final ElapsedTime loopTimer = new ElapsedTime();
    private final ElapsedTime phaseTimer = new ElapsedTime();
    private final ElapsedTime runTimer = new ElapsedTime();

    private Roller roller;
    private Gains g;
    private double ramp;

    private int phase = PHASE_IDLE;
    private boolean running = false;
    private double power = 0.0;
    private double velocity = 0.0;
    private double cmdFraction = 0.0;
    private double peakVelocity = 0.0;
    private double reachedS = -1.0;
    private double sum = 0.0;
    private int samples = 0;
    private String message = "";

    private boolean stepFeedforwardOnly = false;
    private double stepPeak = 0.0;
    private double stepRiseS = -1.0;
    private double stepLastOutOfBandS = 0.0;
    private double stepTailSum = 0.0;
    private int stepTailCount = 0;
    private String stepResult = "";
    private double mOvershootPct = 0.0;
    private double mErrPct = 0.0;
    private double mRiseS = -1.0;
    private boolean mSettled = false;

    private int autoStage = AUTO_OFF;
    private int autoIndex = 0;
    private double autoBestCost = Double.MAX_VALUE;
    private double autoBestValue = 0.0;

    private boolean pressed(int index, boolean down)
    {
        boolean result = down && !wasDown[index];
        wasDown[index] = down;
        return result;
    }

    private double approach(double current, double goal, double dt, double rampS)
    {
        if (rampS <= 0.0)
        {
            return goal;
        }
        double step = dt / rampS;
        if (current < goal)
        {
            return Math.min(goal, current + step);
        }
        return Math.max(goal, current - step);
    }

    private void stopRoller()
    {
        roller.raw(0.0);
        power = 0.0;
        cmdFraction = 0.0;
    }

    private void startMeasure()
    {
        running = false;
        phase = PHASE_KS;
        power = 0.0;
        message = "Measuring kS";
        phaseTimer.reset();
    }

    private void startStep(boolean feedforwardOnly)
    {
        running = false;
        stepFeedforwardOnly = feedforwardOnly;
        phase = PHASE_STEP_REST;
        phaseTimer.reset();
        stopRoller();
        message = feedforwardOnly ? "Step test (feedforward only): waiting for the roller to stop" : "Step test: waiting for the roller to stop";
    }

    private void startAuto()
    {
        autoStage = AUTO_MEASURE;
        stepResult = "";
        startMeasure();
        message = "Auto-tune: measuring kS and max speed";
    }

    private void cancelAll()
    {
        phase = PHASE_IDLE;
        running = false;
        autoStage = AUTO_OFF;
        stopRoller();
        message = "Stopped";
    }

    private double stepCost()
    {
        double cost = mOvershootPct * OVERSHOOT_WEIGHT + Math.abs(mErrPct) * ERROR_WEIGHT;
        if (mRiseS < 0.0)
        {
            cost += NEVER_RISE_COST;
        }
        else
        {
            cost += mRiseS * RISE_WEIGHT;
        }
        if (!mSettled)
        {
            cost += NOT_SETTLED_COST;
        }
        return cost;
    }

    private void afterMeasure()
    {
        if (autoStage != AUTO_MEASURE)
        {
            return;
        }
        if (g.maxTicks <= 0.0)
        {
            autoStage = AUTO_OFF;
            message = "Auto-tune stopped: could not measure max speed. Check the encoder.";
            return;
        }
        g.fraction = AUTO_TARGET_FRACTION;
        autoStage = AUTO_KP;
        autoIndex = 0;
        autoBestCost = Double.MAX_VALUE;
        autoBestValue = AUTO_KP_MULTIPLES[0] / g.maxTicks;
        g.kP = AUTO_KP_MULTIPLES[0] / g.maxTicks;
        g.kD = 0.0;
        startStep(false);
    }

    private void afterStep()
    {
        if (autoStage == AUTO_KP)
        {
            double cost = stepCost();
            if (cost < autoBestCost)
            {
                autoBestCost = cost;
                autoBestValue = g.kP;
            }
            autoIndex++;
            if (autoIndex < AUTO_KP_MULTIPLES.length)
            {
                g.kP = AUTO_KP_MULTIPLES[autoIndex] / g.maxTicks;
                g.kD = 0.0;
                startStep(false);
                return;
            }
            g.kP = autoBestValue;
            autoStage = AUTO_KD;
            autoIndex = 0;
            autoBestCost = Double.MAX_VALUE;
            autoBestValue = 0.0;
            g.kD = AUTO_KD_MULTIPLES[0] * AUTO_KD_UNIT / g.maxTicks;
            startStep(false);
            return;
        }
        if (autoStage == AUTO_KD)
        {
            double cost = stepCost();
            if (cost < autoBestCost)
            {
                autoBestCost = cost;
                autoBestValue = g.kD;
            }
            autoIndex++;
            if (autoIndex < AUTO_KD_MULTIPLES.length)
            {
                g.kD = AUTO_KD_MULTIPLES[autoIndex] * AUTO_KD_UNIT / g.maxTicks;
                startStep(false);
                return;
            }
            g.kD = autoBestValue;
            autoStage = AUTO_VERIFY;
            startStep(false);
            return;
        }
        if (autoStage == AUTO_VERIFY)
        {
            autoStage = AUTO_OFF;
            message = "Auto-tune done. Copy the values below. Press Y to run another step test, or tweak kP and kD by hand.";
        }
    }

    private String autoStatus()
    {
        if (autoStage == AUTO_MEASURE)
        {
            return "Auto-tune: measuring kS and max speed";
        }
        if (autoStage == AUTO_KP)
        {
            return String.format("Auto-tune: kP sweep %d of %d", autoIndex + 1, AUTO_KP_MULTIPLES.length);
        }
        if (autoStage == AUTO_KD)
        {
            return String.format("Auto-tune: kD sweep %d of %d", autoIndex + 1, AUTO_KD_MULTIPLES.length);
        }
        if (autoStage == AUTO_VERIFY)
        {
            return "Auto-tune: checking the final values";
        }
        return "";
    }

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);

        roller = createRoller();
        g = startingGains();
        ramp = rampTimeS();

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addLine(rollerName() + " PIDF Tuner - no balls, keep clear of the rollers");
            telemetry.addLine("Right trigger: AUTO-TUNE. Measures kS and max speed, then finds kP and kD by itself (about 40 seconds). Copy the values it prints.");
            telemetry.addLine("Or tune by hand:");
            telemetry.addLine("X: measure kS and max speed");
            telemetry.addLine("Y: step test with your kP and kD (rise time, overshoot, settle time, error)");
            telemetry.addLine("B: step test with feedforward only (kP and kD at 0)");
            telemetry.addLine("A: start / stop closed-loop at the target speed");
            telemetry.addLine("D-pad left/right: target speed.  D-pad up/down: kP.  Bumpers: kD");
            telemetry.addLine("Back: stop everything");
            telemetry.addLine("The roller needs an encoder plugged in. If velocity reads 0 there is none.");
            telemetry.update();
            idle();
        }

        while (opModeIsActive())
        {
            BulkReads.clear();
            if (roller == null || !roller.present())
            {
                telemetry.addData("Mechanism", rollerName());
                telemetry.addLine("Not found in the config.");
                telemetry.update();
                continue;
            }

            velocity = roller.velocity();
            double dt = loopTimer.seconds();
            loopTimer.reset();

            boolean xPressed = pressed(0, gamepad1.x);
            boolean aPressed = pressed(1, gamepad1.a);
            boolean upPressed = pressed(2, gamepad1.dpad_up);
            boolean downPressed = pressed(3, gamepad1.dpad_down);
            boolean rbPressed = pressed(4, gamepad1.right_bumper);
            boolean lbPressed = pressed(5, gamepad1.left_bumper);
            boolean rightPressed = pressed(6, gamepad1.dpad_right);
            boolean leftPressed = pressed(7, gamepad1.dpad_left);
            boolean backPressed = pressed(8, gamepad1.back);
            boolean yPressed = pressed(9, gamepad1.y);
            boolean bPressed = pressed(10, gamepad1.b);
            boolean autoPressed = pressed(11, gamepad1.right_trigger > TRIGGER_THRESHOLD);
            boolean gainChanged = false;

            if (backPressed)
            {
                cancelAll();
            }
            if (phase == PHASE_IDLE)
            {
                if (autoPressed)
                {
                    startAuto();
                }
                else if (xPressed)
                {
                    autoStage = AUTO_OFF;
                    startMeasure();
                }
                else if (yPressed || bPressed)
                {
                    if (g.maxTicks <= 0.0)
                    {
                        message = "Press X first to measure max speed";
                    }
                    else
                    {
                        stepResult = "";
                        startStep(bPressed);
                    }
                }
                else if (aPressed)
                {
                    running = !running;
                    if (running)
                    {
                        cmdFraction = 0.0;
                        controller.reset();
                        peakVelocity = 0.0;
                        reachedS = -1.0;
                        runTimer.reset();
                        message = g.maxTicks > 0.0 ? "" : "Press X first to measure max speed";
                    }
                    else
                    {
                        stopRoller();
                    }
                }
            }
            if (upPressed)
            {
                g.kP += KP_STEP;
                gainChanged = true;
            }
            if (downPressed)
            {
                g.kP = Math.max(0.0, g.kP - KP_STEP);
                gainChanged = true;
            }
            if (rbPressed)
            {
                g.kD += KD_STEP;
                gainChanged = true;
            }
            if (lbPressed)
            {
                g.kD = Math.max(0.0, g.kD - KD_STEP);
                gainChanged = true;
            }
            if (rightPressed)
            {
                g.fraction = Math.min(1.0, g.fraction + FRACTION_STEP);
                gainChanged = true;
            }
            if (leftPressed)
            {
                g.fraction = Math.max(0.05, g.fraction - FRACTION_STEP);
                gainChanged = true;
            }
            if (gainChanged && running)
            {
                peakVelocity = 0.0;
                reachedS = -1.0;
                runTimer.reset();
            }

            if (phase == PHASE_STEP_REST)
            {
                roller.raw(0.0);
                if (Math.abs(velocity) < STEP_REST_TICKS_PER_SEC || phaseTimer.seconds() >= STEP_REST_MAX_S)
                {
                    phase = PHASE_STEP_RUN;
                    phaseTimer.reset();
                    controller.reset();
                    cmdFraction = 0.0;
                    stepPeak = 0.0;
                    stepRiseS = -1.0;
                    stepLastOutOfBandS = 0.0;
                    stepTailSum = 0.0;
                    stepTailCount = 0;
                    message = stepFeedforwardOnly ? "Step test (feedforward only) running" : "Step test running";
                }
            }
            else if (phase == PHASE_STEP_RUN)
            {
                double finalTarget = g.fraction * g.maxTicks;
                double t = phaseTimer.seconds();
                if (dt >= MIN_DT_S)
                {
                    cmdFraction = approach(cmdFraction, g.fraction, dt, ramp);
                    if (stepFeedforwardOnly)
                    {
                        controller.setGains(g.kS, g.maxTicks, 0.0, 0.0);
                    }
                    else
                    {
                        controller.setGains(g.kS, g.maxTicks, g.kP, g.kD);
                    }
                    power = controller.calculate(cmdFraction * g.maxTicks, velocity, dt);
                    roller.raw(power);

                    double f = controller.getFilteredVelocity();
                    stepPeak = Math.max(stepPeak, f);
                    if (stepRiseS < 0.0 && f >= RISE_FRACTION * finalTarget)
                    {
                        stepRiseS = t;
                    }
                    if (Math.abs(f - finalTarget) > SETTLE_BAND * finalTarget)
                    {
                        stepLastOutOfBandS = t;
                    }
                    if (t >= STEP_RUN_S - STEP_TAIL_S)
                    {
                        stepTailSum += f;
                        stepTailCount++;
                    }
                }
                if (t >= STEP_RUN_S)
                {
                    stopRoller();
                    phase = PHASE_IDLE;
                    double steady = stepTailCount > 0 ? stepTailSum / stepTailCount : 0.0;
                    mOvershootPct = finalTarget > 0.0 ? Math.max(0.0, (stepPeak - finalTarget) / finalTarget * 100.0) : 0.0;
                    double errorTicks = steady - finalTarget;
                    mErrPct = finalTarget > 0.0 ? errorTicks / finalTarget * 100.0 : 0.0;
                    mRiseS = stepRiseS;
                    mSettled = stepLastOutOfBandS < STEP_RUN_S - STEP_TAIL_S;
                    String rise = mRiseS < 0.0 ? "never reached 90%" : String.format("%.2f s to 90%%", mRiseS);
                    String settle = mSettled ? String.format("settled in %.2f s", stepLastOutOfBandS) : "did not settle within 5%";
                    stepResult = String.format("%s: rise %s, overshoot %.1f%%, %s, steady speed %.0f (%+.0f ticks/s, %+.1f%% from target)",
                            stepFeedforwardOnly ? "FEEDFORWARD ONLY" : "WITH kP/kD", rise, mOvershootPct, settle, steady, errorTicks, mErrPct);
                    message = "Step test done";
                    afterStep();
                }
            }
            else if (phase == PHASE_KS)
            {
                power += KS_RAMP_PER_S * dt;
                roller.raw(power);
                if (Math.abs(velocity) > MOVE_TICKS_PER_SEC)
                {
                    g.kS = power;
                    phase = PHASE_MAX;
                    phaseTimer.reset();
                    sum = 0.0;
                    samples = 0;
                    message = "Measuring max speed";
                }
                else if (power >= KS_GIVE_UP_POWER)
                {
                    stopRoller();
                    phase = PHASE_IDLE;
                    autoStage = AUTO_OFF;
                    message = "No movement seen. Check the encoder is plugged in and the motor runs.";
                }
            }
            else if (phase == PHASE_MAX)
            {
                power = 1.0;
                roller.raw(1.0);
                if (phaseTimer.seconds() >= SETTLE_S)
                {
                    sum += velocity;
                    samples++;
                }
                if (phaseTimer.seconds() >= SETTLE_S + MEASURE_S)
                {
                    stopRoller();
                    phase = PHASE_IDLE;
                    double measured = samples > 0 ? sum / samples : 0.0;
                    if (measured > 0.0)
                    {
                        g.maxTicks = measured;
                        message = "Done. Max speed measured.";
                    }
                    else
                    {
                        message = "Max speed read zero or negative. The encoder may be reversed or missing.";
                    }
                    afterMeasure();
                }
            }
            else if (running && g.maxTicks > 0.0 && dt >= MIN_DT_S)
            {
                controller.setGains(g.kS, g.maxTicks, g.kP, g.kD);
                double target = g.fraction * g.maxTicks;
                cmdFraction = approach(cmdFraction, g.fraction, dt, ramp);
                power = controller.calculate(cmdFraction * g.maxTicks, velocity, dt);
                roller.raw(power);
                peakVelocity = Math.max(peakVelocity, controller.getFilteredVelocity());
                if (reachedS < 0.0 && Math.abs(target - controller.getFilteredVelocity()) <= REACHED_FRACTION * target)
                {
                    reachedS = runTimer.seconds();
                }
            }

            showTelemetry();
        }

        if (roller != null && roller.present())
        {
            roller.raw(0.0);
        }
    }

    private void showTelemetry()
    {
        double target = g.fraction * g.maxTicks;
        String mode = "stopped";
        if (phase == PHASE_KS)
        {
            mode = "measuring kS";
        }
        else if (phase == PHASE_MAX)
        {
            mode = "measuring max speed";
        }
        else if (phase == PHASE_STEP_REST)
        {
            mode = "step test: waiting for rest";
        }
        else if (phase == PHASE_STEP_RUN)
        {
            mode = stepFeedforwardOnly ? "step test: feedforward only" : "step test";
        }
        else if (running)
        {
            mode = "closed-loop";
        }
        telemetry.addData("Mechanism", rollerName());
        telemetry.addData("Mode", mode);
        if (autoStage != AUTO_OFF)
        {
            telemetry.addLine(autoStatus());
        }
        if (!message.isEmpty())
        {
            telemetry.addLine(message);
        }
        telemetry.addData("Battery", "%.2f V", hardwareMap.voltageSensor.iterator().next().getVoltage());
        telemetry.addData("Target", "%.0f ticks/s (%.0f%% of max)", target, g.fraction * 100.0);
        telemetry.addData("Velocity", "%.0f ticks/s", velocity);
        telemetry.addData("Error", "%.0f ticks/s", target - velocity);
        telemetry.addData("Motor power", "%.3f", power);
        if (running && reachedS >= 0.0)
        {
            telemetry.addData("Time to reach target", "%.2f s", reachedS);
        }
        if (running && target > 0.0)
        {
            telemetry.addData("Overshoot", "%.1f %%", Math.max(0.0, (peakVelocity - target) / target * 100.0));
        }
        if (!stepResult.isEmpty())
        {
            telemetry.addLine(stepResult);
        }
        telemetry.addData("kS", "%.4f", g.kS);
        telemetry.addData("Max speed", "%.0f ticks/s", g.maxTicks);
        telemetry.addData("kP", "%.5f", g.kP);
        telemetry.addData("kD", "%.6f", g.kD);
        telemetry.addLine("Copy into " + fileName() + ":");
        telemetry.addLine(String.format("%s_KS = %.4f", constantPrefix(), g.kS));
        telemetry.addLine(String.format("%s_MAX_TICKS_PER_SEC = %.0f", constantPrefix(), g.maxTicks));
        telemetry.addLine(String.format("%s_KP = %.5f", constantPrefix(), g.kP));
        telemetry.addLine(String.format("%s_KD = %.6f", constantPrefix(), g.kD));
        telemetry.update();
    }
}
