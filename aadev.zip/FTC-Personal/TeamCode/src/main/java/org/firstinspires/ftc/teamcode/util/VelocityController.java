package org.firstinspires.ftc.teamcode.util;

public class VelocityController
{
    private static final double VELOCITY_FILTER = 0.3;
    private static final double MIN_DT_S = 0.005;
    private static final double MAX_DT_S = 0.1;

    private double kS;
    private double maxTicksPerSec;
    private double kP;
    private double kD;

    private double filtered = 0.0;
    private double lastOutput = 0.0;
    private boolean started = false;

    public VelocityController(double kS, double maxTicksPerSec, double kP, double kD)
    {
        setGains(kS, maxTicksPerSec, kP, kD);
    }

    public void setGains(double kS, double maxTicksPerSec, double kP, double kD)
    {
        this.kS = kS;
        this.maxTicksPerSec = maxTicksPerSec;
        this.kP = kP;
        this.kD = kD;
    }

    public double getKs()
    {
        return kS;
    }

    public double getMaxTicksPerSec()
    {
        return maxTicksPerSec;
    }

    public double getKp()
    {
        return kP;
    }

    public double getKd()
    {
        return kD;
    }

    public double getFilteredVelocity()
    {
        return filtered;
    }

    public void reset()
    {
        started = false;
        filtered = 0.0;
        lastOutput = 0.0;
    }

    public double calculate(double targetTicksPerSec, double measuredTicksPerSec, double dtSeconds)
    {
        if (targetTicksPerSec == 0.0 || maxTicksPerSec <= 0.0)
        {
            reset();
            return 0.0;
        }

        double acceleration = 0.0;
        if (!started)
        {
            started = true;
            filtered = measuredTicksPerSec;
        }
        else
        {
            if (dtSeconds < MIN_DT_S)
            {
                return lastOutput;
            }
            double dt = Math.min(dtSeconds, MAX_DT_S);
            double previous = filtered;
            filtered = previous + VELOCITY_FILTER * (measuredTicksPerSec - previous);
            acceleration = (filtered - previous) / dt;
        }

        double sign = Math.signum(targetTicksPerSec);
        double kV = (1.0 - kS) / maxTicksPerSec;
        double power = sign * kS + kV * targetTicksPerSec + kP * (targetTicksPerSec - filtered) - kD * acceleration;
        power = Math.max(-1.0, Math.min(1.0, power));
        if (sign > 0.0)
        {
            power = Math.max(0.0, power);
        }
        else
        {
            power = Math.min(0.0, power);
        }
        lastOutput = power;
        return power;
    }
}
