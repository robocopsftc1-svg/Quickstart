package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.robot.Robot;
import org.firstinspires.ftc.teamcode.util.BulkReads;

import java.util.ArrayList;

@TeleOp(name = "Shooter Distance Tuner", group = "Tuning")
public class ShooterDistanceTuner extends LinearOpMode
{
    private static final double FRACTION_STEP = 0.01;
    private static final double DISTANCE_STEP_IN = 6.0;
    private static final double TRIGGER_THRESHOLD = 0.5;
    private static final int MAX_LISTED_HITS = 6;

    private final ArrayList<double[]> hits = new ArrayList<>();

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);
        Robot robot = new Robot(hardwareMap);

        double fraction = Shooter.SHOOTER_SPEED_FRACTION;
        double distance = 72.0;
        boolean upWas = false;
        boolean downWas = false;
        boolean leftWas = false;
        boolean rightWas = false;
        boolean triggerWas = false;
        boolean aWas = false;
        boolean bWas = false;
        boolean xWas = false;
        double lastShotDistance = Double.NaN;
        double lastShotFraction = Double.NaN;

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addData("Shooter", robot.shooterStatus);
            telemetry.addData("Intake", robot.intakeStatus);
            telemetry.addLine("Put the robot a known distance from the hive. Left/right = distance, up/down = speed, right trigger = shoot, right bumper = intake, left bumper = outtake. After a shot that scores press A to log it, B removes the last logged shot, X clears the log.");
            telemetry.update();
            idle();
        }

        while (opModeIsActive())
        {
            BulkReads.clear();
            if (robot.shooter == null || robot.shootingCycle == null)
            {
                telemetry.addLine("Needs the shooter and intake in the config");
                telemetry.update();
                continue;
            }

            if (gamepad1.dpad_up && !upWas)
            {
                fraction += FRACTION_STEP;
            }
            if (gamepad1.dpad_down && !downWas)
            {
                fraction -= FRACTION_STEP;
            }
            if (gamepad1.dpad_right && !rightWas)
            {
                distance += DISTANCE_STEP_IN;
            }
            if (gamepad1.dpad_left && !leftWas)
            {
                distance -= DISTANCE_STEP_IN;
            }
            upWas = gamepad1.dpad_up;
            downWas = gamepad1.dpad_down;
            rightWas = gamepad1.dpad_right;
            leftWas = gamepad1.dpad_left;
            fraction = Math.max(0.0, Math.min(Shooter.MAX_SPEED_FRACTION, fraction));

            robot.shooter.setTargetFraction(fraction);

            boolean trigger = gamepad1.right_trigger > TRIGGER_THRESHOLD;
            if (trigger && !triggerWas)
            {
                if (robot.shootingCycle.isRunning())
                {
                    robot.shootingCycle.cancel();
                }
                else
                {
                    robot.shootingCycle.start(0.0);
                    lastShotDistance = distance;
                    lastShotFraction = fraction;
                }
            }
            triggerWas = trigger;

            if (gamepad1.a && !aWas && !Double.isNaN(lastShotDistance))
            {
                hits.add(new double[] {lastShotDistance, lastShotFraction});
                lastShotDistance = Double.NaN;
            }
            if (gamepad1.b && !bWas && !hits.isEmpty())
            {
                hits.remove(hits.size() - 1);
            }
            if (gamepad1.x && !xWas)
            {
                hits.clear();
            }
            aWas = gamepad1.a;
            bWas = gamepad1.b;
            xWas = gamepad1.x;

            robot.control(gamepad1.right_bumper, gamepad1.left_bumper, robot.intake);
            robot.shootingCycle.update();

            telemetry.addData("Distance from hive", "%.0f in", distance);
            telemetry.addData("Speed fraction", "%.2f", fraction);
            telemetry.addData("Target", "%.0f ticks/s", robot.shooter.getTargetTicksPerSec());
            telemetry.addData("Actual", "%.0f ticks/s", robot.shooter.getVelocityTicksPerSec());
            telemetry.addData("Shot cycle", robot.shootingCycle.getState());
            telemetry.addData("Table row if it scores", "{%.0f, %.2f}", distance, fraction);
            showFit(distance);
            telemetry.update();
        }

        robot.stopMechanisms();
    }

    private void showFit(double currentDistance)
    {
        telemetry.addData("Shots logged (A = scored)", hits.size());
        int start = Math.max(0, hits.size() - MAX_LISTED_HITS);
        for (int i = start; i < hits.size(); i++)
        {
            double[] hit = hits.get(i);
            telemetry.addData("  Shot " + (i + 1), "%.0f in at speed %.2f", hit[0], hit[1]);
        }
        if (hits.isEmpty())
        {
            return;
        }

        double meanD = 0.0;
        double meanF = 0.0;
        double minD = Double.MAX_VALUE;
        double maxD = -Double.MAX_VALUE;
        for (double[] hit : hits)
        {
            meanD += hit[0];
            meanF += hit[1];
            minD = Math.min(minD, hit[0]);
            maxD = Math.max(maxD, hit[0]);
        }
        meanD /= hits.size();
        meanF /= hits.size();

        double sxx = 0.0;
        double sxy = 0.0;
        for (double[] hit : hits)
        {
            sxx += (hit[0] - meanD) * (hit[0] - meanD);
            sxy += (hit[0] - meanD) * (hit[1] - meanF);
        }

        double slope = 0.0;
        if (sxx > 1.0)
        {
            slope = sxy / sxx;
        }
        double nearFraction = clampFraction(meanF + slope * (minD - meanD));
        double farFraction = clampFraction(meanF + slope * (maxD - meanD));
        if (maxD - minD < 1.0)
        {
            nearFraction = clampFraction(meanF);
            farFraction = nearFraction;
            maxD = minD + 1.0;
        }

        double worst = 0.0;
        for (double[] hit : hits)
        {
            worst = Math.max(worst, Math.abs(hit[1] - (meanF + slope * (hit[0] - meanD))));
        }

        telemetry.addData("Fitted speed at this distance", "%.2f", clampFraction(meanF + slope * (currentDistance - meanD)));
        telemetry.addData("Worst miss from the line", "%.3f", worst);
        telemetry.addData("Copy into Shooter.java SHOT_DISTANCES_IN", "{%.0f, %.0f}", minD, maxD);
        telemetry.addData("Copy into Shooter.java SHOT_FRACTIONS", "{%.2f, %.2f}", nearFraction, farFraction);
        if (hits.size() < 3 || maxD - minD < 12.0)
        {
            telemetry.addLine("Log scoring shots from at least 3 spots, spread over 12+ inches, for a good line.");
        }
    }

    private double clampFraction(double value)
    {
        return Math.max(0.0, Math.min(Shooter.MAX_SPEED_FRACTION, value));
    }
}
