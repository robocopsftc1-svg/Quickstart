package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.robot.Robot;
import org.firstinspires.ftc.teamcode.util.BulkReads;

@TeleOp(name = "Shooter Power Tuner", group = "Tuning")
public class ShooterPowerTuner extends LinearOpMode
{
    private static final double FLYWHEEL_STEP = 0.01;
    private static final double COUNTER_STEP = 0.01;
    private static final double TRIGGER_THRESHOLD = 0.5;

    private final boolean[] wasDown = new boolean[6];

    private boolean pressed(int index, boolean down)
    {
        boolean result = down && !wasDown[index];
        wasDown[index] = down;
        return result;
    }

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);
        Robot robot = new Robot(hardwareMap);

        double flywheel = Shooter.SHOOTER_SPEED_FRACTION;
        double counter = Shooter.COUNTER_ROLLER_POWER;
        boolean running = false;

        while (!isStarted() && !isStopRequested())
        {
            telemetry.addData("Shooter", robot.shooterStatus);
            telemetry.addData("Intake", robot.intakeStatus);
            telemetry.addLine("A: start / stop the flywheel and counter rollers");
            telemetry.addLine("D-pad up/down: flywheel speed (fraction of max)");
            telemetry.addLine("Bumpers: right = counter roller power up, left = down");
            telemetry.addLine("Right trigger (hold): open the gate and run the intake to feed");
            telemetry.addLine("Copy the values into SHOOTER_SPEED_FRACTION and COUNTER_ROLLER_POWER in Shooter.java");
            telemetry.update();
            idle();
        }

        while (opModeIsActive())
        {
            BulkReads.clear();
            if (robot.shooter == null)
            {
                telemetry.addLine("shooter_driver motor not found in the config");
                telemetry.update();
                continue;
            }

            if (pressed(0, gamepad1.a))
            {
                running = !running;
                if (!running)
                {
                    robot.shooter.stopShooter();
                }
            }
            if (pressed(1, gamepad1.dpad_up))
            {
                flywheel += FLYWHEEL_STEP;
            }
            if (pressed(2, gamepad1.dpad_down))
            {
                flywheel -= FLYWHEEL_STEP;
            }
            if (pressed(3, gamepad1.right_bumper))
            {
                counter += COUNTER_STEP;
            }
            if (pressed(4, gamepad1.left_bumper))
            {
                counter -= COUNTER_STEP;
            }
            flywheel = Math.max(0.0, Math.min(Shooter.MAX_SPEED_FRACTION, flywheel));
            counter = Math.max(0.0, Math.min(1.0, counter));

            robot.shooter.setTargetFraction(flywheel);
            robot.shooter.setCounterPower(counter);

            if (running)
            {
                robot.shooter.shoot();
                robot.shooter.update();
            }

            boolean feeding = running && gamepad1.right_trigger > TRIGGER_THRESHOLD;
            if (feeding)
            {
                if (robot.gate != null)
                {
                    robot.gate.open();
                }
                if (robot.intake != null)
                {
                    robot.intake.in();
                }
            }
            else
            {
                if (robot.gate != null)
                {
                    robot.gate.close();
                }
                if (robot.intake != null)
                {
                    robot.intake.stop();
                }
            }

            telemetry.addData("Mode", running ? "running" : "stopped");
            telemetry.addData("Feeding", feeding ? "yes" : "no");
            telemetry.addData("Flywheel speed", "%.2f of max", flywheel);
            telemetry.addData("Flywheel target", "%.0f ticks/s", robot.shooter.getTargetTicksPerSec());
            telemetry.addData("Flywheel actual", "%.0f ticks/s (%.0f rpm)", robot.shooter.getVelocityTicksPerSec(), robot.shooter.getRpm());
            telemetry.addData("Flywheel motor power", "%.2f", robot.shooter.getShooterPower());
            telemetry.addData("Counter roller power", "%.2f%s", counter, robot.shooter.hasCounterRoller() ? "" : " (no counter roller in the config)");
            telemetry.addData("Copy", "SHOOTER_SPEED_FRACTION = %.2f, COUNTER_ROLLER_POWER = %.2f", flywheel, counter);
            telemetry.update();
        }

        robot.stopMechanisms();
    }
}
