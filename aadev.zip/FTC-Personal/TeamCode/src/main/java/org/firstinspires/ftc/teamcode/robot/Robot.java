package org.firstinspires.ftc.teamcode.robot;

import static com.pedropathing.api.Paths.curve;
import static com.pedropathing.api.Paths.line;
import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.commands.Commands.waitUntil;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.pedropathing.follower.Follower;
import com.pedropathing.ivy.Command;
import com.pedropathing.math.Pose;
import com.pedropathing.paths.Path;
import com.pedropathing.paths.interpolator.Interpolator;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.teamcode.config.DriveConfig;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Gate;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.ShootingCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.FlowerCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;
import org.firstinspires.ftc.teamcode.pedro.Constants;
import org.firstinspires.ftc.teamcode.util.HiveRoutePlanner;
import org.firstinspires.ftc.teamcode.util.LoopTimer;
import org.firstinspires.ftc.teamcode.util.MatchHandoff;
import org.firstinspires.ftc.teamcode.util.MecanumWheelPowers;
import org.firstinspires.ftc.teamcode.util.LimelightRelocalizer;
import org.firstinspires.ftc.teamcode.util.PinpointPose;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

public class Robot
{
    public static final double PATH_TIMEOUT_S = 8.0;
    public static final double HIVE_AVOID_BLEND_IN = 6.0;

    private static final double MAX_POWER_CHANGE_PER_S = 30.0;
    private static final double MAX_DECEL_PER_S = 40.0;
    private static final double STICK_CURVE = 0.2;
    public static final double MANUAL_TURRET_POWER = 0.35;

    public static final boolean AUTO_RELOCALIZE = false;
    public static final double RELOCALIZE_PERIOD_S = 0.1;
    public static final double RELOCALIZE_BLEND = 0.2;
    public static final double RELOCALIZE_MAX_JUMP_IN = 36.0;
    public static final double RELOCALIZE_MAX_DRIVE_POWER = 0.5;
    public static final double MANUAL_TURRET_RIGHT_SIGN = 1.0;
    private static final double MAX_RAMP_DT_S = 0.1;
    private static final double LOOP_WORST_RESET_S = 2.0;
    private static final double CORNER_FIX_HOLD_S = 0.25;
    private static final double CORNER_FIELD_IN = 144.0;
    private static final double CORNER_SIDE_IN = 9.0;
    private static final double CORNER_BACK_IN = 8.0;
    private static final double TELEOP_LENGTH_S = 120.0;
    private static final double FLOWERS_OPEN_REMAINING_S = 60.0;
    private static final double FINAL_WARNING_REMAINING_S = 30.0;

    private static final String OK = "OK";
    private static final String UNAVAILABLE = "NOT AVAILABLE - ";

    public final DcMotor frontLeft;
    public final DcMotor backLeft;
    public final DcMotor frontRight;
    public final DcMotor backRight;

    public Intake intake;
    public Shooter shooter;
    public Gate gate;
    public Sweeper sweeper;
    public TurretTracker turret;
    public ShootingCycle shootingCycle;
    public FlowerCycle flowerCycle;
    public Follower follower;

    private final HardwareMap hardwareMap;
    private boolean following = false;
    private final Map<Path, Pose> pathEnds = new IdentityHashMap<>();
    private final Map<Path, String> pathInfo = new IdentityHashMap<>();
    private String activePath = "none";
    private final ElapsedTime revTimer = new ElapsedTime();
    private boolean revving = false;
    private boolean autoTrack = true;
    private boolean halted = false;
    private boolean turretActive = false;
    private boolean manualTurret = false;
    private LimelightRelocalizer relocalizer = null;
    private final ElapsedTime relocalizeTimer = new ElapsedTime();
    private int relocalizeCount = 0;
    private int relocalizeRejected = 0;
    private double relocalizeLastDiffIn = 0.0;
    private double manualTurretPower = 0.0;
    private boolean teleOpMode = false;
    private Gamepad pad;
    public PinpointPose pinpointPose;
    private boolean handoffUsed = false;
    private boolean allianceKnown = false;
    private boolean blueAlliance = false;
    private double remaining = TELEOP_LENGTH_S;
    private final ElapsedTime runtime = new ElapsedTime();
    private final ElapsedTime driveTimer = new ElapsedTime();
    private final ElapsedTime cornerTimer = new ElapsedTime();
    private final ElapsedTime flywheelTimer = new ElapsedTime();
    private final LoopTimer loopTimer = new LoopTimer();
    private boolean worstReset = false;
    private boolean flowersWarned = false;
    private boolean finalWarned = false;
    private boolean cornerHolding = false;
    private boolean cornerFired = false;
    private String cornerText = "none yet - hold X with the robot in the corner";
    private boolean flywheelLatched = false;
    private boolean cycleButtonWasDown = false;
    private boolean gateButtonWasDown = false;
    private boolean sweeperButtonWasDown = false;
    private boolean cycleWasRunning = false;
    private boolean shooting = false;
    private double frontLeftPower;
    private double frontRightPower;
    private double backLeftPower;
    private double backRightPower;
    private double lastFrontLeftWrite = Double.NaN;
    private double lastFrontRightWrite = Double.NaN;
    private double lastBackLeftWrite = Double.NaN;
    private double lastBackRightWrite = Double.NaN;
    private boolean sweeperActive = false;

    public String followerStatus = "not created";
    public String intakeStatus = OK;
    public String shooterStatus = OK;
    public String gateStatus = OK;
    public String sweeperStatus = OK;
    public String turretStatus = OK;

    public Robot(HardwareMap hardwareMap)
    {
        this.hardwareMap = hardwareMap;
        frontLeft  = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_LEFT);
        backLeft   = hardwareMap.get(DcMotor.class, HardwareNames.BACK_LEFT);
        frontRight = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_RIGHT);
        backRight  = hardwareMap.get(DcMotor.class, HardwareNames.BACK_RIGHT);
        DriveConfig.apply(frontLeft, backLeft, frontRight, backRight);

        intake = null;
        try
        {
            intake = new Intake(hardwareMap);
        }
        catch (Exception e)
        {
            intake = null;
            intakeStatus = UNAVAILABLE + e.getMessage();
        }

        shooter = null;
        try
        {
            shooter = new Shooter(hardwareMap);
        }
        catch (Exception e)
        {
            shooter = null;
            shooterStatus = UNAVAILABLE + e.getMessage();
        }

        gate = null;
        try
        {
            gate = new Gate(hardwareMap);
        }
        catch (Exception e)
        {
            gate = null;
            gateStatus = UNAVAILABLE + e.getMessage();
        }

        turret = null;
        try
        {
            turret = new TurretTracker(hardwareMap);
        }
        catch (Exception e)
        {
            turret = null;
            turretStatus = UNAVAILABLE + e.getMessage();
        }

        sweeper = null;
        try
        {
            sweeper = new Sweeper(hardwareMap);
        }
        catch (Exception e)
        {
            sweeper = null;
            sweeperStatus = UNAVAILABLE + e.getMessage();
        }

        shootingCycle = null;
        if (shooter != null && intake != null)
        {
            shootingCycle = new ShootingCycle(shooter, intake, gate);
            shootingCycle.setTurret(turret);
            shootingCycle.setKeepFlywheelOn(true);
        }

        flowerCycle = null;
        if (sweeper != null && intake != null)
        {
            flowerCycle = new FlowerCycle(sweeper, intake);
        }
    }

    public Follower createFollower()
    {
        if (follower != null)
        {
            return follower;
        }
        try
        {
            follower = Constants.create(hardwareMap);
            followerStatus = OK;
        }
        catch (Exception e)
        {
            follower = null;
            followerStatus = UNAVAILABLE + e.getMessage();
        }
        if (follower != null)
        {
            setPoseSource(() ->
            {
                Pose current = follower.pose();
                return new double[] {current.x(), current.y(), current.heading()};
            });
        }
        return follower;
    }

    public String getFollowerStatus()
    {
        return followerStatus;
    }

    public boolean hasFollower()
    {
        return follower != null;
    }

    public void setStartPose(Pose pose)
    {
        if (follower != null)
        {
            follower.setPose(pose);
            follower.update();
        }
    }

    public Pose getPose()
    {
        if (follower == null)
        {
            return null;
        }
        return follower.pose();
    }

    public void updateFollower()
    {
        if (follower != null && following)
        {
            follower.update();
        }
    }

    public void stopFollowing()
    {
        following = false;
    }

    public Path createPath(Pose start, Pose end)
    {
        Path path = line(start, end).heading(headingProfile(start, end));
        pathEnds.put(path, end);
        double length = Math.hypot(end.x() - start.x(), end.y() - start.y());
        pathInfo.put(path, String.format("line (%.1f, %.1f) to (%.1f, %.1f), %.1f in", start.x(), start.y(), end.x(), end.y(), length));
        return path;
    }

    public Path createPath(Pose start, Pose control, Pose end)
    {
        Path path = curve(start, control, end).heading(headingProfile(start, end));
        pathEnds.put(path, end);
        pathInfo.put(path, String.format("curve (%.1f, %.1f) via (%.1f, %.1f) to (%.1f, %.1f), %.1f in",
                start.x(), start.y(), control.x(), control.y(), end.x(), end.y(), curveLength(start, control, end)));
        return path;
    }

    public Command executePath(Path path)
    {
        return executePath(path, 0.0);
    }

    public Command executePath(Path path, double blendIn)
    {
        Pose end = pathEnds.get(path);
        if (end == null)
        {
            throw new IllegalArgumentException("executePath needs a path made by createPath");
        }
        String info = pathInfo.get(path);
        return sequential(
                instant(() -> activePath = info),
                driveCommand(path, end, blendIn));
    }

    private static double curveLength(Pose start, Pose control, Pose end)
    {
        final int steps = 24;
        double length = 0.0;
        double previousX = start.x();
        double previousY = start.y();
        for (int i = 1; i <= steps; i++)
        {
            double t = (double) i / steps;
            double u = 1.0 - t;
            double x = u * u * start.x() + 2.0 * u * t * control.x() + t * t * end.x();
            double y = u * u * start.y() + 2.0 * u * t * control.y() + t * t * end.y();
            length += Math.hypot(x - previousX, y - previousY);
            previousX = x;
            previousY = y;
        }
        return length;
    }

    private static Interpolator headingProfile(Pose start, Pose end)
    {
        double delta = end.heading() - start.heading();
        while (delta > Math.PI)
        {
            delta -= 2.0 * Math.PI;
        }
        while (delta <= -Math.PI)
        {
            delta += 2.0 * Math.PI;
        }
        return Interpolator.linear(start.heading(), start.heading() + delta);
    }

    public Command followPath(Pose start, Pose end, boolean collect, boolean shoot)
    {
        createFollower();
        return pathSteps(createPath(start, end), collect, shoot);
    }

    public Command followPath(Pose start, Pose control, Pose end, boolean collect, boolean shoot)
    {
        createFollower();
        return pathSteps(createPath(start, control, end), collect, shoot);
    }

    // Same as followPath(start, end, ...) but the route bends around the hive when the straight line would hit it.
    // If the start or end is too close to the hive to plan around it, this drives the straight line like before.
    public Command followPathAvoidingHive(Pose start, Pose end, boolean collect, boolean shoot)
    {
        List<double[]> via = HiveRoutePlanner.waypoints(start.x(), start.y(), end.x(), end.y());
        if (via == null || via.isEmpty())
        {
            return followPath(start, end, collect, shoot);
        }
        createFollower();

        double total = HiveRoutePlanner.routeLength(start.x(), start.y(), end.x(), end.y(), via);
        double turn = end.heading() - start.heading();
        while (turn > Math.PI)
        {
            turn -= 2.0 * Math.PI;
        }
        while (turn <= -Math.PI)
        {
            turn += 2.0 * Math.PI;
        }

        List<Command> steps = new ArrayList<>();
        if (collect)
        {
            steps.add(intakeOn());
        }
        if (shoot)
        {
            steps.add(rev());
        }
        Pose from = start;
        double travelled = 0.0;
        for (int i = 0; i <= via.size(); i++)
        {
            Pose to = end;
            double blend = 0.0;
            if (i < via.size())
            {
                double[] point = via.get(i);
                travelled += Math.hypot(point[0] - from.x(), point[1] - from.y());
                double fraction = total > 0.0 ? travelled / total : 1.0;
                to = new Pose(point[0], point[1], start.heading() + turn * fraction);
                blend = HIVE_AVOID_BLEND_IN;
            }
            steps.add(executePath(createPath(from, to), blend).raceWith(waitMs(PATH_TIMEOUT_S * 1000.0)));
            from = to;
        }
        if (collect)
        {
            steps.add(intakeOff());
        }
        if (shoot)
        {
            steps.add(launch());
        }
        return sequential(steps.toArray(new Command[0]));
    }

    private Command pathSteps(Path path, boolean collect, boolean shoot)
    {
        List<Command> steps = new ArrayList<>();
        if (collect)
        {
            steps.add(intakeOn());
        }
        if (shoot)
        {
            steps.add(rev());
        }
        steps.add(executePath(path).raceWith(waitMs(PATH_TIMEOUT_S * 1000.0)));
        if (collect)
        {
            steps.add(intakeOff());
        }
        if (shoot)
        {
            steps.add(launch());
        }
        return sequential(steps.toArray(new Command[0]));
    }

    public Command intakeOn()
    {
        return instant(() ->
        {
            if (intake != null)
            {
                intake.in();
            }
        });
    }

    public Command intakeOff()
    {
        return instant(() ->
        {
            if (intake != null)
            {
                intake.stop();
            }
        });
    }

    public Command rev()
    {
        return instant(() ->
        {
            if (!revving && shooter != null)
            {
                shooter.shoot();
                revTimer.reset();
                revving = true;
            }
        });
    }

    public Command shooterOff()
    {
        return instant(() ->
        {
            revving = false;
            if (shooter != null)
            {
                shooter.stopShooter();
            }
        });
    }

    public Command launch()
    {
        if (shootingCycle == null)
        {
            return instant(() ->
            {
            });
        }
        return sequential(
                instant(() ->
                {
                    double spinningS = 0.0;
                    if (revving)
                    {
                        spinningS = revTimer.seconds();
                    }
                    revving = false;
                    shootingCycle.start(spinningS);
                }),
                waitUntil(() -> shootingCycle.isDone()));
    }

    public void setAutoTrack(boolean enabled)
    {
        autoTrack = enabled;
    }

    public boolean isAutoTrack()
    {
        return autoTrack;
    }

    public void haltAuto()
    {
        halted = true;
        following = false;
        revving = false;
        turretActive = false;
        sweeperActive = false;
    }

    public Command driveCommand(Path path, Pose endPose, double blendIn)
    {
        return Command.build()
                .setStart(() ->
                {
                    following = true;
                    follower.follow(path);
                })
                .setDone(() ->
                {
                    if (follower.atParametricEnd())
                    {
                        return true;
                    }
                    if (blendIn <= 0.0)
                    {
                        return false;
                    }
                    return Math.hypot(follower.pose().x() - endPose.x(), follower.pose().y() - endPose.y()) <= blendIn;
                })
                .setEnd(condition ->
                {
                    following = true;
                    follower.hold(endPose);
                });
    }

    public boolean hasIntake()
    {
        return intake != null;
    }

    public boolean hasShooter()
    {
        return shooter != null;
    }

    public boolean hasTurret()
    {
        return turret != null;
    }

    public boolean hasSweeper()
    {
        return sweeper != null;
    }

    public boolean canLaunch()
    {
        return shootingCycle != null;
    }

    public void setAlliance(boolean blue)
    {
        if (turret != null)
        {
            turret.setAlliance(blue);
        }
    }

    public void setPoseSource(TurretTracker.PoseSource source)
    {
        if (turret != null)
        {
            turret.setPoseSource(source);
        }
    }

    public void startTurret()
    {
        halted = false;
        if (turret != null)
        {
            turret.start();
            turretActive = true;
        }
    }

    public void startSweeper()
    {
        halted = false;
        if (sweeper != null)
        {
            sweeper.start();
            sweeperActive = true;
        }
    }

    public boolean relocalizeNow()
    {
        return relocalize(1.0);
    }

    // Call with false while the hive is tilted so Limelight position fixes are ignored.
    public void setHiveFlat(boolean flat)
    {
        if (relocalizer != null)
        {
            relocalizer.setHiveFlat(flat);
        }
    }

    private boolean relocalize(double blend)
    {
        if (relocalizer == null || pinpointPose == null || !pinpointPose.isValid())
        {
            return false;
        }
        double[] current = pinpointPose.pose();
        if (current == null)
        {
            return false;
        }
        double[] seen = relocalizer.pose(current[2]);
        if (seen == null)
        {
            return false;
        }
        double dx = seen[0] - current[0];
        double dy = seen[1] - current[1];
        double diff = Math.hypot(dx, dy);
        if (diff > RELOCALIZE_MAX_JUMP_IN)
        {
            relocalizeRejected++;
            return false;
        }
        pinpointPose.setPose(current[0] + blend * dx, current[1] + blend * dy, current[2]);
        relocalizeCount++;
        relocalizeLastDiffIn = diff;
        return true;
    }

    private void autoRelocalize()
    {
        if (!AUTO_RELOCALIZE || relocalizer == null || relocalizeTimer.seconds() < RELOCALIZE_PERIOD_S)
        {
            return;
        }
        relocalizeTimer.reset();
        double fastest = Math.max(Math.max(Math.abs(frontLeftPower), Math.abs(frontRightPower)), Math.max(Math.abs(backLeftPower), Math.abs(backRightPower)));
        if (fastest > RELOCALIZE_MAX_DRIVE_POWER)
        {
            return;
        }
        relocalize(RELOCALIZE_BLEND);
    }

    private void updateShotSpeed()
    {
        if (shooter != null && turret != null)
        {
            shooter.setDistance(turret.getHiveDistance());
        }
    }

    public void update(Telemetry telemetry)
    {
        updateShotSpeed();
        if (teleOpMode)
        {
            updateTeleOp(telemetry);
            return;
        }
        if (autoTrack && !halted && turret != null && !turretActive)
        {
            startTurret();
        }
        if (shooter != null)
        {
            shooter.update();
        }
        if (intake != null)
        {
            intake.update();
        }
        if (shootingCycle != null)
        {
            shootingCycle.update();
        }
        if (flowerCycle != null)
        {
            flowerCycle.update();
        }
        if (turret != null && turretActive)
        {
            turret.track();
        }
        if (sweeper != null && sweeperActive)
        {
            sweeper.update();
        }
        if (telemetry != null)
        {
            addTelemetry(telemetry);
        }
    }

    public void addTelemetry(Telemetry telemetry)
    {
        if (follower != null)
        {
            Pose pose = follower.pose();
            telemetry.addData("Pose", "x %.1f  y %.1f  heading %.0f deg", pose.x(), pose.y(), Math.toDegrees(pose.heading()));
        }
        else
        {
            telemetry.addData("Pose", followerStatus);
        }
        telemetry.addData("Path", activePath);
        if (shooter != null)
        {
            telemetry.addData("Shooter", shooter.getState());
            telemetry.addData("Shot speed", "%.2f of max at %.0f in from the hive", shooter.getTargetFraction(), turret != null ? turret.getHiveDistance() : -1.0);
        }
        else
        {
            telemetry.addData("Shooter", shooterStatus);
        }
        if (shootingCycle != null)
        {
            telemetry.addData("Shooting cycle", shootingCycle.isRunning() ? "running" : "idle");
        }
        if (turret != null)
        {
            telemetry.addData("Turret", turret.getState());
        }
        else
        {
            telemetry.addData("Turret", turretStatus);
        }
    }

    public void stopMechanisms()
    {
        if (shootingCycle != null)
        {
            shootingCycle.cancel();
        }
        if (flowerCycle != null)
        {
            flowerCycle.cancel();
        }
        if (shooter != null)
        {
            shooter.stopAll();
        }
        if (intake != null)
        {
            intake.stop();
        }
        if (gate != null)
        {
            gate.close();
        }
    }

    public void teleOpInit(Gamepad gamepad)
    {
        pad = gamepad;
        if (intake == null)
        {
            throw new IllegalStateException("Intake " + intakeStatus);
        }
        loadHandoff();
        setupPoseSource();
        teleOpMode = true;
    }

    public void chooseAlliance(boolean red, boolean blue)
    {
        if (red)
        {
            allianceKnown = true;
            blueAlliance = false;
        }
        else if (blue)
        {
            allianceKnown = true;
            blueAlliance = true;
        }
    }

    public void initTelemetry(Telemetry telemetry)
    {
        telemetry.addData("Turret", turretStatus);
        telemetry.addData("Shooter", shooterStatus);
        telemetry.addData("Gate", gateStatus);
        telemetry.addData("Sweeper", sweeperStatus);
        telemetry.addData("Alliance", allianceText());
        telemetry.addData("Heading from auto", handoffText());
        telemetry.addData("Status", "Initialized - D-pad left = RED, D-pad right = BLUE, then press START");
        telemetry.update();
    }

    public void teleOpStart()
    {
        if (turret != null && allianceKnown)
        {
            turret.setAlliance(blueAlliance);
        }
        runtime.reset();
        flywheelLatched = true;
        flywheelTimer.reset();
        if (turret != null)
        {
            turret.start();
        }
        if (sweeper != null)
        {
            sweeper.start();
        }
    }

    public void stopTeleOp()
    {
        if (shooter != null)
        {
            shooter.stopAll();
        }
        if (turret != null)
        {
            turret.stop();
        }
    }

    public void control(double axialStick, double lateralStick, double yawStick)
    {
        double axial = stickCurve(axialStick);
        double lateral = stickCurve(lateralStick);
        double yaw = stickCurve(yawStick);

        double[] power = MecanumWheelPowers.calculate(axial, lateral, yaw);

        double dt = Math.min(driveTimer.seconds(), MAX_RAMP_DT_S);
        driveTimer.reset();
        double maxStep = MAX_POWER_CHANGE_PER_S * dt;
        double decelStep = MAX_DECEL_PER_S * dt;

        frontLeftPower = ramp(frontLeftPower, power[0], maxStep, decelStep);
        frontRightPower = ramp(frontRightPower, power[1], maxStep, decelStep);
        backLeftPower = ramp(backLeftPower, power[2], maxStep, decelStep);
        backRightPower = ramp(backRightPower, power[3], maxStep, decelStep);

        if (frontLeftPower != lastFrontLeftWrite)
        {
            lastFrontLeftWrite = frontLeftPower;
            frontLeft.setPower(frontLeftPower);
        }
        if (frontRightPower != lastFrontRightWrite)
        {
            lastFrontRightWrite = frontRightPower;
            frontRight.setPower(frontRightPower);
        }
        if (backLeftPower != lastBackLeftWrite)
        {
            lastBackLeftWrite = backLeftPower;
            backLeft.setPower(backLeftPower);
        }
        if (backRightPower != lastBackRightWrite)
        {
            lastBackRightWrite = backRightPower;
            backRight.setPower(backRightPower);
        }
    }

    public void control(boolean inButton, boolean outButton, Intake intakeSubsystem)
    {
        if (intakeSubsystem == null || cycleRunning())
        {
            return;
        }
        if (outButton)
        {
            intakeSubsystem.out();
        }
        else if (inButton)
        {
            intakeSubsystem.in();
        }
        else
        {
            intakeSubsystem.stop();
        }
    }

    public void control(boolean shootButton, ShootingCycle cycle)
    {
        if (cycle == null)
        {
            return;
        }
        cycle.setHold(shootButton);
        if (shootButton)
        {
            if (cycle.isDone())
            {
                double spinningS = 0.0;
                if (flywheelLatched)
                {
                    spinningS = flywheelTimer.seconds();
                }
                else
                {
                    flywheelTimer.reset();
                }
                flywheelLatched = false;
                cycle.start(spinningS);
            }
        }
        else if (cycleButtonWasDown && cycle.isRunning())
        {
            cycle.cancel();
        }
        cycleButtonWasDown = shootButton;
    }

    public void control(boolean leftButton, boolean rightButton, TurretTracker turretSubsystem)
    {
        if (turretSubsystem == null)
        {
            return;
        }
        manualTurret = true;
        double power = 0.0;
        if (rightButton)
        {
            power += MANUAL_TURRET_RIGHT_SIGN;
        }
        if (leftButton)
        {
            power -= MANUAL_TURRET_RIGHT_SIGN;
        }
        manualTurretPower = power * MANUAL_TURRET_POWER;
    }

    public void control(boolean toggleButton, Gate gateSubsystem)
    {
        if (gateSubsystem != null && !cycleRunning() && toggleButton && !gateButtonWasDown)
        {
            gateSubsystem.toggle();
        }
        gateButtonWasDown = toggleButton;
    }

    public void control(boolean toggleButton, Sweeper sweeperSubsystem)
    {
        if (sweeperSubsystem != null && toggleButton && !sweeperButtonWasDown)
        {
            sweeperSubsystem.toggle();
        }
        sweeperButtonWasDown = toggleButton;
    }

    public void control(boolean fixButton, PinpointPose pinpoint)
    {
        if (!fixButton)
        {
            cornerHolding = false;
            cornerFired = false;
            return;
        }
        if (!cornerHolding)
        {
            cornerHolding = true;
            cornerTimer.reset();
            return;
        }
        if (cornerFired || cornerTimer.seconds() < CORNER_FIX_HOLD_S)
        {
            return;
        }
        cornerFired = true;
        applyCornerFix(pinpoint);
    }

    private void applyCornerFix(PinpointPose pinpoint)
    {
        boolean blue = allianceKnown && blueAlliance;
        double x = CORNER_SIDE_IN;
        double y = CORNER_BACK_IN;
        if (blue)
        {
            x = CORNER_FIELD_IN - x;
            y = CORNER_FIELD_IN - y;
        }
        double cornerHeading = MatchHandoff.driverForwardHeading(blue);

        boolean pinpointFixed = false;
        if (pinpoint != null)
        {
            pinpoint.setPose(x, y, cornerHeading);
            pinpointFixed = true;
        }
        String corner = "RED corner (0, 0)";
        if (blue)
        {
            corner = "BLUE corner (144, 144)";
        }
        else if (!allianceKnown)
        {
            corner = "RED corner (0, 0) - alliance not set";
        }
        if (pinpointFixed)
        {
            cornerText = String.format("%s - pose set to %.1f, %.1f, %.0f deg", corner, x, y, Math.toDegrees(cornerHeading));
        }
        else
        {
            cornerText = corner + " - no Pinpoint found, nothing changed";
        }
        if (pad != null)
        {
            pad.rumbleBlips(2);
        }
    }

    private void updateTeleOp(Telemetry telemetry)
    {
        loopTimer.tick();
        if (!worstReset && runtime.seconds() >= LOOP_WORST_RESET_S)
        {
            worstReset = true;
            loopTimer.resetWorst();
        }
        checkTimeWarnings();
        autoRelocalize();

        if (cycleRunning())
        {
            shooting = true;
        }
        else
        {
            shooting = flywheelLatched;
            if (shooter != null)
            {
                if (shooting)
                {
                    shooter.shoot();
                    shooter.update();
                }
                else
                {
                    shooter.stopShooter();
                }
            }
        }

        if (turret != null)
        {
            if (manualTurret)
            {
                turret.manual(manualTurretPower);
            }
            else
            {
                turret.track();
            }
        }

        if (shootingCycle != null)
        {
            shootingCycle.update();
            boolean cycleNowRunning = shootingCycle.isRunning();
            if (cycleWasRunning && !cycleNowRunning)
            {
                flywheelLatched = true;
            }
            cycleWasRunning = cycleNowRunning;
        }

        if (sweeper != null)
        {
            sweeper.update();
        }

        showTeleOpTelemetry(telemetry);
    }

    private boolean cycleRunning()
    {
        return shootingCycle != null && shootingCycle.isRunning();
    }

    private void checkTimeWarnings()
    {
        remaining = TELEOP_LENGTH_S - runtime.seconds();
        if (!flowersWarned && remaining <= FLOWERS_OPEN_REMAINING_S)
        {
            flowersWarned = true;
            if (pad != null)
            {
                pad.rumbleBlips(2);
            }
        }
        if (!finalWarned && remaining <= FINAL_WARNING_REMAINING_S)
        {
            finalWarned = true;
            if (pad != null)
            {
                pad.rumbleBlips(3);
            }
        }
    }

    private double stickCurve(double value)
    {
        return value * (1.0 - STICK_CURVE) + value * value * value * STICK_CURVE;
    }

    private double ramp(double current, double target, double maxStep, double decelStep)
    {
        boolean sameSide = current * target >= 0.0;
        if (sameSide && Math.abs(target) <= Math.abs(current))
        {
            double slowDelta = target - current;
            return current + Math.max(-decelStep, Math.min(decelStep, slowDelta));
        }
        double delta = target - current;
        return current + Math.max(-maxStep, Math.min(maxStep, delta));
    }

    private void setupPoseSource()
    {
        pinpointPose = null;
        if (turret == null)
        {
            return;
        }
        try
        {
            pinpointPose = new PinpointPose(hardwareMap);
            pinpointPose.setValid(handoffUsed);
            turret.setPoseSource(pinpointPose);
            if (turret.hasLimelight())
            {
                relocalizer = new LimelightRelocalizer(hardwareMap);
            }
        }
        catch (Exception e)
        {
            pinpointPose = null;
        }
    }

    private void loadHandoff()
    {
        handoffUsed = MatchHandoff.isFresh();
        if (handoffUsed)
        {
            allianceKnown = true;
            blueAlliance = MatchHandoff.isBlue();
        }
    }

    private String allianceText()
    {
        if (!allianceKnown)
        {
            return "not set - turret accepts any tag";
        }
        if (blueAlliance)
        {
            return "BLUE";
        }
        return "RED";
    }

    private String handoffText()
    {
        if (!handoffUsed)
        {
            return "none - put the robot in the corner and hold X";
        }
        return String.format("%.0f s old, robot at %.0f deg on the field", MatchHandoff.getAgeS(), Math.toDegrees(MatchHandoff.getHeading()));
    }

    private void showTeleOpTelemetry(Telemetry telemetry)
    {
        telemetry.addData("Time left", "%.0f s", Math.max(0, remaining));
        telemetry.addData("Loop time", "%.1f ms avg, %.1f ms worst", loopTimer.getAverageMs(), loopTimer.getWorstMs());

        if (pinpointPose != null && pinpointPose.isValid())
        {
            double[] where = pinpointPose.pose();
            if (where != null)
            {
                telemetry.addData("Heading (Pinpoint)", "%.0f deg", Math.toDegrees(where[2]));
            }
        }
        else
        {
            telemetry.addData("Heading (Pinpoint)", "not set yet - press X in your corner");
        }
        telemetry.addData("Alliance", allianceText());
        telemetry.addData("Corner fix", cornerText);
        if (AUTO_RELOCALIZE && relocalizer != null)
        {
            telemetry.addData("Limelight position fix", "%d applied, %d rejected, last correction %.1f in", relocalizeCount, relocalizeRejected, relocalizeLastDiffIn);
            telemetry.addData("Limelight hive tilt", "%d fixes ignored (tilted hive or bad height)", relocalizer.getTiltRejectCount());
        }

        if (turret == null)
        {
            telemetry.addData("Turret", "not found in the config");
        }
        else if (manualTurret)
        {
            telemetry.addData("Turret", "MANUAL at %.0f deg (D-pad left/right)", turret.getPositionDegrees());
        }
        else if (turret.getState() == TurretTracker.State.POSE_AIM)
        {
            telemetry.addData("Turret", "POSE_AIM at %.0f deg, %.1f deg to go (aiming from the robot's position)", turret.getPositionDegrees(), turret.getPoseError());
        }
        else if (!turret.hasLimelight())
        {
            telemetry.addData("Turret", "%s, no limelight in config - position aim only (hold X in the corner first)", turret.getState());
        }
        else if (turret.hasTarget())
        {
            telemetry.addData("Turret", "%s, tag %d, %.1f deg off", turret.getState(), turret.getTargetId(), turret.getError());
        }
        else
        {
            telemetry.addData("Turret", "%s, no tag in view", turret.getState());
        }
        if (turret != null && turret.isAtLimit())
        {
            telemetry.addData("Turret limit", "at the end of its travel - turn the other way");
        }

        if (shooter == null)
        {
            telemetry.addData("Shooter", shooterStatus);
        }
        else
        {
            if (shooting)
            {
                telemetry.addData("Shooter", "RUNNING - %s", shooter.getState());
            }
            else
            {
                telemetry.addData("Shooter", "off");
            }
            String encoderNote = "";
            if (!shooter.isSpeedControlled())
            {
                encoderNote = " (no encoder, plain power)";
            }
            telemetry.addData("Shooter wheel power", "%.2f%s", shooter.getShooterPower(), encoderNote);
            telemetry.addData("Shot speed", "%.2f of max, hive %.0f in away (-1 = no position)", shooter.getTargetFraction(), turret != null ? turret.getHiveDistance() : -1.0);
            telemetry.addData("Shooter speed", "%.0f ticks/s", shooter.getVelocityTicksPerSec());
            if (shootingCycle != null)
            {
                String aimNote = "";
                if (shootingCycle.isWaitingForAim())
                {
                    aimNote = " (waiting for turret to lock on)";
                }
                telemetry.addData("Shot cycle (right trigger)", "%s%s", shootingCycle.getState(), aimNote);
            }
            if (!shooter.hasCounterRoller())
            {
                telemetry.addData("Counter roller", "not in config (shooter_counter)");
            }
            else if (shooting)
            {
                telemetry.addData("Counter roller", "RUNNING");
            }
            else
            {
                telemetry.addData("Counter roller", "off");
            }
        }

        if (gate == null)
        {
            telemetry.addData("Gate", gateStatus);
        }
        else if (gate.isOpen())
        {
            telemetry.addData("Gate", "OPEN");
        }
        else
        {
            telemetry.addData("Gate", "closed");
        }

        if (sweeper == null)
        {
            telemetry.addData("Sweeper", sweeperStatus);
        }
        else
        {
            telemetry.addData("Sweeper", sweeper.isDeployed() ? "DOWN" : "up");
        }

        if (intake != null)
        {
            String transferNote = "";
            if (!intake.hasTransfer())
            {
                transferNote = " (no transfer motor in config)";
            }
            if (!intake.hasOuter())
            {
                transferNote = transferNote + " (no intake_right motor in config)";
            }
            telemetry.addData("Intake inner+transfer / outer", "%.2f / %.2f%s", intake.getInnerPower(), intake.getOuterPower(), transferNote);
            telemetry.addData("Intake current", "%.1f A now, %.1f A peak, %d jam clears%s", intake.getCurrentAmps(), intake.getPeakCurrentAmps(), intake.getJamCount(), intake.isClearingJam() ? " (clearing)" : "");
        }
        telemetry.addData("Front L/R", "%.2f, %.2f", frontLeftPower, frontRightPower);
        telemetry.addData("Back  L/R", "%.2f, %.2f", backLeftPower, backRightPower);
    }

    public Command sweeperDown()
    {
        return sequential(
                instant(() ->
                {
                    if (sweeper != null)
                    {
                        sweeper.deploy();
                    }
                }),
                waitUntil(() -> sweeper == null || !sweeperActive || !sweeper.isMoving()));
    }

    public Command sweeperLower()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.deploy();
            }
        });
    }

    public Command sweeperUp()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.stow();
            }
        });
    }

    public Command collectFlower()
    {
        if (flowerCycle == null)
        {
            return waitMs(FlowerCycle.COLLECT_S * 1000.0);
        }
        return sequential(
                instant(() -> flowerCycle.start(false)),
                waitUntil(() -> flowerCycle.isDone()));
    }

    public Command nothing()
    {
        return instant(() ->
        {
        });
    }

    public Command driveFor(double axial, double lateral, double seconds)
    {
        return sequential(
                instant(() -> setDrive(axial, lateral, 0.0)),
                waitMs(seconds * 1000.0),
                instant(this::stopDrive));
    }

    public void setDrive(double axial, double lateral, double yaw)
    {
        double[] power = MecanumWheelPowers.calculate(axial, lateral, yaw);
        frontLeft.setPower(power[0]);
        frontRight.setPower(power[1]);
        backLeft.setPower(power[2]);
        backRight.setPower(power[3]);
    }

    public void stopDrive()
    {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }

    public void stopAll()
    {
        boolean turretWasOn = turretActive;
        boolean sweeperWasOn = sweeperActive;
        haltAuto();
        stopDrive();
        stopMechanisms();
        if (turret != null && turretWasOn)
        {
            turret.stop();
        }
        if (sweeper != null && sweeperWasOn)
        {
            sweeper.stow();
        }
    }
}
