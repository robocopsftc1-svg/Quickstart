package org.firstinspires.ftc.teamcode.mechanisms.shooter;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;

import org.firstinspires.ftc.teamcode.config.HardwareNames;

public class Gate
{
    public static final double CLOSED_POSITION = 0.90;
    public static final double OPEN_POSITION = 0.70;

    private static final int PWM_MIN_US = 500;
    private static final int PWM_MAX_US = 2500;

    public static final double SERVO_RANGE_DEG = 350.0;

    private Servo servo;
    private boolean open;
    private double closedPosition = CLOSED_POSITION;
    private double openPosition = OPEN_POSITION;

    public Gate(HardwareMap hardwareMap)
    {
        servo = hardwareMap.get(Servo.class, HardwareNames.STOPPER);
        if (servo instanceof ServoImplEx)
        {
            ServoImplEx extended = (ServoImplEx) servo;
            extended.setPwmRange(new PwmControl.PwmRange(PWM_MIN_US, PWM_MAX_US));
        }
        close();
    }

    public void open()
    {
        servo.setPosition(openPosition);
        open = true;
    }

    public void close()
    {
        servo.setPosition(closedPosition);
        open = false;
    }

    public void setClosedPosition(double position)
    {
        closedPosition = Math.max(0.0, Math.min(1.0, position));
        if (!open)
        {
            servo.setPosition(closedPosition);
        }
    }

    public void setOpenPosition(double position)
    {
        openPosition = Math.max(0.0, Math.min(1.0, position));
        if (open)
        {
            servo.setPosition(openPosition);
        }
    }

    public double getClosedPosition()
    {
        return closedPosition;
    }

    public double getOpenPosition()
    {
        return openPosition;
    }

    public void toggle()
    {
        if (open)
        {
            close();
        }
        else
        {
            open();
        }
    }

    public boolean isOpen()
    {
        return open;
    }
}
