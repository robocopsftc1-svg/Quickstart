package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;

@TeleOp(name = "Turret Tracking Test", group = "Test")
public class TurretTrackingTest extends LinearOpMode
{
    private static final double JOG_POWER = 1.0;
    private static final double STICK_DEADBAND = 0.08;
    private static final double KP_STEP = 0.002;
    private static final double KD_STEP = 0.0002;
    private static final double MIN_POWER_STEP = 0.01;
    private static final double MAX_POWER_STEP = 0.05;

    private final boolean[] wasDown = new boolean[12];

    private TurretTracker turret;
    private int servoMode = 0;

    @Override
    public void runOpMode()
    {
        try
        {
            turret = new TurretTracker(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Turret", "a turret servo or the limelight was not found in the config");
            telemetry.addData("Expected names", "%s, %s, %s", HardwareNames.TURRET_LEFT,
                    HardwareNames.TURRET_RIGHT, HardwareNames.LIMELIGHT);
            telemetry.update();
            waitForStart();
            return;
        }

        telemetry.addLine("Turret Tracking Test - the turret swings to its center when you press start");
        telemetry.addLine("Left stick left/right: sweep the turret (stick right should turn it clockwise)");
        telemetry.addLine("Y: flip direction if stick right turned it the wrong way");
        telemetry.addLine("Left bumper: send the turret back to center. Back: turn the travel limits on/off.");
        telemetry.addLine("X: choose which servo the stick drives - both, left only, right only");
        telemetry.addLine("Hold right bumper: aim at the AprilTag automatically");
        telemetry.addLine("D-pad up/down: kP. D-pad right/left: kD. A/B: min power. Triggers: max power.");
        telemetry.update();

        waitForStart();
        turret.start();

        while (opModeIsActive())
        {
            handleButtons();

            if (gamepad1.right_bumper)
            {
                turret.track();
            }
            else
            {
                double stick = gamepad1.left_stick_x;
                if (Math.abs(stick) < STICK_DEADBAND)
                {
                    stick = 0.0;
                }
                if (servoMode == 1)
                {
                    turret.setServoPowers(stick * JOG_POWER, 0.0);
                }
                else if (servoMode == 2)
                {
                    turret.setServoPowers(0.0, stick * JOG_POWER);
                }
                else
                {
                    turret.setPower(stick * JOG_POWER);
                }
            }

            showTelemetry();
        }

        turret.stop();
    }

    private boolean pressed(int index, boolean down)
    {
        boolean value = down && !wasDown[index];
        wasDown[index] = down;
        return value;
    }

    private void handleButtons()
    {
        if (pressed(0, gamepad1.dpad_up))
        {
            turret.kP += KP_STEP;
        }
        if (pressed(1, gamepad1.dpad_down))
        {
            turret.kP = Math.max(0.0, turret.kP - KP_STEP);
        }
        if (pressed(2, gamepad1.dpad_right))
        {
            turret.kD += KD_STEP;
        }
        if (pressed(3, gamepad1.dpad_left))
        {
            turret.kD = Math.max(0.0, turret.kD - KD_STEP);
        }
        if (pressed(4, gamepad1.a))
        {
            turret.minPower += MIN_POWER_STEP;
        }
        if (pressed(5, gamepad1.b))
        {
            turret.minPower = Math.max(0.0, turret.minPower - MIN_POWER_STEP);
        }
        if (pressed(6, gamepad1.right_trigger > 0.5))
        {
            turret.maxPower = Math.min(1.0, turret.maxPower + MAX_POWER_STEP);
        }
        if (pressed(7, gamepad1.left_trigger > 0.5))
        {
            turret.maxPower = Math.max(0.0, turret.maxPower - MAX_POWER_STEP);
        }
        if (pressed(8, gamepad1.y))
        {
            turret.invert = !turret.invert;
        }
        if (pressed(9, gamepad1.x))
        {
            servoMode = (servoMode + 1) % 3;
        }
        if (pressed(10, gamepad1.left_bumper))
        {
            turret.zeroPositionEstimate();
        }
        if (pressed(11, gamepad1.back))
        {
            turret.limitsEnabled = !turret.limitsEnabled;
        }
    }

    private void showTelemetry()
    {
        telemetry.addData("Mode", gamepad1.right_bumper ? "auto-tracking" : "manual");
        if (turret.hasTarget())
        {
            telemetry.addData("Tag", "id %d, %.1f deg off center", turret.getTargetId(), turret.getError());
            telemetry.addData("Distance from Limelight", "%.0f in", turret.getLimelightDistance());
        }
        else
        {
            telemetry.addData("Tag", "none seen");
        }
        telemetry.addData("Distance from position", "%.0f in (-1 means no position yet)", turret.getPoseDistance());
        telemetry.addData("Distance used for shot speed", "%.0f in", turret.getHiveDistance());
        telemetry.addLine("Measure the real distance to the hive. If the Limelight distance is off, change CAMERA_HEIGHT_IN and CAMERA_PITCH_DEG in TurretTracker.java.");
        String[] modeNames = {"BOTH servos", "LEFT servo only", "RIGHT servo only"};
        telemetry.addData("Stick drives", modeNames[servoMode]);
        telemetry.addData("Enabled in code", "left %s, right %s (BOTH mode uses only the enabled ones)", TurretTracker.LEFT_SERVO_ENABLED, TurretTracker.RIGHT_SERVO_ENABLED);
        telemetry.addData("Turret angle", "%.1f deg from center (+ is stick right)%s", turret.getPositionDegrees(), turret.isAtLimit() ? " (AT LIMIT)" : "");
        if (turret.limitsEnabled)
        {
            telemetry.addData("Travel limits", "ON, %.0f to +%.0f deg", turret.getLowerLimit(), turret.getUpperLimit());
        }
        else
        {
            telemetry.addData("Travel limits", "turned off with Back, servo edge at %.0f to +%.0f deg", turret.getLowerLimit(), turret.getUpperLimit());
        }
        telemetry.addData("Turret power", "%.3f", turret.getCommandedPower());
        telemetry.addData("Flip direction (invert)", turret.invert);
        telemetry.addData("kP", "%.4f", turret.kP);
        telemetry.addData("kD", "%.5f", turret.kD);
        telemetry.addData("Min power", "%.3f", turret.minPower);
        telemetry.addData("Max power", "%.2f", turret.maxPower);
        telemetry.update();
    }
}
