package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.robot.Robot;
import org.firstinspires.ftc.teamcode.util.BulkReads;

@TeleOp(name = "teleOp", group = "TeleOp")
public class teleOp extends LinearOpMode
{
    private static final double SHOOT_BUTTON_THRESHOLD = 0.5;

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);
        Robot robot = new Robot(hardwareMap);
        robot.teleOpInit(gamepad1);

        while (!isStarted() && !isStopRequested())
        {
            robot.chooseAlliance(gamepad1.dpad_left, gamepad1.dpad_right);
            robot.initTelemetry(telemetry);
            idle();
        }

        robot.teleOpStart();

        while (opModeIsActive())
        {
            BulkReads.clear();
            robot.control(-gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x);
            robot.control(gamepad1.right_bumper, gamepad1.left_bumper, robot.intake);
            robot.control(gamepad1.right_trigger > SHOOT_BUTTON_THRESHOLD, robot.shootingCycle);
            robot.control(gamepad1.x, robot.pinpointPose);
            robot.update(telemetry);
            telemetry.update();
        }

        robot.stopTeleOp();
    }
}
