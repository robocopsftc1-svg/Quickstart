package org.firstinspires.ftc.teamcode.util;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.teamcode.config.HardwareNames;

public class LimelightRelocalizer
{
    public static final int APRIL_TAG_PIPELINE = 0;
    public static final double MAX_STALENESS_MS = 60.0;
    public static final int MIN_TAGS = 1;

    public static final double FIELD_CENTER_IN = 72.0;
    public static final boolean LL_SWAP_XY = true;
    public static final double LL_X_SIGN = 1.0;
    public static final double LL_Y_SIGN = -1.0;
    public static final double LL_HEADING_OFFSET_DEG = 90.0;

    // The hive tilts during a match, but the field map is the flat hive. A tilted hive moves the
    // tags, so the Limelight position would be wrong. A robot on the floor must read about 0 in
    // height, so a large height error means the hive is probably tilted and the fix is rejected.
    // This needs the Limelight camera position (including "up") entered in the Limelight page.
    public static final boolean USE_HEIGHT_CHECK = true;
    public static final double MAX_HEIGHT_ERROR_IN = 3.0;

    private Limelight3A limelight;
    private boolean hiveFlat = true;
    private int tiltRejectCount = 0;

    public LimelightRelocalizer(HardwareMap hardwareMap)
    {
        limelight = null;
        try
        {
            limelight = hardwareMap.get(Limelight3A.class, HardwareNames.LIMELIGHT);
        }
        catch (Exception e)
        {
            limelight = null;
        }
    }

    public boolean hasLimelight()
    {
        return limelight != null;
    }

    // Set false while the hive is known to be tilted so no position fixes are accepted.
    public void setHiveFlat(boolean flat)
    {
        hiveFlat = flat;
    }

    public boolean isHiveFlat()
    {
        return hiveFlat;
    }

    public int getTiltRejectCount()
    {
        return tiltRejectCount;
    }

    public void start()
    {
        if (limelight == null)
        {
            return;
        }
        limelight.setPollRateHz(100);
        limelight.pipelineSwitch(APRIL_TAG_PIPELINE);
        limelight.start();
    }

    public void stop()
    {
        if (limelight != null)
        {
            limelight.stop();
        }
    }

    public int tagCount()
    {
        if (limelight == null)
        {
            return 0;
        }
        LLResult result = limelight.getLatestResult();
        if (result == null || !result.isValid())
        {
            return 0;
        }
        return result.getFiducialResults().size();
    }

    public double[] rawPoseInches(double headingRad)
    {
        if (limelight == null)
        {
            return null;
        }
        limelight.updateRobotOrientation(Math.toDegrees(headingRad) + LL_HEADING_OFFSET_DEG);
        LLResult result = limelight.getLatestResult();
        if (result == null || !result.isValid() || result.getStaleness() >= MAX_STALENESS_MS)
        {
            return null;
        }
        if (result.getFiducialResults().size() < MIN_TAGS)
        {
            return null;
        }
        Pose3D botpose = result.getBotpose_MT2();
        if (botpose == null)
        {
            return null;
        }
        Position position = botpose.getPosition();
        double x = DistanceUnit.INCH.fromUnit(position.unit, position.x);
        double y = DistanceUnit.INCH.fromUnit(position.unit, position.y);
        double z = DistanceUnit.INCH.fromUnit(position.unit, position.z);
        if (x == 0.0 && y == 0.0)
        {
            return null;
        }
        if (!hiveFlat)
        {
            tiltRejectCount++;
            return null;
        }
        if (USE_HEIGHT_CHECK && Math.abs(z) > MAX_HEIGHT_ERROR_IN)
        {
            tiltRejectCount++;
            return null;
        }
        return new double[] {x, y};
    }

    public double[] pose(double headingRad)
    {
        double[] raw = rawPoseInches(headingRad);
        if (raw == null)
        {
            return null;
        }
        return toFieldFrame(raw[0], raw[1]);
    }

    public double[] toFieldFrame(double llXIn, double llYIn)
    {
        double a = LL_SWAP_XY ? llYIn : llXIn;
        double b = LL_SWAP_XY ? llXIn : llYIn;
        return new double[] {FIELD_CENTER_IN + LL_X_SIGN * a, FIELD_CENTER_IN + LL_Y_SIGN * b};
    }
}
