package org.firstinspires.ftc.teamcode.auto;

import static com.pedropathing.api.Paths.curve;
import static com.pedropathing.ivy.commands.Commands.conditional;
import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.commands.Commands.waitUntil;
import static com.pedropathing.ivy.groups.Groups.race;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.pedropathing.ivy.Command;
import com.pedropathing.ivy.Scheduler;
import com.pedropathing.math.Pose;
import com.pedropathing.paths.Path;
import com.pedropathing.paths.interpolator.Interpolator;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.ShootingCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.FlowerCycle;
import org.firstinspires.ftc.teamcode.robot.Robot;
import org.firstinspires.ftc.teamcode.util.BulkReads;
import org.firstinspires.ftc.teamcode.util.LoopTimer;
import org.firstinspires.ftc.teamcode.util.MatchHandoff;

import java.util.ArrayList;
import java.util.List;

@Autonomous(name = "SuperSaiyanRosé", group = "Autonomous")
public class SuperSaiyanRose extends OpMode
{
    private static class Spot
    {
        final double x;
        final double y;
        final double heading;

        Spot(double x, double y, double heading)
        {
            this.x = x;
            this.y = y;
            this.heading = heading;
        }

        Pose pose()
        {
            return new Pose(x, y, heading);
        }
    }

    private static final double FIELD_IN = 144.0;

    private static final double HIVE_LEFT_IN = 47.0;
    private static final double HIVE_RIGHT_IN = 97.0;
    private static final double HIVE_BOTTOM_IN = 52.5;
    private static final double HIVE_TOP_IN = 91.5;
    private static final double HIVE_MID_X_IN = (HIVE_LEFT_IN + HIVE_RIGHT_IN) / 2.0;
    private static final double HIVE_MID_Y_IN = (HIVE_BOTTOM_IN + HIVE_TOP_IN) / 2.0;

    private static final double FLOWER_TOP_X_IN = 48.0;
    private static final double FLOWER_LEFT_Y_IN = 48.0;

    private static final double GARDEN_X_MIN_IN = 0.0;
    private static final double GARDEN_X_MAX_IN = 23.0;

    private static final double LOADING_X_MIN_IN = 0.0;
    private static final double LOADING_X_MAX_IN = 11.0;
    private static final double LOADING_Y_MIN_IN = 96.0;
    private static final double LOADING_Y_MAX_IN = 119.0;

    private static final double START_X_IN = 56.0;
    private static final double START_Y_IN = 8.0;
    private static final double START_HEADING_DEG = 90.0;

    private static final double ROBOT_FRONT_IN = 11.0;
    private static final double ROBOT_SIDE_IN = 9.0;
    private static final double WALL_PAD_IN = 1.0;
    private static final double FLOWER_STANDOFF_IN = 2.0;

    private static final double SHOT_MOVE_TOLERANCE_IN = 10.0;
    private static final double GARDEN_TURN_FRACTION = 0.2;

    private static final double ESTIMATED_SPEED_IN_PER_S = 45.0;
    private static final double GARDEN_PICKUP_S = 1.0;
    private static final double FLOWER_PICKUP_S = FlowerCycle.COLLECT_S;
    private static final double SHOT_EXTRA_S = 0.5;

    private static final double PATH_TIMEOUT_S = 8.0;
    private static final double BLEND_RADIUS_IN = 6.0;
    private static final double BLEND_MAX_LEG_FRACTION = 0.25;

    private static final double DRIVE_POWER = 0.4;
    private static final double CLEAR_WALL_S = 0.3;

    private static final double AUTO_LENGTH_S = 30.0;
    private static final double END_MARGIN_S = 2.0;

    private static final double LANE_X_IN = (0.0 + HIVE_LEFT_IN) / 2.0;

    private final Spot startSpot = spot(START_X_IN, START_Y_IN, START_HEADING_DEG);

    private final Spot gardenSpot = spot(
            ROBOT_FRONT_IN + WALL_PAD_IN,
            START_Y_IN,
            180.0);

    private final Spot topShotSpot = spot(
            START_X_IN,
            Math.min(2.0 * HIVE_MID_Y_IN - START_Y_IN, FIELD_IN - ROBOT_FRONT_IN - WALL_PAD_IN),
            90.0);

    private final Spot topFlowerSpot = spot(
            FLOWER_TOP_X_IN,
            FIELD_IN - ROBOT_FRONT_IN - WALL_PAD_IN - FLOWER_STANDOFF_IN,
            90.0);

    private final Spot leftFlowerSpot = spot(
            ROBOT_FRONT_IN + WALL_PAD_IN + FLOWER_STANDOFF_IN,
            FLOWER_LEFT_Y_IN,
            180.0);

    private final Spot leftShotSpot = spot(
            Math.max(HIVE_MID_X_IN + (START_Y_IN - HIVE_MID_Y_IN), ROBOT_SIDE_IN + WALL_PAD_IN),
            HIVE_MID_Y_IN - (START_X_IN - HIVE_MID_X_IN),
            90.0);

    private final Spot parkSpot = spot(
            Math.max((LOADING_X_MIN_IN + LOADING_X_MAX_IN) / 2.0, ROBOT_SIDE_IN + WALL_PAD_IN),
            (LOADING_Y_MIN_IN + LOADING_Y_MAX_IN) / 2.0,
            90.0);

    private final boolean topShotInPlace =
            Math.hypot(topFlowerSpot.x - topShotSpot.x, topFlowerSpot.y - topShotSpot.y) <= SHOT_MOVE_TOLERANCE_IN;

    private final Spot afterTopFlowerSpot = topShotInPlace ? topFlowerSpot : topShotSpot;

    private final Pose startToGardenControl = straight(startSpot, gardenSpot);
    private final Pose gardenToTopShotControl = new Pose(redX(LANE_X_IN), topShotSpot.y);
    private final Pose topToLeftFlowerControl = new Pose(redX(LANE_X_IN), afterTopFlowerSpot.y);
    private final Pose startToParkControl = new Pose(redX(LANE_X_IN), (startSpot.y + parkSpot.y) / 2.0);

    private final double preloadSeconds = ShootingCycle.SPINUP_S + ShootingCycle.INTAKE_LEAD_S + ShootingCycle.FEED_S + SHOT_EXTRA_S;
    private final double shotSeconds = ShootingCycle.INTAKE_LEAD_S + ShootingCycle.FEED_S + SHOT_EXTRA_S;

    private final double gardenStageWork =
            legSeconds(startSpot, startToGardenControl, gardenSpot)
                    + GARDEN_PICKUP_S
                    + legSeconds(gardenSpot, gardenToTopShotControl, topShotSpot)
                    + shotSeconds;

    private final double topFlowerStageWork =
            legSeconds(topShotSpot, straight(topShotSpot, topFlowerSpot), topFlowerSpot)
                    + FLOWER_PICKUP_S
                    + (topShotInPlace ? 0.0 : legSeconds(topFlowerSpot, straight(topFlowerSpot, topShotSpot), topShotSpot))
                    + shotSeconds;

    private final double leftFlowerStageWork =
            legSeconds(afterTopFlowerSpot, topToLeftFlowerControl, leftFlowerSpot)
                    + FLOWER_PICKUP_S
                    + legSeconds(leftFlowerSpot, straight(leftFlowerSpot, leftShotSpot), leftShotSpot)
                    + shotSeconds;

    private Robot robot;
    private final ElapsedTime matchTimer = new ElapsedTime();
    private final LoopTimer loopTimer = new LoopTimer();
    private Command root;
    private boolean stopped = false;
    private int stagesDone = 0;
    private String status = "Waiting for start";

    private final boolean launch = true;

    @Override
    public void init()
    {
        Scheduler.reset();
        BulkReads.enable(hardwareMap);
        robot = new Robot(hardwareMap);
        robot.setAlliance(isBlue());

        robot.createFollower();
    }

    @Override
    public void init_loop()
    {
        BulkReads.clear();
        telemetry.addLine("SuperSaiyanRosé - hive, garden and flowers");
        telemetry.addData("Alliance", isBlue() ? "BLUE" : "RED");
        telemetry.addData("Start", "x %.1f  y %.1f  heading %.0f deg", startSpot.x, startSpot.y, Math.toDegrees(startSpot.heading));
        telemetry.addData("Garden", "x %.1f  y %.1f", gardenSpot.x, gardenSpot.y);
        telemetry.addData("Top shot", "x %.1f  y %.1f", topShotSpot.x, topShotSpot.y);
        telemetry.addData("Top flower", "x %.1f  y %.1f", topFlowerSpot.x, topFlowerSpot.y);
        telemetry.addData("Left flower", "x %.1f  y %.1f", leftFlowerSpot.x, leftFlowerSpot.y);
        telemetry.addData("Left shot", "x %.1f  y %.1f", leftShotSpot.x, leftShotSpot.y);
        telemetry.addData("Park", "x %.1f  y %.1f", parkSpot.x, parkSpot.y);
        telemetry.addData("Estimated full route", "%.1f s of %.0f s", estimatedFullRouteSeconds(), AUTO_LENGTH_S);
        if (!robot.hasSweeper())
        {
            telemetry.addLine("WARNING: sweeper servos not found, sweeper will not move");
        }
        if (robot.hasTurret())
        {
            telemetry.addLine("Turret: set it by hand to its start position now. It tracks AprilTags from Start.");
        }
        else
        {
            telemetry.addLine("WARNING: turret servos or limelight not found, turret will not track");
        }
        if (!robot.hasFollower())
        {
            telemetry.addData("No odometry, timed plan only", robot.getFollowerStatus());
        }
        if (!robot.canLaunch())
        {
            telemetry.addLine("WARNING: shooter/intake not found in the hardware config");
        }
        telemetry.update();
    }

    @Override
    public void start()
    {
        Scheduler.reset();
        MatchHandoff.clear();
        matchTimer.reset();
        stagesDone = 0;
        robot.startTurret();
        robot.startSweeper();

        Command plan;
        if (robot.hasFollower())
        {
            robot.setStartPose(startSpot.pose());
            plan = odometryPlan();
        }
        else
        {
            plan = timedPlan();
        }

        root = race(plan, waitUntil(() -> timeLeft() <= END_MARGIN_S));
        Scheduler.schedule(root);
    }

    @Override
    public void loop()
    {
        BulkReads.clear();
        loopTimer.tick();
        robot.updateFollower();
        Scheduler.execute();
        robot.update(telemetry);

        if (!Scheduler.isScheduled(root))
        {
            if (!stopped)
            {
                stopped = true;
                robot.stopAll();
            }
            status = "Done";
        }

        if (robot.hasFollower())
        {
            Pose endPose = robot.getPose();
            MatchHandoff.save(endPose.x(), endPose.y(), endPose.heading(), isBlue());
        }

        telemetry.addData("Status", status);
        telemetry.addData("Stages done", stagesDone);
        telemetry.addData("Time left", "%.1f s", timeLeft());
        telemetry.addData("Loop time", "%.1f ms avg, %.1f ms worst", loopTimer.getAverageMs(), loopTimer.getWorstMs());
        telemetry.update();
    }

    @Override
    public void stop()
    {
        Scheduler.reset();
        robot.stopAll();
    }

    private Command odometryPlan()
    {
        List<Command> steps = new ArrayList<>();

        steps.add(robot.sweeperUp());
        steps.add(say("Launching preload"));
        steps.add(shoot());

        steps.add(conditional(
                () -> timeFor(gardenStageWork + parkSeconds(topShotSpot)),
                gardenStage(),
                robot.nothing()));

        steps.add(conditional(
                () -> stagesDone >= 1 && timeFor(topFlowerStageWork + parkSeconds(afterTopFlowerSpot)),
                topFlowerStage(),
                robot.nothing()));

        steps.add(conditional(
                () -> stagesDone >= 2 && timeFor(leftFlowerStageWork + parkSeconds(leftShotSpot)),
                leftFlowerStage(),
                robot.nothing()));

        steps.add(parkStage());

        return sequential(steps.toArray(new Command[0]));
    }

    private Command gardenStage()
    {
        return sequential(
                robot.intakeOn(),
                goTo(startSpot, startToGardenControl, gardenSpot, "Turn left and drive into the garden", GARDEN_TURN_FRACTION),
                say("Collecting garden pollen"),
                waitMs(GARDEN_PICKUP_S * 1000.0),
                robot.rev(),
                goTo(gardenSpot, gardenToTopShotControl, topShotSpot, "Drive to the far side of the hive"),
                robot.intakeOff(),
                say("Launching"),
                shoot(),
                mark(1));
    }

    private Command topFlowerStage()
    {
        List<Command> steps = new ArrayList<>();
        steps.add(robot.sweeperLower());
        steps.add(robot.intakeOn());
        steps.add(goTo(topShotSpot, straight(topShotSpot, topFlowerSpot), topFlowerSpot, "Drive to the top flower"));
        steps.add(say("Collecting top flower"));
        steps.add(robot.collectFlower());
        steps.add(robot.rev());
        if (!topShotInPlace)
        {
            steps.add(goTo(topFlowerSpot, straight(topFlowerSpot, topShotSpot), topShotSpot, "Back to the shot spot"));
        }
        steps.add(robot.intakeOff());
        steps.add(say("Launching"));
        steps.add(shoot());
        steps.add(robot.sweeperUp());
        steps.add(robot.intakeOn());
        steps.add(mark(2));
        return sequential(steps.toArray(new Command[0]));
    }

    private Command leftFlowerStage()
    {
        return sequential(
                robot.sweeperLower(),
                robot.intakeOn(),
                goTo(afterTopFlowerSpot, topToLeftFlowerControl, leftFlowerSpot, "Drive to the left flower"),
                say("Collecting left flower"),
                robot.collectFlower(),
                robot.rev(),
                goTo(leftFlowerSpot, straight(leftFlowerSpot, leftShotSpot), leftShotSpot, "Drive to the shot spot"),
                robot.intakeOff(),
                say("Launching"),
                shoot(),
                robot.sweeperUp(),
                mark(3));
    }

    private Command parkStage()
    {
        Command parkFromLeftShot = goToExact(leftShotSpot, straight(leftShotSpot, parkSpot), parkSpot, "Drive to park");
        Command parkFromTop = goToExact(afterTopFlowerSpot, straight(afterTopFlowerSpot, parkSpot), parkSpot, "Drive to park");
        Command parkFromTopShot = goToExact(topShotSpot, straight(topShotSpot, parkSpot), parkSpot, "Drive to park");
        Command parkFromStart = goToExact(startSpot, startToParkControl, parkSpot, "Drive to park");

        return sequential(
                robot.intakeOff(),
                robot.shooterOff(),
                robot.sweeperUp(),
                conditional(
                        () -> stagesDone >= 3,
                        parkFromLeftShot,
                        conditional(
                                () -> stagesDone == 2,
                                parkFromTop,
                                conditional(
                                        () -> stagesDone == 1,
                                        parkFromTopShot,
                                        parkFromStart))));
    }

    private Command timedPlan()
    {
        List<Command> steps = new ArrayList<>();
        steps.add(say("Launching preload"));
        steps.add(shoot());
        steps.add(say("Leave wall"));
        steps.add(robot.driveFor(DRIVE_POWER, 0.0, CLEAR_WALL_S));
        return sequential(steps.toArray(new Command[0]));
    }

    private Command shoot()
    {
        if (launch && robot.canLaunch())
        {
            return robot.launch();
        }
        return robot.nothing();
    }

    private Command say(String text)
    {
        return instant(() -> status = text);
    }

    private Command mark(int stage)
    {
        return instant(() -> stagesDone = stage);
    }

    private Command goTo(Spot from, Pose control, Spot to, String label)
    {
        return drive(from, control, to, label, 1.0, true);
    }

    private Command goTo(Spot from, Pose control, Spot to, String label, double turnFraction)
    {
        return drive(from, control, to, label, turnFraction, true);
    }

    private Command goToExact(Spot from, Pose control, Spot to, String label)
    {
        return drive(from, control, to, label, 1.0, false);
    }

    private Command drive(Spot from, Pose control, Spot to, String label, double turnFraction, boolean blend)
    {
        double legLength = Math.hypot(to.x - from.x, to.y - from.y);
        double blendIn = 0.0;
        if (blend)
        {
            blendIn = Math.min(BLEND_RADIUS_IN, BLEND_MAX_LEG_FRACTION * legLength);
        }

        return sequential(
                say(label),
                followCurve(from, control, to, turnFraction, blendIn).raceWith(waitMs(PATH_TIMEOUT_S * 1000.0)));
    }

    private Command followCurve(Spot from, Pose control, Spot to, double turnFraction, double blendIn)
    {
        final double startHeading = from.heading;
        final double endHeading = from.heading + shortestTurn(from.heading, to.heading);

        Interpolator headingProfile = Interpolator.linear(startHeading, endHeading);
        if (turnFraction < 1.0)
        {
            headingProfile = Interpolator.piecewise()
                    .until(turnFraction, Interpolator.linear(startHeading, endHeading))
                    .until(1.0, Interpolator.constant(endHeading));
        }
        Path path = curve(from.pose(), control, to.pose()).heading(headingProfile);
        return robot.driveCommand(path, to.pose(), blendIn);
    }

    private double timeLeft()
    {
        return AUTO_LENGTH_S - matchTimer.seconds();
    }

    private boolean timeFor(double neededSeconds)
    {
        return timeLeft() - END_MARGIN_S >= neededSeconds;
    }

    private double estimatedFullRouteSeconds()
    {
        return preloadSeconds
                + gardenStageWork
                + topFlowerStageWork
                + leftFlowerStageWork
                + parkSeconds(leftShotSpot);
    }

    private double parkSeconds(Spot from)
    {
        return legSeconds(from, straight(from, parkSpot), parkSpot);
    }

    private double legSeconds(Spot from, Pose control, Spot to)
    {
        return curveLength(from, control, to) / ESTIMATED_SPEED_IN_PER_S;
    }

    private static double curveLength(Spot from, Pose control, Spot to)
    {
        final int steps = 24;
        double length = 0.0;
        double previousX = from.x;
        double previousY = from.y;
        for (int i = 1; i <= steps; i++)
        {
            double t = (double) i / steps;
            double u = 1.0 - t;
            double x = u * u * from.x + 2.0 * u * t * control.x() + t * t * to.x;
            double y = u * u * from.y + 2.0 * u * t * control.y() + t * t * to.y;
            length += Math.hypot(x - previousX, y - previousY);
            previousX = x;
            previousY = y;
        }
        return length;
    }

    private static Pose straight(Spot from, Spot to)
    {
        return new Pose((from.x + to.x) / 2.0, (from.y + to.y) / 2.0);
    }

    private static double shortestTurn(double from, double to)
    {
        double delta = to - from;
        while (delta > Math.PI)
        {
            delta -= 2.0 * Math.PI;
        }
        while (delta <= -Math.PI)
        {
            delta += 2.0 * Math.PI;
        }
        return delta;
    }

    protected boolean isBlue()
    {
        return false;
    }

    private double redX(double x)
    {
        return isBlue() ? FIELD_IN - x : x;
    }

    private Spot spot(double x, double y, double headingDeg)
    {
        double heading = Math.toRadians(headingDeg);
        if (isBlue())
        {
            return new Spot(FIELD_IN - x, FIELD_IN - y, heading + Math.PI);
        }
        return new Spot(x, y, heading);
    }
}
