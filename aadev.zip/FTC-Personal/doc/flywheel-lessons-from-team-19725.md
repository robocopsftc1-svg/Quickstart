# Flywheel control lessons from Team 19725 (condensed, in English)

Source: the Chinese flywheel docs in github.com/BluePowerRobotics/Team19725_BIOBUZZ (doc/ folder, about 300 KB, last updated late October 2026).
This is a short summary in my own words of what they learned and what applies to us, not a word-for-word translation. Their robot has a different shooter (two flywheels with hood servos), so treat the numbers as examples, not targets.

## What their control law does
- Output power = feedforward + P (+ a small, limited I). No D term.
- Feedforward = kS (power that just starts it moving) + kV x target speed. Same idea as our kS/kV tuner.
- The feedforward is scaled by 12 V / smoothed battery voltage. The feedback part is not scaled.
- Velocity is smoothed with an exponential filter that changes with the error: light smoothing when the error is large (so it reacts fast), heavy smoothing when close to target (to cut encoder noise).

## Lessons that came from testing
1. **Encoder speed steps limit how big kP can be.** Their velocity reading moves in steps of 20 ticks/s. One step of noise times kP becomes a jump in power, so they keep kP x step size under about 0.05. Higher gives buzzing and a limit cycle (the speed oscillates by 1-2 steps). They could not calculate kP from a formula; it was set by this limit.
2. **Skip kD.** Differencing a stepped reading amplifies the noise a lot. Their overshoot came from motor saturation plus the I term, not from too little damping.
3. **Fit kS separately.** A single-point feedforward folds static friction into the slope, and the I term then sits at a large permanent offset. Fit power against speed at 2+ speeds (a line, power = kS + kV x speed). Our kS/kV tuner already does this.
4. **A "boost" after a shot did nothing.** The output is already at 100% during the speed drop after a ball leaves, so adding more can't help. It only delayed leaving saturation and caused overshoot. They deleted it.
5. **Freeze the I term during the drop.** Don't add to it while the speed is far below target after a shot, and don't reset it either. Resume once the error is back in a small band (about 2% of target, at least 2 speed steps).
6. **Battery smoothing must be slow.** A shot pulls the battery down about 1 V for ~0.4 s. If you use that dip directly, the feedforward jumps and overshoots on recovery. They use a ~1 s filter and stop updating it while the flywheel is away from target.
7. **Recovery speed is set by hardware.** After a shot, the time to get back is the speed drop divided by how fast the motor can accelerate at full power. Weak batteries, long wires, and higher target speeds all slow it. At 2250 ticks/s the acceleration was about half what it is at 1750; a lower working speed recovers much faster. They suggest a stronger battery and a lower speed if the shot allows it.
8. **Wait until settled before feeding.** Right after recovery the speed overshoots the target by a little, so firing at once shoots a bit high. They require the error to stay in the band for about 10 frames (~0.1 s) first.

## What this means for us
- Our `Shooter` already uses kS/kV feedforward plus kP, and has no kD in use. That matches their findings.
- Battery compensation is now added (see `Shooter.java`: USE_VOLTAGE_COMP, NOMINAL_BATTERY_V).
- Check our kP against lesson 1: our kP is 0.0026, so our speed readings should not step by more than about 19 ticks/s. If the flywheel buzzes, lower kP.
- Lesson 8 is worth adding later: only feed when the flywheel has been near target for a short time.
- Lesson 5 (freezing the I term) doesn't apply yet because we have no I term.
- Measure shot recovery with real balls. Their empty-shot data was misleading because a ball adds sustained load.
