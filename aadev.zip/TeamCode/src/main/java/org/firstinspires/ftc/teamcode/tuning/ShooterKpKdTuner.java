package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;

@TeleOp(name = "Shooter kP kD Tuner", group = "Tuning")
public class ShooterKpKdTuner extends LinearOpMode
{
    private static final double KP_STEP = 0.0001;
    private static final double KD_STEP = 0.00001;
    private static final double VELOCITY_FILTER = 0.3;
    private static final double REACHED_FRACTION = 0.03;

    private final boolean[] wasDown = new boolean[8];

    private Shooter shooter;
    private double kP = Shooter.FEEDBACK_KP;
    private double kD = Shooter.FEEDBACK_KD;
    private boolean running = false;
    private double velocity = 0.0;
    private double power = 0.0;
    private double peakVelocity = 0.0;
    private double reachedS = -1.0;

    private final ElapsedTime loopTimer = new ElapsedTime();
    private final ElapsedTime runTimer = new ElapsedTime();

    @Override
    public void runOpMode()
    {
        try
        {
            shooter = new Shooter(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Shooter", "shooter_driver motor not found in the config");
            telemetry.update();
            waitForStart();
            return;
        }

        double kS = Shooter.FEEDFORWARD_KS;
        double maxTicks = Shooter.MAX_TICKS_PER_SEC;
        double target = Shooter.SHOOTER_SPEED_FRACTION * maxTicks;
        double kV = 0.0;
        if (maxTicks > 0.0)
        {
            kV = (1.0 - kS) / maxTicks;
        }

        telemetry.addLine("Shooter kP kD Tuner - no balls, keep clear of the flywheel");
        if (maxTicks <= 0.0)
        {
            telemetry.addLine("First run Shooter kS kV Tuner and copy FEEDFORWARD_KS and");
            telemetry.addLine("MAX_TICKS_PER_SEC into Shooter.java. Then come back here.");
        }
        else
        {
            telemetry.addLine("A: start / stop the flywheel at the shooting speed.");
            telemetry.addLine("D-pad up/down: kP. Raise it until the speed reaches the target fast.");
            telemetry.addLine("   Too high and the speed swings around the target.");
            telemetry.addLine("Bumpers: kD. Raise it if the speed overshoots the target.");
            telemetry.addLine("Copy kP into FEEDBACK_KP and kD into FEEDBACK_KD in Shooter.java when it is steady.");
        }
        telemetry.update();

        waitForStart();

        while (opModeIsActive())
        {
            if (maxTicks > 0.0)
            {
                handleButtons();
                runControl(kS, kV, target);
            }
            showTelemetry(kS, kV, maxTicks, target);
        }

        shooter.stopAll();
    }

    private boolean pressed(int index, boolean down)
    {
        boolean result = down && !wasDown[index];
        wasDown[index] = down;
        return result;
    }

    private void handleButtons()
    {
        if (pressed(0, gamepad1.a))
        {
            running = !running;
            if (running)
            {
                velocity = 0.0;
                peakVelocity = 0.0;
                reachedS = -1.0;
                runTimer.reset();
                loopTimer.reset();
            }
            else
            {
                shooter.stopShooter();
                power = 0.0;
            }
        }
        if (pressed(1, gamepad1.dpad_up))
        {
            kP += KP_STEP;
        }
        if (pressed(2, gamepad1.dpad_down))
        {
            kP = Math.max(0.0, kP - KP_STEP);
        }
        if (pressed(3, gamepad1.right_bumper))
        {
            kD += KD_STEP;
        }
        if (pressed(4, gamepad1.left_bumper))
        {
            kD = Math.max(0.0, kD - KD_STEP);
        }
    }

    private void runControl(double kS, double kV, double target)
    {
        if (!running)
        {
            return;
        }

        double dt = Math.max(loopTimer.seconds(), 0.001);
        loopTimer.reset();

        double raw = shooter.getVelocityTicksPerSec();
        double previous = velocity;
        velocity = previous + VELOCITY_FILTER * (raw - previous);
        double accel = (velocity - previous) / dt;
        double error = target - velocity;

        power = kS + kV * target + kP * error - kD * accel;
        power = Math.max(0.0, Math.min(1.0, power));
        shooter.setRawPower(power);

        peakVelocity = Math.max(peakVelocity, velocity);
        if (reachedS < 0.0 && Math.abs(error) <= REACHED_FRACTION * target)
        {
            reachedS = runTimer.seconds();
        }
    }

    private void showTelemetry(double kS, double kV, double maxTicks, double target)
    {
        if (maxTicks > 0.0)
        {
            telemetry.addData("Mode", running ? "running" : "stopped");
            telemetry.addData("Battery", "%.2f V", hardwareMap.voltageSensor.iterator().next().getVoltage());
            telemetry.addData("Target", "%.0f ticks/s", target);
            telemetry.addData("Velocity", "%.0f ticks/s", velocity);
            telemetry.addData("Error", "%.0f ticks/s", target - velocity);
            telemetry.addData("Motor power", "%.3f", power);
            if (running)
            {
                telemetry.addData("Time to reach target", reachedS < 0.0 ? "not yet" : String.format("%.2f s", reachedS));
                telemetry.addData("Overshoot", "%.1f %%", Math.max(0.0, (peakVelocity - target) / target * 100.0));
            }
            telemetry.addData("kS", "%.5f", kS);
            telemetry.addData("kV", "%.7f", kV);
            telemetry.addData("kP", "%.5f", kP);
            telemetry.addData("kD", "%.6f", kD);
        }
        telemetry.update();
    }
}
