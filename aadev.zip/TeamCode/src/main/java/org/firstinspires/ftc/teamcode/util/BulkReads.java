package org.firstinspires.ftc.teamcode.util;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.hardware.HardwareMap;

import java.util.ArrayList;
import java.util.List;

public final class BulkReads
{
    private BulkReads()
    {
    }

    private static List<LynxModule> hubs = new ArrayList<>();

    public static void enable(HardwareMap hardwareMap)
    {
        hubs = hardwareMap.getAll(LynxModule.class);
        for (LynxModule hub : hubs)
        {
            hub.setBulkCachingMode(LynxModule.BulkCachingMode.MANUAL);
        }
    }

    public static void clear()
    {
        for (LynxModule hub : hubs)
        {
            hub.clearBulkCache();
        }
    }
}
