package org.firstinspires.ftc.teamcode.auto;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

@Autonomous(name = "SuperSaiyanBlue", group = "Autonomous")
public class SuperSaiyanBlue extends SuperSaiyanRose
{
    @Override
    protected boolean isBlue()
    {
        return true;
    }
}
