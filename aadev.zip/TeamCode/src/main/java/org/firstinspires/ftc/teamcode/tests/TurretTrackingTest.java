package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;

@TeleOp(name = "Turret Tracking Test", group = "Test")
public class TurretTrackingTest extends LinearOpMode
{
    private static final double JOG_POWER = 0.3;
    private static final double KP_STEP = 0.002;
    private static final double KD_STEP = 0.0002;
    private static final double MIN_POWER_STEP = 0.01;
    private static final double MAX_POWER_STEP = 0.05;

    private final boolean[] wasDown = new boolean[9];

    private TurretTracker turret;

    @Override
    public void runOpMode()
    {
        try
        {
            turret = new TurretTracker(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Turret", "a turret servo or the limelight was not found in the config");
            telemetry.addData("Expected names", "%s, %s, %s", HardwareNames.TURRET_LEFT,
                    HardwareNames.TURRET_RIGHT, HardwareNames.LIMELIGHT);
            telemetry.update();
            waitForStart();
            return;
        }

        telemetry.addLine("Turret Tracking Test - start with the turret roughly centered");
        telemetry.addLine("Left stick left/right: turn the turret by hand (stick right should turn it clockwise)");
        telemetry.addLine("Y: flip direction if stick right turned it the wrong way");
        telemetry.addLine("Hold right bumper: aim at the AprilTag automatically");
        telemetry.addLine("D-pad up/down: kP. D-pad right/left: kD. A/B: min power. Triggers: max power.");
        telemetry.update();

        waitForStart();
        turret.start();

        while (opModeIsActive())
        {
            handleButtons();

            if (gamepad1.right_bumper)
            {
                turret.track();
            }
            else
            {
                turret.setPower(gamepad1.left_stick_x * JOG_POWER);
            }

            showTelemetry();
        }

        turret.stop();
    }

    private boolean pressed(int index, boolean down)
    {
        boolean value = down && !wasDown[index];
        wasDown[index] = down;
        return value;
    }

    private void handleButtons()
    {
        if (pressed(0, gamepad1.dpad_up))
        {
            turret.kP += KP_STEP;
        }
        if (pressed(1, gamepad1.dpad_down))
        {
            turret.kP = Math.max(0.0, turret.kP - KP_STEP);
        }
        if (pressed(2, gamepad1.dpad_right))
        {
            turret.kD += KD_STEP;
        }
        if (pressed(3, gamepad1.dpad_left))
        {
            turret.kD = Math.max(0.0, turret.kD - KD_STEP);
        }
        if (pressed(4, gamepad1.a))
        {
            turret.minPower += MIN_POWER_STEP;
        }
        if (pressed(5, gamepad1.b))
        {
            turret.minPower = Math.max(0.0, turret.minPower - MIN_POWER_STEP);
        }
        if (pressed(6, gamepad1.right_trigger > 0.5))
        {
            turret.maxPower = Math.min(1.0, turret.maxPower + MAX_POWER_STEP);
        }
        if (pressed(7, gamepad1.left_trigger > 0.5))
        {
            turret.maxPower = Math.max(0.0, turret.maxPower - MAX_POWER_STEP);
        }
        if (pressed(8, gamepad1.y))
        {
            turret.invert = !turret.invert;
        }
    }

    private void showTelemetry()
    {
        telemetry.addData("Mode", gamepad1.right_bumper ? "auto-tracking" : "manual");
        if (turret.hasTarget())
        {
            telemetry.addData("Tag", "id %d, %.1f deg off center", turret.getTargetId(), turret.getError());
        }
        else
        {
            telemetry.addData("Tag", "none seen");
        }
        telemetry.addData("Turret power", "%.3f", turret.getCommandedPower());
        telemetry.addData("Flip direction (invert)", turret.invert);
        telemetry.addData("kP", "%.4f", turret.kP);
        telemetry.addData("kD", "%.5f", turret.kD);
        telemetry.addData("Min power", "%.3f", turret.minPower);
        telemetry.addData("Max power", "%.2f", turret.maxPower);
        telemetry.update();
    }
}
