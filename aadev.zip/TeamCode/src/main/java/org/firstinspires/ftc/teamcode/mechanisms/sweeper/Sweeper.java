package org.firstinspires.ftc.teamcode.mechanisms.sweeper;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;

public class Sweeper
{
    public static final Servo.Direction LEFT_DIRECTION = Servo.Direction.FORWARD;
    public static final Servo.Direction RIGHT_DIRECTION = Servo.Direction.REVERSE;

    public static final double STOWED_POSITION = 0.0;
    public static final double DEPLOYED_POSITION = 0.5;
    public static final double SPEED_PER_S = 0.6;

    private static final int PWM_MIN_US = 500;
    private static final int PWM_MAX_US = 2500;
    private static final double MAX_DT_S = 0.1;
    private static final double ARRIVED_TOLERANCE = 0.0005;

    private final Servo leftServo;
    private final Servo rightServo;
    private final ElapsedTime timer = new ElapsedTime();

    private double position = STOWED_POSITION;
    private double target = STOWED_POSITION;

    public Sweeper(HardwareMap hardwareMap)
    {
        leftServo = hardwareMap.get(Servo.class, HardwareNames.SWEEPER_LEFT);
        rightServo = hardwareMap.get(Servo.class, HardwareNames.SWEEPER_RIGHT);
        leftServo.setDirection(LEFT_DIRECTION);
        rightServo.setDirection(RIGHT_DIRECTION);
        applyRange(leftServo);
        applyRange(rightServo);
    }

    public void start()
    {
        position = STOWED_POSITION;
        target = STOWED_POSITION;
        timer.reset();
        command(position);
    }

    public void update()
    {
        double dt = Math.min(timer.seconds(), MAX_DT_S);
        timer.reset();

        double remaining = target - position;
        if (Math.abs(remaining) <= ARRIVED_TOLERANCE)
        {
            return;
        }

        double step = SPEED_PER_S * dt;
        if (Math.abs(remaining) <= step)
        {
            position = target;
        }
        else
        {
            position += Math.signum(remaining) * step;
        }
        command(position);
    }

    public void deploy()
    {
        target = DEPLOYED_POSITION;
    }

    public void stow()
    {
        target = STOWED_POSITION;
    }

    public void toggle()
    {
        if (isDeployed())
        {
            stow();
        }
        else
        {
            deploy();
        }
    }

    public boolean isDeployed()
    {
        return target == DEPLOYED_POSITION;
    }

    public boolean isMoving()
    {
        return Math.abs(target - position) > ARRIVED_TOLERANCE;
    }

    public double getPosition()
    {
        return position;
    }

    private void command(double value)
    {
        leftServo.setPosition(value);
        rightServo.setPosition(value);
    }

    private static void applyRange(Servo servo)
    {
        if (servo instanceof ServoImplEx)
        {
            ((ServoImplEx) servo).setPwmRange(new PwmControl.PwmRange(PWM_MIN_US, PWM_MAX_US));
        }
    }
}
