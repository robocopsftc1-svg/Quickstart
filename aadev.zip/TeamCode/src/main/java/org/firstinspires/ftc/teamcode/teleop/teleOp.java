package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

import org.firstinspires.ftc.teamcode.config.DriveConfig;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Gate;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.ShootingCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;
import org.firstinspires.ftc.teamcode.util.BulkReads;
import org.firstinspires.ftc.teamcode.util.LoopTimer;
import org.firstinspires.ftc.teamcode.util.MatchHandoff;
import org.firstinspires.ftc.teamcode.util.MecanumWheelPowers;

@TeleOp(name = "teleOp", group = "TeleOp")
public class teleOp extends LinearOpMode
{
    private static final double SLOW_MODE_SCALE = 0.35;
    private static final double MAX_POWER_CHANGE_PER_S = 12.0;
    private static final double MAX_RAMP_DT_S = 0.1;
    private static final double HEADING_DISPLAY_PERIOD_S = 0.25;
    private static final double LOOP_WORST_RESET_S = 2.0;
    private static final double TURRET_MANUAL_DEADBAND = 0.1;
    private static final double TURRET_MANUAL_POWER = 0.3;
    private static final double SHOOT_BUTTON_THRESHOLD = 0.5;

    private static final boolean FIELD_CENTRIC_AT_START = false;
    private static final RevHubOrientationOnRobot.LogoFacingDirection HUB_LOGO_DIRECTION =
            RevHubOrientationOnRobot.LogoFacingDirection.LEFT;
    private static final RevHubOrientationOnRobot.UsbFacingDirection HUB_USB_DIRECTION =
            RevHubOrientationOnRobot.UsbFacingDirection.UP;

    private static final double AXIAL_SIGN = 1.0;
    private static final double LATERAL_SIGN = 1.0;
    private static final double TELEOP_LENGTH_S = 120.0;
    private static final double FLOWERS_OPEN_REMAINING_S = 60.0;
    private static final double FINAL_WARNING_REMAINING_S = 30.0;

    private ElapsedTime runtime = new ElapsedTime();
    private ElapsedTime driveTimer = new ElapsedTime();
    private ElapsedTime headingTimer = new ElapsedTime();
    private boolean worstReset = false;
    private LoopTimer loopTimer = new LoopTimer();

    private DcMotor frontLeft;
    private DcMotor backLeft;
    private DcMotor frontRight;
    private DcMotor backRight;
    private Intake intake;
    private Shooter shooter;
    private Gate gate;
    private TurretTracker turret;
    private IMU imu;

    private String imuStatus;
    private String shooterStatus;
    private String gateStatus;

    private boolean fieldCentric;
    private boolean handoffUsed = false;
    private boolean allianceKnown = false;
    private boolean blueAlliance = false;
    private double headingOffset = 0.0;
    private boolean yWasDown = false;
    private boolean xWasDown = false;
    private boolean dpadUpWasDown = false;
    private boolean dpadDownWasDown = false;
    private Sweeper sweeper;
    private String sweeperStatus;
    private boolean flywheelLatched = false;
    private ShootingCycle shootingCycle;
    private boolean cycleButtonWasDown = false;
    private final ElapsedTime flywheelTimer = new ElapsedTime();
    private boolean flowersWarned = false;
    private boolean finalWarned = false;

    private double axial;
    private double lateral;
    private double yaw;
    private double heading;
    private double remaining;
    private double driveScale;
    private boolean slowMode;
    private boolean shooting;

    private double lastFrontLeftWrite = Double.NaN;
    private double lastFrontRightWrite = Double.NaN;
    private double lastBackLeftWrite = Double.NaN;
    private double lastBackRightWrite = Double.NaN;

    private double frontLeftPower;
    private double frontRightPower;
    private double backLeftPower;
    private double backRightPower;

    @Override
    public void runOpMode()
    {
        BulkReads.enable(hardwareMap);
        setupDrive();
        intake = new Intake(hardwareMap);
        setupImu();
        fieldCentric = FIELD_CENTRIC_AT_START && imu != null;
        setupShooter();
        setupGate();
        setupShootingCycle();
        setupSweeper();
        setupTurret();
        if (shootingCycle != null)
        {
            shootingCycle.setTurret(turret);
        }
        loadHandoff();

        while (!isStarted() && !isStopRequested())
        {
            chooseAlliance();
            telemetry.addData("IMU", imuStatus);
            telemetry.addData("Shooter", shooterStatus);
            telemetry.addData("Gate", gateStatus);
            telemetry.addData("Sweeper", sweeperStatus);
            telemetry.addData("Alliance", allianceText());
            telemetry.addData("Heading from auto", handoffText());
            telemetry.addData("Status", "Initialized - D-pad left = RED, D-pad right = BLUE, then press START");
            telemetry.update();
            idle();
        }

        applyAlliance();
        runtime.reset();
        if (turret != null)
        {
            turret.start();
        }
        if (sweeper != null)
        {
            sweeper.start();
        }

        while (opModeIsActive())
        {
            BulkReads.clear();
            loopTimer.tick();
            if (!worstReset && runtime.seconds() >= LOOP_WORST_RESET_S)
            {
                worstReset = true;
                loopTimer.resetWorst();
            }
            readSticks();
            updateFieldCentric();
            driveRobot();
            checkTimeWarnings();
            runIntake();
            runShooter();
            runTurret();
            runGate();
            runShootingCycle();
            runSweeper();
            showTelemetry();
        }

        if (shooter != null)
        {
            shooter.stopAll();
        }
        if (turret != null)
        {
            turret.stop();
        }
    }

    private void setupDrive()
    {
        frontLeft  = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_LEFT);
        backLeft   = hardwareMap.get(DcMotor.class, HardwareNames.BACK_LEFT);
        frontRight = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_RIGHT);
        backRight  = hardwareMap.get(DcMotor.class, HardwareNames.BACK_RIGHT);

        DriveConfig.apply(frontLeft, backLeft, frontRight, backRight);
    }

    private void setupImu()
    {
        imu = null;
        imuStatus = "";
        try
        {
            try
            {
                imu = hardwareMap.get(IMU.class, HardwareNames.IMU);
                imuStatus = "OK";
            }
            catch (Exception notByName)
            {
                java.util.List<IMU> all = hardwareMap.getAll(IMU.class);
                if (all.isEmpty())
                {
                    throw notByName;
                }
                imu = all.get(0);
                imuStatus = "OK";
            }
            imu.initialize(new IMU.Parameters(
                    new RevHubOrientationOnRobot(HUB_LOGO_DIRECTION, HUB_USB_DIRECTION)));
            imu.resetYaw();
        }
        catch (Exception e)
        {
            imu = null;
            imuStatus = "NOT AVAILABLE - " + e.getMessage();
        }
    }

    private void setupShooter()
    {
        shooter = null;
        shooterStatus = "OK";
        try
        {
            shooter = new Shooter(hardwareMap);
        }
        catch (Exception e)
        {
            shooter = null;
            shooterStatus = "NOT AVAILABLE - " + e.getMessage();
        }
    }

    private void setupGate()
    {
        gate = null;
        gateStatus = "OK";
        try
        {
            gate = new Gate(hardwareMap);
        }
        catch (Exception e)
        {
            gate = null;
            gateStatus = "NOT AVAILABLE - " + e.getMessage();
        }
    }

    private void setupShootingCycle()
    {
        shootingCycle = null;
        if (shooter != null)
        {
            shootingCycle = new ShootingCycle(shooter, intake, gate);
        }
    }

    private void setupSweeper()
    {
        sweeper = null;
        sweeperStatus = "OK";
        try
        {
            sweeper = new Sweeper(hardwareMap);
        }
        catch (Exception e)
        {
            sweeper = null;
            sweeperStatus = "NOT AVAILABLE - " + e.getMessage();
        }
    }

    private void loadHandoff()
    {
        handoffUsed = MatchHandoff.isFresh();
        if (handoffUsed)
        {
            allianceKnown = true;
            blueAlliance = MatchHandoff.isBlue();
        }
    }

    private void chooseAlliance()
    {
        if (gamepad1.dpad_left)
        {
            allianceKnown = true;
            blueAlliance = false;
        }
        else if (gamepad1.dpad_right)
        {
            allianceKnown = true;
            blueAlliance = true;
        }
    }

    private void applyAlliance()
    {
        headingOffset = 0.0;
        if (handoffUsed && allianceKnown)
        {
            headingOffset = MatchHandoff.normalize(MatchHandoff.getHeading() - MatchHandoff.driverForwardHeading(blueAlliance));
        }
        if (turret != null && allianceKnown)
        {
            turret.setAlliance(blueAlliance);
        }
    }

    private String allianceText()
    {
        if (!allianceKnown)
        {
            return "not set - turret accepts any tag";
        }
        if (blueAlliance)
        {
            return "BLUE";
        }
        return "RED";
    }

    private String handoffText()
    {
        if (!handoffUsed)
        {
            return "none - press BACK with the robot facing away from the driver before using field-centric";
        }
        return String.format("%.0f s old, robot at %.0f deg on the field", MatchHandoff.getAgeS(), Math.toDegrees(MatchHandoff.getHeading()));
    }

    private void setupTurret()
    {
        turret = null;
        try
        {
            turret = new TurretTracker(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Turret", "not found - turret tracking OFF");
        }
    }

    private void runTurret()
    {
        if (turret == null)
        {
            return;
        }

        double manual = 0.0;
        if (gamepad1.dpad_right)
        {
            manual = 1.0;
        }
        else if (gamepad1.dpad_left)
        {
            manual = -1.0;
        }
        if (Math.abs(manual) > TURRET_MANUAL_DEADBAND)
        {
            turret.manual(manual * TURRET_MANUAL_POWER);
        }
        else
        {
            turret.track();
        }
    }

    private void readSticks()
    {
        axial   = -gamepad1.left_stick_y;
        lateral =  gamepad1.left_stick_x;
        yaw     =  gamepad1.right_stick_x;
    }

    private void updateFieldCentric()
    {
        boolean yDown = gamepad1.y;
        if (yDown && !yWasDown && imu != null)
        {
            fieldCentric = !fieldCentric;
        }
        yWasDown = yDown;

        if (gamepad1.back && imu != null)
        {
            imu.resetYaw();
            headingOffset = 0.0;
        }

        if (imu == null)
        {
            heading = 0.0;
        }
        else if (fieldCentric || headingTimer.seconds() >= HEADING_DISPLAY_PERIOD_S)
        {
            headingTimer.reset();
            heading = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS) + headingOffset;
        }

        if (fieldCentric)
        {
            double rotatedLateral = lateral * Math.cos(heading) + axial * Math.sin(heading);
            double rotatedAxial   = -lateral * Math.sin(heading) + axial * Math.cos(heading);
            lateral = rotatedLateral;
            axial   = rotatedAxial;
        }
    }

    private void driveRobot()
    {
        axial = axial * AXIAL_SIGN;
        lateral = lateral * LATERAL_SIGN;

        double[] power = MecanumWheelPowers.calculate(axial, lateral, yaw);
        double flPower = power[0];
        double frPower = power[1];
        double blPower = power[2];
        double brPower = power[3];

        slowMode = gamepad1.right_bumper;
        if (slowMode)
        {
            driveScale = SLOW_MODE_SCALE;
        }
        else
        {
            driveScale = 1.0;
        }

        double dt = Math.min(driveTimer.seconds(), MAX_RAMP_DT_S);
        driveTimer.reset();
        double maxStep = MAX_POWER_CHANGE_PER_S * dt;

        frontLeftPower = ramp(frontLeftPower, flPower * driveScale, maxStep);
        frontRightPower = ramp(frontRightPower, frPower * driveScale, maxStep);
        backLeftPower = ramp(backLeftPower, blPower * driveScale, maxStep);
        backRightPower = ramp(backRightPower, brPower * driveScale, maxStep);

        if (frontLeftPower != lastFrontLeftWrite)
        {
            lastFrontLeftWrite = frontLeftPower;
            frontLeft.setPower(frontLeftPower);
        }
        if (frontRightPower != lastFrontRightWrite)
        {
            lastFrontRightWrite = frontRightPower;
            frontRight.setPower(frontRightPower);
        }
        if (backLeftPower != lastBackLeftWrite)
        {
            lastBackLeftWrite = backLeftPower;
            backLeft.setPower(backLeftPower);
        }
        if (backRightPower != lastBackRightWrite)
        {
            lastBackRightWrite = backRightPower;
            backRight.setPower(backRightPower);
        }
    }

    private double ramp(double current, double target, double maxStep)
    {
        boolean sameSide = current * target >= 0.0;
        if (sameSide && Math.abs(target) <= Math.abs(current))
        {
            return target;
        }
        double delta = target - current;
        return current + Math.max(-maxStep, Math.min(maxStep, delta));
    }

    private void checkTimeWarnings()
    {
        remaining = TELEOP_LENGTH_S - runtime.seconds();
        if (!flowersWarned && remaining <= FLOWERS_OPEN_REMAINING_S)
        {
            flowersWarned = true;
            gamepad1.rumbleBlips(2);
        }
        if (!finalWarned && remaining <= FINAL_WARNING_REMAINING_S)
        {
            finalWarned = true;
            gamepad1.rumbleBlips(3);
        }
    }

    private void runIntake()
    {
        if (cycleRunning())
        {
            return;
        }
        if (gamepad1.a)
        {
            intake.out();
        }
        else if (gamepad1.b)
        {
            intake.in();
        }
        else
        {
            intake.stop();
        }
    }

    private void runShooter()
    {
        if (cycleRunning())
        {
            shooting = true;
            return;
        }

        boolean xDown = gamepad1.x;
        if (xDown && !xWasDown)
        {
            flywheelLatched = !flywheelLatched;
            flywheelTimer.reset();
        }
        xWasDown = xDown;

        shooting = flywheelLatched;
        if (shooter != null)
        {
            if (shooting)
            {
                shooter.shoot();
                shooter.update();
            }
            else
            {
                shooter.stopShooter();
            }
        }
    }

    private void runGate()
    {
        if (cycleRunning())
        {
            return;
        }
        boolean dpadUpDown = gamepad1.dpad_up;
        if (dpadUpDown && !dpadUpWasDown && gate != null)
        {
            gate.toggle();
        }
        dpadUpWasDown = dpadUpDown;
    }

    private boolean cycleRunning()
    {
        return shootingCycle != null && shootingCycle.isRunning();
    }

    private void runShootingCycle()
    {
        if (shootingCycle == null)
        {
            return;
        }

        boolean buttonDown = gamepad1.right_trigger > SHOOT_BUTTON_THRESHOLD;
        if (buttonDown && !cycleButtonWasDown)
        {
            if (shootingCycle.isRunning())
            {
                shootingCycle.cancel();
            }
            else
            {
                double spinningS = 0.0;
                if (flywheelLatched)
                {
                    spinningS = flywheelTimer.seconds();
                }
                flywheelLatched = false;
                shootingCycle.start(spinningS);
            }
        }
        cycleButtonWasDown = buttonDown;

        shootingCycle.update();
    }

    private void runSweeper()
    {
        if (sweeper == null)
        {
            return;
        }
        boolean dpadDownDown = gamepad1.dpad_down;
        if (dpadDownDown && !dpadDownWasDown)
        {
            sweeper.toggle();
        }
        dpadDownWasDown = dpadDownDown;
        sweeper.update();
    }

    private void showTelemetry()
    {
        telemetry.addData("Time left", "%.0f s", Math.max(0, remaining));
        telemetry.addData("Loop time", "%.1f ms avg, %.1f ms worst", loopTimer.getAverageMs(), loopTimer.getWorstMs());

        if (slowMode)
        {
            telemetry.addData("Slow mode", "ON");
        }
        else
        {
            telemetry.addData("Slow mode", "off");
        }

        if (imu == null)
        {
            telemetry.addData("Field-centric", "no IMU");
        }
        else if (fieldCentric)
        {
            telemetry.addData("Field-centric", "ON");
        }
        else
        {
            telemetry.addData("Field-centric", "off");
        }

        if (imu != null)
        {
            telemetry.addData("Heading", "%.0f deg (offset %.0f deg from auto)", Math.toDegrees(heading), Math.toDegrees(headingOffset));
        }
        telemetry.addData("Alliance", allianceText());

        if (turret == null)
        {
            telemetry.addData("Turret", "not found in the config");
        }
        else if (!turret.hasLimelight())
        {
            telemetry.addData("Turret", "%s, no limelight in config - D-pad left/right only", turret.getState());
        }
        else if (turret.hasTarget())
        {
            telemetry.addData("Turret", "%s, tag %d, %.1f deg off", turret.getState(), turret.getTargetId(), turret.getError());
        }
        else
        {
            telemetry.addData("Turret", "%s, no tag in view", turret.getState());
        }

        showShooterTelemetry();
        showGateTelemetry();
        showSweeperTelemetry();

        String transferNote = "";
        if (!intake.hasTransfer())
        {
            transferNote = " (no transfer motor in config)";
        }
        if (!intake.hasOuter())
        {
            transferNote = transferNote + " (no intake_right motor in config)";
        }
        telemetry.addData("Intake inner+transfer / outer", "%.2f / %.2f%s", intake.getInnerPower(), intake.getOuterPower(), transferNote);
        telemetry.addData("Intake current", "%.1f A now, %.1f A peak, %d jam clears%s", intake.getCurrentAmps(), intake.getPeakCurrentAmps(), intake.getJamCount(), intake.isClearingJam() ? " (clearing)" : "");
        telemetry.addData("Front L/R", "%.2f, %.2f", frontLeftPower, frontRightPower);
        telemetry.addData("Back  L/R", "%.2f, %.2f", backLeftPower, backRightPower);
        telemetry.update();
    }

    private void showSweeperTelemetry()
    {
        if (sweeper == null)
        {
            telemetry.addData("Sweeper", sweeperStatus);
        }
        else
        {
            telemetry.addData("Sweeper", sweeper.isDeployed() ? "DOWN" : "up");
        }
    }

    private void showGateTelemetry()
    {
        if (gate == null)
        {
            telemetry.addData("Gate", gateStatus);
        }
        else if (gate.isOpen())
        {
            telemetry.addData("Gate", "OPEN");
        }
        else
        {
            telemetry.addData("Gate", "closed");
        }
    }

    private void showShooterTelemetry()
    {
        if (shooter == null)
        {
            telemetry.addData("Shooter", shooterStatus);
            return;
        }

        if (shooting)
        {
            telemetry.addData("Shooter", "RUNNING");
        }
        else
        {
            telemetry.addData("Shooter", "off");
        }

        String encoderNote = "";
        if (!shooter.isSpeedControlled())
        {
            encoderNote = " (no encoder, plain power)";
        }
        telemetry.addData("Shooter wheel power", "%.2f%s", shooter.getShooterPower(), encoderNote);
        telemetry.addData("Shooter speed", "%.0f ticks/s", shooter.getVelocityTicksPerSec());
        if (shootingCycle != null)
        {
            String aimNote = "";
            if (shootingCycle.isWaitingForAim())
            {
                aimNote = " (waiting for turret to lock on)";
            }
            telemetry.addData("Shot cycle (right trigger)", "%s%s", shootingCycle.getState(), aimNote);
        }

        if (!shooter.hasCounterRoller())
        {
            telemetry.addData("Counter roller", "not in config (shooter_counter)");
        }
        else if (shooting)
        {
            telemetry.addData("Counter roller", "RUNNING");
        }
        else
        {
            telemetry.addData("Counter roller", "off");
        }
    }
}
