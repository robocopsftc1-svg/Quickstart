package org.firstinspires.ftc.teamcode.mechanisms.shooter;

import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;

public class ShootingCycle
{
    public enum State
    {
        IDLE,
        REVVING,
        FEEDING,
        RESETTING
    }

    public static final double SPINUP_S = 1.5;
    public static final double READY_MIN_SPIN_S = 0.3;
    public static final double READY_TOLERANCE_FRACTION = 0.01;
    public static final double READY_HOLD_S = 0.1;
    public static final double READY_MAX_WAIT_S = 3.0;
    public static final double FEED_S = 3.0;
    public static final double RESET_S = 0.2;
    public static final double AIM_HOLD_S = 0.1;
    public static final double AIM_MAX_WAIT_S = 1.5;

    private final Shooter shooter;
    private final Intake intake;
    private final Gate gate;
    private final ElapsedTime timer = new ElapsedTime();
    private final ElapsedTime readyHoldTimer = new ElapsedTime();
    private final ElapsedTime aimHoldTimer = new ElapsedTime();
    private final ElapsedTime aimWaitTimer = new ElapsedTime();

    private State state = State.IDLE;
    private double spinCreditS = 0.0;
    private boolean inBand = false;
    private boolean aimInBand = false;
    private boolean waitingForAim = false;
    private TurretTracker turret = null;

    public ShootingCycle(Shooter shooter, Intake intake, Gate gate)
    {
        this.shooter = shooter;
        this.intake = intake;
        this.gate = gate;
    }

    public void setTurret(TurretTracker turret)
    {
        this.turret = turret;
    }

    public void start(double flywheelAlreadySpinningS)
    {
        if (state != State.IDLE)
        {
            return;
        }
        spinCreditS = Math.max(0.0, flywheelAlreadySpinningS);
        inBand = false;
        aimInBand = false;
        waitingForAim = false;
        timer.reset();
        state = State.REVVING;
    }

    public void cancel()
    {
        if (state == State.REVVING || state == State.FEEDING)
        {
            enterResetting();
        }
    }

    public void update()
    {
        switch (state)
        {
            case IDLE:
                break;

            case REVVING:
                driveShooter();
                if (gate != null)
                {
                    gate.close();
                }
                if (flywheelReady() && aimReady())
                {
                    waitingForAim = false;
                    timer.reset();
                    intake.setJamProtection(false);
                    state = State.FEEDING;
                }
                break;

            case FEEDING:
                driveShooter();
                if (gate != null)
                {
                    gate.open();
                }
                intake.in();
                if (timer.seconds() >= FEED_S)
                {
                    enterResetting();
                }
                break;

            case RESETTING:
                if (timer.seconds() >= RESET_S)
                {
                    state = State.IDLE;
                }
                break;
        }
    }

    public State getState()
    {
        return state;
    }

    public boolean isWaitingForAim()
    {
        return state == State.REVVING && waitingForAim;
    }

    public boolean isRunning()
    {
        return state == State.REVVING || state == State.FEEDING;
    }

    public boolean isDone()
    {
        return state == State.IDLE;
    }

    private void driveShooter()
    {
        shooter.shoot();
        shooter.update();
    }

    private boolean flywheelReady()
    {
        double spun = timer.seconds() + spinCreditS;
        if (!shooter.usesVelocityControl())
        {
            return spun >= SPINUP_S;
        }
        if (spun >= SPINUP_S + READY_MAX_WAIT_S)
        {
            return true;
        }
        if (spun < READY_MIN_SPIN_S)
        {
            return false;
        }

        double target = shooter.getTargetTicksPerSec();
        double error = Math.abs(shooter.getVelocityTicksPerSec() - target);
        if (error > READY_TOLERANCE_FRACTION * target)
        {
            inBand = false;
            return false;
        }
        if (!inBand)
        {
            inBand = true;
            readyHoldTimer.reset();
        }
        return readyHoldTimer.seconds() >= READY_HOLD_S;
    }

    private boolean aimReady()
    {
        if (turret == null || !turret.isAiming())
        {
            return true;
        }
        if (!waitingForAim)
        {
            waitingForAim = true;
            aimInBand = false;
            aimWaitTimer.reset();
        }
        if (aimWaitTimer.seconds() >= AIM_MAX_WAIT_S)
        {
            return true;
        }
        if (!turret.isLockedOn())
        {
            aimInBand = false;
            return false;
        }
        if (!aimInBand)
        {
            aimInBand = true;
            aimHoldTimer.reset();
        }
        return aimHoldTimer.seconds() >= AIM_HOLD_S;
    }

    private void enterResetting()
    {
        intake.setJamProtection(true);
        intake.stop();
        shooter.stopShooter();
        if (gate != null)
        {
            gate.close();
        }
        timer.reset();
        state = State.RESETTING;
    }
}
