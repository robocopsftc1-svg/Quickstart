package org.firstinspires.ftc.teamcode.config;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

public final class DriveConfig
{
    private DriveConfig()
    {
    }

    public static final DcMotorSimple.Direction FRONT_LEFT_DIRECTION  = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction BACK_LEFT_DIRECTION   = DcMotorSimple.Direction.REVERSE;
    public static final DcMotorSimple.Direction FRONT_RIGHT_DIRECTION = DcMotorSimple.Direction.FORWARD;
    public static final DcMotorSimple.Direction BACK_RIGHT_DIRECTION  = DcMotorSimple.Direction.FORWARD;

    public static void apply(DcMotor frontLeft, DcMotor backLeft, DcMotor frontRight, DcMotor backRight)
    {
        frontLeft.setDirection(FRONT_LEFT_DIRECTION);
        backLeft.setDirection(BACK_LEFT_DIRECTION);
        frontRight.setDirection(FRONT_RIGHT_DIRECTION);
        backRight.setDirection(BACK_RIGHT_DIRECTION);

        setupMotor(frontLeft);
        setupMotor(backLeft);
        setupMotor(frontRight);
        setupMotor(backRight);
    }

    private static void setupMotor(DcMotor motor)
    {
        motor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }
}
