package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.PwmControl;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;

@TeleOp(name = "Sweeper Test", group = "Test")
public class SweeperTest extends LinearOpMode
{
    private static final double START_POSITION = 0.5;
    private static final double JOG_SPEED_PER_S = 0.25;
    private static final double SLOW_FACTOR = 0.25;
    private static final double STICK_DEADBAND = 0.1;
    private static final int PWM_MIN_US = 500;
    private static final int PWM_MAX_US = 2500;

    private static final int BOTH = 0;
    private static final int LEFT_ONLY = 1;
    private static final int RIGHT_ONLY = 2;

    private final boolean[] wasDown = new boolean[6];

    private Servo leftServo;
    private Servo rightServo;

    private double position = START_POSITION;
    private int mode = BOTH;
    private boolean rightReversed = Sweeper.RIGHT_DIRECTION == Servo.Direction.REVERSE;
    private Double stowedSaved = null;
    private Double deployedSaved = null;

    @Override
    public void runOpMode()
    {
        try
        {
            leftServo = hardwareMap.get(Servo.class, HardwareNames.SWEEPER_LEFT);
            rightServo = hardwareMap.get(Servo.class, HardwareNames.SWEEPER_RIGHT);
        }
        catch (Exception e)
        {
            telemetry.addData("Sweeper", "a sweeper servo was not found in the config");
            telemetry.addData("Expected names", "%s, %s", HardwareNames.SWEEPER_LEFT, HardwareNames.SWEEPER_RIGHT);
            telemetry.update();
            waitForStart();
            return;
        }

        applyRange(leftServo);
        applyRange(rightServo);
        leftServo.setDirection(Sweeper.LEFT_DIRECTION);
        applyRightDirection();

        telemetry.addLine("Sweeper Test - the servos must be in servo (positional) mode");
        telemetry.addLine("The sweeper jumps to position " + START_POSITION + " when you press Start.");
        telemetry.addLine("Hold the sweeper clear or change START_POSITION first.");
        telemetry.addLine("Left stick up/down: move slowly. Hold left trigger for fine moves.");
        telemetry.addLine("D-pad up: both servos. D-pad left: left only. D-pad right: right only.");
        telemetry.addLine("Y: flip the right servo direction. A: save stowed. B: save deployed.");
        telemetry.update();

        waitForStart();

        ElapsedTime timer = new ElapsedTime();
        applyPosition();

        while (opModeIsActive())
        {
            double dt = Math.min(timer.seconds(), 0.1);
            timer.reset();

            handleButtons();

            double stick = -gamepad1.left_stick_y;
            if (Math.abs(stick) > STICK_DEADBAND)
            {
                double speed = JOG_SPEED_PER_S * (gamepad1.left_trigger > 0.5 ? SLOW_FACTOR : 1.0);
                position = Math.max(0.0, Math.min(1.0, position + stick * speed * dt));
            }

            applyPosition();
            showTelemetry();
        }
    }

    private boolean pressed(int index, boolean down)
    {
        boolean value = down && !wasDown[index];
        wasDown[index] = down;
        return value;
    }

    private void handleButtons()
    {
        if (pressed(0, gamepad1.dpad_up))
        {
            mode = BOTH;
        }
        if (pressed(1, gamepad1.dpad_left))
        {
            mode = LEFT_ONLY;
        }
        if (pressed(2, gamepad1.dpad_right))
        {
            mode = RIGHT_ONLY;
        }
        if (pressed(3, gamepad1.y))
        {
            rightReversed = !rightReversed;
            applyRightDirection();
        }
        if (pressed(4, gamepad1.a))
        {
            stowedSaved = position;
        }
        if (pressed(5, gamepad1.b))
        {
            deployedSaved = position;
        }
    }

    private void applyPosition()
    {
        if (mode != RIGHT_ONLY)
        {
            leftServo.setPosition(position);
        }
        if (mode != LEFT_ONLY)
        {
            rightServo.setPosition(position);
        }
    }

    private void applyRightDirection()
    {
        rightServo.setDirection(rightReversed ? Servo.Direction.REVERSE : Servo.Direction.FORWARD);
    }

    private static void applyRange(Servo servo)
    {
        if (servo instanceof ServoImplEx)
        {
            ((ServoImplEx) servo).setPwmRange(new PwmControl.PwmRange(PWM_MIN_US, PWM_MAX_US));
        }
    }

    private void showTelemetry()
    {
        String moving = mode == BOTH ? "both servos" : (mode == LEFT_ONLY ? "left only" : "right only");
        telemetry.addData("Moving", moving);
        telemetry.addData("Position", "%.3f", position);
        telemetry.addData("Right servo reversed", rightReversed);
        telemetry.addData("Saved stowed", stowedSaved == null ? "not saved (press A)" : String.format("%.3f", stowedSaved));
        telemetry.addData("Saved deployed", deployedSaved == null ? "not saved (press B)" : String.format("%.3f", deployedSaved));
        telemetry.addLine("Copy into Sweeper.java: STOWED_POSITION, DEPLOYED_POSITION, RIGHT_DIRECTION");
        telemetry.update();
    }
}
