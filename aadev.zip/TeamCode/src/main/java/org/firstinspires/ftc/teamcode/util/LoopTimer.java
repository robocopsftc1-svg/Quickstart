package org.firstinspires.ftc.teamcode.util;

import com.qualcomm.robotcore.util.ElapsedTime;

public class LoopTimer
{
    private static final double AVERAGE_WEIGHT = 0.05;

    private final ElapsedTime clock = new ElapsedTime();
    private boolean first = true;
    private double averageMs = 0.0;
    private double worstMs = 0.0;

    public void tick()
    {
        double ms = clock.milliseconds();
        clock.reset();
        if (first)
        {
            first = false;
            return;
        }
        if (averageMs == 0.0)
        {
            averageMs = ms;
        }
        else
        {
            averageMs += AVERAGE_WEIGHT * (ms - averageMs);
        }
        worstMs = Math.max(worstMs, ms);
    }

    public void resetWorst()
    {
        worstMs = 0.0;
    }

    public double getAverageMs()
    {
        return averageMs;
    }

    public double getWorstMs()
    {
        return worstMs;
    }
}
