package org.firstinspires.ftc.teamcode.mechanisms.sweeper;

import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;

public class FlowerCycle
{
    public enum State
    {
        IDLE,
        LOWERING,
        COLLECTING,
        RAISING
    }

    public static final double COLLECT_S = 1.5;
    public static final double SWEEPER_MAX_MOVE_S = 2.0;

    private final Sweeper sweeper;
    private final Intake intake;
    private final ElapsedTime timer = new ElapsedTime();

    private State state = State.IDLE;
    private boolean stowWhenDone = true;
    private boolean cancelled = false;

    public FlowerCycle(Sweeper sweeper, Intake intake)
    {
        this.sweeper = sweeper;
        this.intake = intake;
    }

    public void start(boolean stowWhenDone)
    {
        if (state != State.IDLE)
        {
            return;
        }
        this.stowWhenDone = stowWhenDone;
        cancelled = false;
        sweeper.deploy();
        timer.reset();
        state = State.LOWERING;
    }

    public void cancel()
    {
        if (state == State.LOWERING || state == State.COLLECTING)
        {
            cancelled = true;
            intake.stop();
            sweeper.stow();
            timer.reset();
            state = State.RAISING;
        }
    }

    public void update()
    {
        switch (state)
        {
            case IDLE:
                break;

            case LOWERING:
                intake.in();
                if (!sweeper.isMoving() || timer.seconds() >= SWEEPER_MAX_MOVE_S)
                {
                    timer.reset();
                    state = State.COLLECTING;
                }
                break;

            case COLLECTING:
                intake.in();
                if (timer.seconds() >= COLLECT_S)
                {
                    if (stowWhenDone)
                    {
                        sweeper.stow();
                        timer.reset();
                        state = State.RAISING;
                    }
                    else
                    {
                        state = State.IDLE;
                    }
                }
                break;

            case RAISING:
                if (!cancelled)
                {
                    intake.in();
                }
                if (!sweeper.isMoving() || timer.seconds() >= SWEEPER_MAX_MOVE_S)
                {
                    if (!cancelled)
                    {
                        intake.stop();
                    }
                    state = State.IDLE;
                }
                break;
        }
    }

    public State getState()
    {
        return state;
    }

    public boolean isRunning()
    {
        return state != State.IDLE;
    }

    public boolean isDone()
    {
        return state == State.IDLE;
    }
}
