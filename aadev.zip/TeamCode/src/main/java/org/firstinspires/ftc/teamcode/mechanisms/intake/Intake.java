package org.firstinspires.ftc.teamcode.mechanisms.intake;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.teamcode.config.HardwareNames;

public class Intake
{
    public static final double INTAKE_POWER  = 0.8;
    public static final double REVERSE_POWER = 1.0;
    public static final double RAMP_TIME_S = 0.25;
    private static final double MAX_STEP_TIME_S = 0.1;

    public static final double JAM_CURRENT_AMPS = 0.0;
    public static final double JAM_DETECT_S = 0.3;
    public static final double JAM_REVERSE_S = 0.4;
    public static final double JAM_COOLDOWN_S = 1.0;
    private static final double CURRENT_READ_PERIOD_S = 0.1;
    private static final double RAMP_DONE_MARGIN = 0.05;

    private static final DcMotorSimple.Direction INNER_DIRECTION    = DcMotorSimple.Direction.REVERSE;
    private static final DcMotorSimple.Direction OUTER_DIRECTION    = DcMotorSimple.Direction.FORWARD;
    private static final DcMotorSimple.Direction TRANSFER_DIRECTION = DcMotorSimple.Direction.FORWARD;

    private static class Stage
    {
        private DcMotor[] motors;
        private double power = 0.0;
        private double target = 0.0;
        private double lastWritten = Double.NaN;
        private ElapsedTime clock = new ElapsedTime();

        Stage(DcMotor[] motors)
        {
            this.motors = motors;
        }

        void setTarget(double t)
        {
            if (t == 0.0)
            {
                stop();
            }
            else
            {
                target = t;
            }
        }

        void stop()
        {
            target = 0.0;
            clock.reset();
            apply(0.0);
        }

        void update()
        {
            double dt = Math.min(clock.seconds(), MAX_STEP_TIME_S);
            clock.reset();

            if (target == 0.0)
            {
                apply(0.0);
                return;
            }

            double step = dt / RAMP_TIME_S;
            double next = power;
            if (next < target)
            {
                next = Math.min(target, next + step);
            }
            else if (next > target)
            {
                next = Math.max(target, next - step);
            }
            apply(next);
        }

        void apply(double p)
        {
            power = p;
            if (p == lastWritten)
            {
                return;
            }
            lastWritten = p;
            for (int i = 0; i < motors.length; i++)
            {
                motors[i].setPower(p);
            }
        }
    }

    private DcMotor inner;
    private DcMotor outer;
    private DcMotor transfer;
    private Stage innerStage;
    private Stage outerStage;

    private DcMotorEx innerEx = null;
    private DcMotorEx outerEx = null;
    private final ElapsedTime currentTimer = new ElapsedTime();
    private final ElapsedTime jamTimer = new ElapsedTime();
    private final ElapsedTime reverseTimer = new ElapsedTime();
    private final ElapsedTime cooldownTimer = new ElapsedTime();
    private boolean reversing = false;
    private boolean jamProtection = true;
    private boolean wasRunning = false;
    private double currentAmps = 0.0;
    private double innerAmps = 0.0;
    private double outerAmps = 0.0;
    private boolean readInnerNext = true;
    private double peakAmps = 0.0;
    private int jamCount = 0;

    public Intake(HardwareMap hardwareMap)
    {
        inner = hardwareMap.get(DcMotor.class, HardwareNames.INTAKE_LEFT);

        outer = null;
        try
        {
            outer = hardwareMap.get(DcMotor.class, HardwareNames.INTAKE_RIGHT);
        }
        catch (Exception e)
        {
            outer = null;
        }

        transfer = null;
        try
        {
            transfer = hardwareMap.get(DcMotor.class, HardwareNames.TRANSFER);
        }
        catch (Exception e)
        {
            transfer = null;
        }

        inner.setDirection(INNER_DIRECTION);
        if (outer != null)
        {
            outer.setDirection(OUTER_DIRECTION);
        }
        if (transfer != null)
        {
            transfer.setDirection(TRANSFER_DIRECTION);
        }

        setupMotor(inner);
        if (outer != null)
        {
            setupMotor(outer);
        }
        if (transfer != null)
        {
            setupMotor(transfer);
        }

        if (transfer != null)
        {
            innerStage = new Stage(new DcMotor[] {inner, transfer});
        }
        else
        {
            innerStage = new Stage(new DcMotor[] {inner});
        }
        if (outer != null)
        {
            outerStage = new Stage(new DcMotor[] {outer});
        }
        else
        {
            outerStage = new Stage(new DcMotor[0]);
        }

        if (inner instanceof DcMotorEx)
        {
            innerEx = (DcMotorEx) inner;
        }
        if (outer instanceof DcMotorEx)
        {
            outerEx = (DcMotorEx) outer;
        }
    }

    private void setupMotor(DcMotor motor)
    {
        motor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }

    public void control(boolean innerButton, boolean outerButton, boolean reverseButton)
    {
        if (reverseButton)
        {
            innerStage.setTarget(-REVERSE_POWER);
            outerStage.setTarget(-REVERSE_POWER);
        }
        else if (innerButton && outerButton)
        {
            innerStage.stop();
            outerStage.stop();
        }
        else
        {
            double innerTarget = 0.0;
            if (innerButton)
            {
                innerTarget = INTAKE_POWER;
            }
            double outerTarget = 0.0;
            if (outerButton)
            {
                outerTarget = INTAKE_POWER;
            }
            innerStage.setTarget(innerTarget);
            outerStage.setTarget(outerTarget);
        }
        update();
    }

    public void in()
    {
        innerStage.setTarget(INTAKE_POWER);
        outerStage.setTarget(INTAKE_POWER);
        update();
    }

    public void out()
    {
        innerStage.setTarget(-REVERSE_POWER);
        outerStage.setTarget(-REVERSE_POWER);
        update();
    }

    public void stop()
    {
        innerStage.stop();
        outerStage.stop();
    }

    public void update()
    {
        if (reversing)
        {
            continueReverse();
            return;
        }
        innerStage.update();
        outerStage.update();
        checkJam();
    }

    public void setJamProtection(boolean enabled)
    {
        jamProtection = enabled;
        jamTimer.reset();
    }

    public boolean isClearingJam()
    {
        return reversing;
    }

    public int getJamCount()
    {
        return jamCount;
    }

    public double getCurrentAmps()
    {
        return currentAmps;
    }

    public double getPeakCurrentAmps()
    {
        return peakAmps;
    }

    private boolean forwardRequested()
    {
        return innerStage.target > 0.0 || outerStage.target > 0.0;
    }

    private boolean rampDone()
    {
        boolean done = true;
        if (innerStage.target > 0.0 && innerStage.power < innerStage.target - RAMP_DONE_MARGIN)
        {
            done = false;
        }
        if (outerStage.target > 0.0 && outerStage.power < outerStage.target - RAMP_DONE_MARGIN)
        {
            done = false;
        }
        return done;
    }

    private double readCurrentAmps()
    {
        boolean readInner = innerEx != null && (outerEx == null || readInnerNext);
        if (readInner)
        {
            innerAmps = innerEx.getCurrent(CurrentUnit.AMPS);
        }
        else if (outerEx != null)
        {
            outerAmps = outerEx.getCurrent(CurrentUnit.AMPS);
        }
        readInnerNext = !readInnerNext;
        return Math.max(innerAmps, outerAmps);
    }

    private void checkJam()
    {
        if (!forwardRequested())
        {
            wasRunning = false;
            jamTimer.reset();
            return;
        }
        if (!wasRunning)
        {
            wasRunning = true;
            peakAmps = 0.0;
            currentTimer.reset();
            jamTimer.reset();
            return;
        }
        if (currentTimer.seconds() < CURRENT_READ_PERIOD_S)
        {
            return;
        }
        currentTimer.reset();

        currentAmps = readCurrentAmps();
        boolean steady = rampDone();
        if (steady)
        {
            peakAmps = Math.max(peakAmps, currentAmps);
        }

        boolean jammed = JAM_CURRENT_AMPS > 0.0
                && jamProtection
                && steady
                && cooldownTimer.seconds() >= JAM_COOLDOWN_S
                && currentAmps >= JAM_CURRENT_AMPS;
        if (!jammed)
        {
            jamTimer.reset();
            return;
        }
        if (jamTimer.seconds() >= JAM_DETECT_S)
        {
            reversing = true;
            jamCount++;
            reverseTimer.reset();
            innerStage.apply(-REVERSE_POWER);
            outerStage.apply(-REVERSE_POWER);
        }
    }

    private void continueReverse()
    {
        if (!forwardRequested() || reverseTimer.seconds() >= JAM_REVERSE_S)
        {
            reversing = false;
            innerStage.apply(0.0);
            outerStage.apply(0.0);
            innerStage.clock.reset();
            outerStage.clock.reset();
            cooldownTimer.reset();
            jamTimer.reset();
            return;
        }
        innerStage.apply(-REVERSE_POWER);
        outerStage.apply(-REVERSE_POWER);
    }

    public double getInnerPower()
    {
        return innerStage.power;
    }

    public double getOuterPower()
    {
        return outerStage.power;
    }

    public boolean hasOuter()
    {
        return outer != null;
    }

    public boolean hasTransfer()
    {
        return transfer != null;
    }

    public double getPower()
    {
        double a = innerStage.power;
        double b = outerStage.power;
        if (Math.abs(a) >= Math.abs(b))
        {
            return a;
        }
        return b;
    }

    public void setPowers(double innerPower, double outerPower)
    {
        innerStage.target = 0.0;
        outerStage.target = 0.0;
        innerStage.apply(innerPower);
        outerStage.apply(outerPower);
    }
}
