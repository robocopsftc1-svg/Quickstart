package org.firstinspires.ftc.teamcode.mechanisms.shooter;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;

public class Shooter
{
    public static final double SHOOTER_SPEED_FRACTION = 0.55;
    public static final double COUNTER_ROLLER_POWER = 0.65;
    public static final double TICKS_PER_REV = 28.0;

    public static final double FEEDFORWARD_KS = 0.0;
    public static final double MAX_TICKS_PER_SEC = 0.0;
    public static final double FEEDBACK_KP = 0.0;
    public static final double FEEDBACK_KD = 0.0;

    private static final double ENCODER_CHECK_S = 0.8;
    private static final double ENCODER_MIN_TICKS_PER_SEC = 0.8;
    private static final double VELOCITY_FILTER = 0.3;
    private static final double MIN_CONTROL_DT_S = 0.005;
    private static final double MAX_CONTROL_DT_S = 0.1;

    private static final DcMotorSimple.Direction SHOOTER_DRIVER_DIRECTION = DcMotorSimple.Direction.FORWARD;
    private static final DcMotorSimple.Direction COUNTER_ROLLER_DIRECTION = DcMotorSimple.Direction.FORWARD;

    private DcMotor shooterDriver;
    private DcMotorEx shooterEx;
    private DcMotor counterRoller;
    private ElapsedTime spinTimer = new ElapsedTime();
    private ElapsedTime controlTimer = new ElapsedTime();
    private boolean spinning = false;
    private boolean speedControl = true;
    private boolean controlStarted = false;
    private double maxTicksPerSec = MAX_TICKS_PER_SEC;
    private double feedbackKp = FEEDBACK_KP;
    private double feedbackKd = FEEDBACK_KD;
    private double filteredVelocity = 0.0;
    private double lastShooterPower = Double.NaN;
    private double lastCounterPower = Double.NaN;

    public Shooter(HardwareMap hardwareMap)
    {
        shooterDriver = hardwareMap.get(DcMotor.class, HardwareNames.SHOOTER_DRIVER);
        shooterDriver.setDirection(SHOOTER_DRIVER_DIRECTION);
        shooterDriver.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        if (shooterDriver instanceof DcMotorEx)
        {
            shooterEx = (DcMotorEx) shooterDriver;
        }
        else
        {
            shooterEx = null;
        }

        counterRoller = null;
        try
        {
            counterRoller = hardwareMap.get(DcMotor.class, HardwareNames.SHOOTER_COUNTER);
            counterRoller.setDirection(COUNTER_ROLLER_DIRECTION);
            counterRoller.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            counterRoller.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        catch (Exception e)
        {
            counterRoller = null;
        }
    }

    public boolean hasCounterRoller()
    {
        return counterRoller != null;
    }

    public void shoot()
    {
        if (!spinning)
        {
            spinning = true;
            controlStarted = false;
            spinTimer.reset();
            controlTimer.reset();
            filteredVelocity = getVelocityTicksPerSec();
            shooterDriver.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
        driveAtTarget();
        if (counterRoller != null)
        {
            writeCounter(COUNTER_ROLLER_POWER);
        }
    }

    public void update()
    {
        if (!spinning)
        {
            return;
        }
        if (speedControl && spinTimer.seconds() > ENCODER_CHECK_S)
        {
            if (getVelocityTicksPerSec() < ENCODER_MIN_TICKS_PER_SEC)
            {
                speedControl = false;
            }
        }
        driveAtTarget();
    }

    private void driveAtTarget()
    {
        if (!usesVelocityControl())
        {
            writeShooter(SHOOTER_SPEED_FRACTION);
            return;
        }

        double dt = controlTimer.seconds();
        if (controlStarted && dt < MIN_CONTROL_DT_S)
        {
            return;
        }
        controlStarted = true;
        dt = Math.min(Math.max(dt, MIN_CONTROL_DT_S), MAX_CONTROL_DT_S);
        controlTimer.reset();

        double raw = getVelocityTicksPerSec();
        double previous = filteredVelocity;
        filteredVelocity = previous + VELOCITY_FILTER * (raw - previous);
        double acceleration = (filteredVelocity - previous) / dt;

        double target = getTargetTicksPerSec();
        double kV = (1.0 - FEEDFORWARD_KS) / maxTicksPerSec;
        double error = target - filteredVelocity;

        double power = FEEDFORWARD_KS + kV * target + feedbackKp * error - feedbackKd * acceleration;
        power = Math.max(0.0, Math.min(1.0, power));
        writeShooter(power);
    }

    private void writeShooter(double power)
    {
        if (power == lastShooterPower)
        {
            return;
        }
        lastShooterPower = power;
        shooterDriver.setPower(power);
    }

    private void writeCounter(double power)
    {
        if (counterRoller == null || power == lastCounterPower)
        {
            return;
        }
        lastCounterPower = power;
        counterRoller.setPower(power);
    }

    public boolean usesVelocityControl()
    {
        return shooterEx != null && speedControl && maxTicksPerSec > 0.0;
    }

    public double getTargetTicksPerSec()
    {
        return SHOOTER_SPEED_FRACTION * maxTicksPerSec;
    }

    public void setMaxTicksPerSec(double value)
    {
        maxTicksPerSec = value;
        if (spinning)
        {
            driveAtTarget();
        }
    }

    public void setFeedback(double kP, double kD)
    {
        feedbackKp = kP;
        feedbackKd = kD;
    }

    public double getFeedbackKp()
    {
        return feedbackKp;
    }

    public double getFeedbackKd()
    {
        return feedbackKd;
    }

    public double getMaxTicksPerSec()
    {
        return maxTicksPerSec;
    }

    public void spinFullPower()
    {
        spinning = false;
        shooterDriver.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        lastShooterPower = Double.NaN;
        writeShooter(1.0);
    }

    public void setRawPower(double power)
    {
        spinning = false;
        if (shooterDriver.getMode() != DcMotor.RunMode.RUN_WITHOUT_ENCODER)
        {
            shooterDriver.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            lastShooterPower = Double.NaN;
        }
        writeShooter(power);
    }

    public boolean isSpeedControlled()
    {
        return speedControl;
    }

    public void stopShooter()
    {
        spinning = false;
        writeShooter(0.0);
        writeCounter(0.0);
    }

    public void stopAll()
    {
        stopShooter();
    }

    public double getShooterPower()
    {
        return shooterDriver.getPower();
    }

    public double getVelocityTicksPerSec()
    {
        if (shooterEx == null)
        {
            return 0.0;
        }
        return Math.abs(shooterEx.getVelocity());
    }

    public double getRpm()
    {
        return getVelocityTicksPerSec() / TICKS_PER_REV * 60.0;
    }
}
