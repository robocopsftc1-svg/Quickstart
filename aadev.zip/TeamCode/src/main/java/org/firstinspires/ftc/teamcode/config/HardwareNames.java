package org.firstinspires.ftc.teamcode.config;

public final class HardwareNames
{
    private HardwareNames()
    {
    }

    public static final String FRONT_LEFT  = "left_front";
    public static final String BACK_LEFT   = "left_back";
    public static final String FRONT_RIGHT = "right_front";
    public static final String BACK_RIGHT  = "right_back";

    public static final String IMU      = "imu";
    public static final String PINPOINT = "pinpoint";

    public static final String INTAKE_LEFT  = "intake_left";
    public static final String TRANSFER     = "transfer";

    public static final String INTAKE_RIGHT = "intake_right";
    public static final String SHOOTER_DRIVER  = "shooter_driver";
    public static final String SHOOTER_COUNTER = "shooter_counter";
    public static final String STOPPER = "stopper";

    public static final String LIMELIGHT = "limelight";

    public static final String TURRET_LEFT     = "turret_left";
    public static final String TURRET_RIGHT    = "turret_right";

    public static final String SWEEPER_LEFT  = "sweeper_left";
    public static final String SWEEPER_RIGHT = "sweeper_right";
}
