package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;

@TeleOp(name = "Shooter kS kV Tuner", group = "Tuning")
public class ShooterKsKvTuner extends LinearOpMode
{
    private static final double KS_RAMP_STEP = 0.0005;
    private static final double KS_RAMP_STEP_S = 0.1;
    private static final double KS_MOVING_TICKS_PER_SEC = 20.0;
    private static final double KS_MAX_POWER = 0.3;

    private static final double[] KV_POWERS = {0.4, 0.6, 0.8, 1.0};
    private static final double KV_SETTLE_S = 3.0;
    private static final double KV_SAMPLE_S = 1.0;

    private Shooter shooter;
    private double kS = 0.0;
    private double kV = 0.0;
    private double maxTicksPerSec = 0.0;
    private final double[] measured = new double[KV_POWERS.length];
    private boolean kvDone = false;
    private String message = "";

    private boolean aWasDown = false;
    private boolean bWasDown = false;

    @Override
    public void runOpMode()
    {
        try
        {
            shooter = new Shooter(hardwareMap);
        }
        catch (Exception e)
        {
            telemetry.addData("Shooter", "shooter_driver motor not found in the config");
            telemetry.update();
            waitForStart();
            return;
        }

        telemetry.addLine("Shooter kS kV Tuner - no balls, keep clear of the flywheel, fresh battery");
        telemetry.addLine("A: find kS. Power creeps up until the flywheel just starts to turn.");
        telemetry.addLine("B: find kV. Runs 4 power steps, about 16 s, ends at full power.");
        telemetry.addLine("Run A first. Press A or B again after it finishes to redo.");
        telemetry.update();

        waitForStart();

        while (opModeIsActive())
        {
            boolean aDown = gamepad1.a;
            if (aDown && !aWasDown)
            {
                findKs();
            }
            aWasDown = aDown;

            boolean bDown = gamepad1.b;
            if (bDown && !bWasDown)
            {
                findKv();
            }
            bWasDown = bDown;

            showResults();
        }

        shooter.stopAll();
    }

    private void findKs()
    {
        kS = 0.0;
        message = "";
        ElapsedTime stepTimer = new ElapsedTime();
        double power = 0.0;
        boolean moved = false;

        shooter.setRawPower(power);
        while (opModeIsActive() && !moved && power <= KS_MAX_POWER)
        {
            double velocity = shooter.getVelocityTicksPerSec();
            telemetry.addData("Finding kS", "power %.4f", power);
            telemetry.addData("Velocity", "%.0f ticks/s", velocity);
            telemetry.update();

            if (velocity > KS_MOVING_TICKS_PER_SEC)
            {
                moved = true;
                kS = power;
            }
            else if (stepTimer.seconds() >= KS_RAMP_STEP_S)
            {
                stepTimer.reset();
                power += KS_RAMP_STEP;
                shooter.setRawPower(power);
            }
        }

        shooter.stopShooter();
        if (!moved)
        {
            message = "kS: no movement up to power " + KS_MAX_POWER + ". Check the encoder cable and motor.";
        }
    }

    private void findKv()
    {
        kvDone = false;
        message = "";
        if (kS <= 0.0)
        {
            message = "Run A first to find kS.";
            return;
        }

        for (int i = 0; i < KV_POWERS.length && opModeIsActive(); i++)
        {
            measured[i] = runStep(KV_POWERS[i], i);
        }
        shooter.stopShooter();

        if (!opModeIsActive())
        {
            return;
        }

        double top = 0.0;
        double numerator = 0.0;
        double denominator = 0.0;
        for (int i = 0; i < KV_POWERS.length; i++)
        {
            numerator += measured[i] * (KV_POWERS[i] - kS);
            denominator += measured[i] * measured[i];
            top = Math.max(top, measured[i]);
        }

        if (denominator <= 0.0 || top < KS_MOVING_TICKS_PER_SEC)
        {
            message = "kV: no speed reading. Check the encoder cable and motor.";
            return;
        }

        kV = numerator / denominator;
        maxTicksPerSec = (1.0 - kS) / kV;
        kvDone = true;
    }

    private double runStep(double power, int index)
    {
        shooter.setRawPower(power);
        ElapsedTime timer = new ElapsedTime();
        double sum = 0.0;
        int count = 0;

        while (opModeIsActive() && timer.seconds() < KV_SETTLE_S + KV_SAMPLE_S)
        {
            double velocity = shooter.getVelocityTicksPerSec();
            if (timer.seconds() >= KV_SETTLE_S)
            {
                sum += velocity;
                count++;
            }
            telemetry.addData("Finding kV", "step %d of %d at power %.2f", index + 1, KV_POWERS.length, power);
            telemetry.addData("Velocity", "%.0f ticks/s", velocity);
            telemetry.update();
        }

        if (count == 0)
        {
            return 0.0;
        }
        return sum / count;
    }

    private void showResults()
    {
        telemetry.addData("Battery", "%.2f V", hardwareMap.voltageSensor.iterator().next().getVoltage());
        telemetry.addData("kS (power that just moves it)", "%.5f", kS);
        for (int i = 0; i < KV_POWERS.length; i++)
        {
            telemetry.addData(String.format("Power %.2f", KV_POWERS[i]), "%.0f ticks/s", measured[i]);
        }
        if (kvDone)
        {
            telemetry.addData("kV (power per tick/s)", "%.7f", kV);
            telemetry.addData("MAX_TICKS_PER_SEC", "%.0f", maxTicksPerSec);
            telemetry.addData("Top speed", "%.0f RPM", maxTicksPerSec / Shooter.TICKS_PER_REV * 60.0);
            telemetry.addLine("Copy kS into FEEDFORWARD_KS and MAX_TICKS_PER_SEC into Shooter.java.");
            telemetry.addLine("Then run Shooter kP kD Tuner.");
        }
        if (!message.isEmpty())
        {
            telemetry.addLine(message);
        }
        telemetry.update();
    }
}
