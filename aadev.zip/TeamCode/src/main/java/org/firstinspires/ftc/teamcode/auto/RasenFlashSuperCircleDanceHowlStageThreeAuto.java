package org.firstinspires.ftc.teamcode.auto;

import static com.pedropathing.api.Paths.line;
import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.pedropathing.follower.Follower;
import com.pedropathing.ivy.Command;
import com.pedropathing.ivy.Scheduler;
import com.pedropathing.math.Pose;
import com.pedropathing.paths.Path;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.config.DriveConfig;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;
import org.firstinspires.ftc.teamcode.pedro.Constants;
import org.firstinspires.ftc.teamcode.util.BulkReads;
import org.firstinspires.ftc.teamcode.util.MatchHandoff;

@Autonomous(name = "Rasen Flash Super Circle Dance Howl Stage Three", group = "Autonomous")
public class RasenFlashSuperCircleDanceHowlStageThreeAuto extends OpMode
{
    private static final String AUTO_NAME = "Rasen Flash Super Circle Dance Howl Stage Three";

    private static final double PARK_FORWARD_IN = 10.0;

    private static final double PATH_TIMEOUT_S = 6.0;

    private static final double DRIVE_POWER = 0.4;
    private static final double CLEAR_WALL_S = 0.3;

    private DcMotor frontLeft, backLeft, frontRight, backRight;
    private Follower follower;
    private Sweeper sweeper;

    private Command root;
    private boolean following = false;
    private boolean stopped = false;
    private String status = "Waiting for start";

    @Override
    public void init()
    {
        Scheduler.reset();
        BulkReads.enable(hardwareMap);

        frontLeft  = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_LEFT);
        backLeft   = hardwareMap.get(DcMotor.class, HardwareNames.BACK_LEFT);
        frontRight = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_RIGHT);
        backRight  = hardwareMap.get(DcMotor.class, HardwareNames.BACK_RIGHT);
        DriveConfig.apply(frontLeft, backLeft, frontRight, backRight);

        try
        {
            sweeper = new Sweeper(hardwareMap);
        }
        catch (Exception e)
        {
            sweeper = null;
        }

        try
        {
            follower = Constants.create(hardwareMap);
        }
        catch (Exception e)
        {
            follower = null;
        }
    }

    @Override
    public void init_loop()
    {
        BulkReads.clear();
        telemetry.addLine(AUTO_NAME);
        telemetry.update();
    }

    @Override
    public void start()
    {
        Scheduler.reset();
        MatchHandoff.clear();
        if (sweeper != null)
        {
            sweeper.start();
        }

        if (follower != null)
        {
            Pose start = new Pose(0.0, 0.0, 0.0);
            follower.setPose(start);
            follower.update();
            root = odometryPlan(start, new Pose(PARK_FORWARD_IN, 0.0, 0.0));
        }
        else
        {
            root = timedPlan();
        }

        Scheduler.schedule(root);
    }

    @Override
    public void loop()
    {
        BulkReads.clear();
        if (follower != null && following)
        {
            follower.update();
        }
        Scheduler.execute();

        if (!Scheduler.isScheduled(root))
        {
            if (!stopped)
            {
                stopped = true;
                stopDrive();
            }
            status = follower != null ? "Done - motors stopped" : "Done - holding still";
        }

        telemetry.addData("Status", status);
        telemetry.update();
    }

    @Override
    public void stop()
    {
        Scheduler.reset();
        stopDrive();
    }

    private Command odometryPlan(Pose start, Pose park)
    {
        return sequential(
                instant(() -> status = "Drive forward to park"),
                followPath(start, park).raceWith(waitMs(PATH_TIMEOUT_S * 1000.0)));
    }

    private Command timedPlan()
    {
        return sequential(
                instant(() ->
                {
                    status = "No odometry - leaving the wall only";
                    setDrivePower(DRIVE_POWER);
                }),
                waitMs(CLEAR_WALL_S * 1000.0),
                instant(this::stopDrive));
    }

    private Command followPath(Pose from, Pose to)
    {
        return Command.build()
                .setStart(() ->
                {
                    Path path = line(from, to).heading((curve, t) -> 0.0);
                    following = true;
                    follower.follow(path);
                })
                .setDone(() -> follower.atParametricEnd())
                .setEnd(condition ->
                {
                    following = false;
                    stopDrive();
                });
    }

    private void setDrivePower(double power)
    {
        frontLeft.setPower(power);
        frontRight.setPower(power);
        backLeft.setPower(power);
        backRight.setPower(power);
    }

    private void stopDrive()
    {
        setDrivePower(0.0);
    }
}
