package org.firstinspires.ftc.teamcode.util;

public class MatchHandoff
{
    public static final double MAX_AGE_S = 120.0;
    public static final double RED_DRIVER_FORWARD_HEADING = Math.PI / 2.0;
    public static final double BLUE_DRIVER_FORWARD_HEADING = 3.0 * Math.PI / 2.0;

    private static boolean saved = false;
    private static long savedAtMs = 0L;
    private static double x = 0.0;
    private static double y = 0.0;
    private static double heading = 0.0;
    private static boolean blue = false;

    public static void save(double xIn, double yIn, double headingRad, boolean isBlue)
    {
        x = xIn;
        y = yIn;
        heading = headingRad;
        blue = isBlue;
        savedAtMs = System.currentTimeMillis();
        saved = true;
    }

    public static void clear()
    {
        saved = false;
    }

    public static boolean isFresh()
    {
        return saved && getAgeS() <= MAX_AGE_S;
    }

    public static double getAgeS()
    {
        return (System.currentTimeMillis() - savedAtMs) / 1000.0;
    }

    public static double getX()
    {
        return x;
    }

    public static double getY()
    {
        return y;
    }

    public static double getHeading()
    {
        return heading;
    }

    public static boolean isBlue()
    {
        return blue;
    }

    public static double driverForwardHeading(boolean isBlue)
    {
        if (isBlue)
        {
            return BLUE_DRIVER_FORWARD_HEADING;
        }
        return RED_DRIVER_FORWARD_HEADING;
    }

    public static double normalize(double angleRad)
    {
        return Math.atan2(Math.sin(angleRad), Math.cos(angleRad));
    }
}
