package org.firstinspires.ftc.teamcode.auto;

import static com.pedropathing.ivy.commands.Commands.instant;
import static com.pedropathing.ivy.commands.Commands.waitMs;
import static com.pedropathing.ivy.commands.Commands.waitUntil;
import static com.pedropathing.ivy.groups.Groups.sequential;

import com.pedropathing.ivy.Command;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.DriveConfig;
import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.intake.Intake;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Gate;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.Shooter;
import org.firstinspires.ftc.teamcode.mechanisms.shooter.ShootingCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.FlowerCycle;
import org.firstinspires.ftc.teamcode.mechanisms.sweeper.Sweeper;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;
import org.firstinspires.ftc.teamcode.util.MecanumWheelPowers;

public class AutoCommands
{
    public static final double LAUNCH_SPINUP_S = ShootingCycle.SPINUP_S;
    public static final double LAUNCH_FEED_S = ShootingCycle.FEED_S;

    private final DcMotor frontLeft;
    private final DcMotor backLeft;
    private final DcMotor frontRight;
    private final DcMotor backRight;

    public Shooter shooter;
    public Intake intake;
    public Gate gate;
    public TurretTracker turret;
    public Sweeper sweeper;
    public ShootingCycle cycle;
    public FlowerCycle flowerCycle;

    private final ElapsedTime revTimer = new ElapsedTime();
    private boolean revving = false;
    private boolean turretActive = false;
    private boolean sweeperActive = false;

    public AutoCommands(HardwareMap hardwareMap)
    {
        frontLeft  = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_LEFT);
        backLeft   = hardwareMap.get(DcMotor.class, HardwareNames.BACK_LEFT);
        frontRight = hardwareMap.get(DcMotor.class, HardwareNames.FRONT_RIGHT);
        backRight  = hardwareMap.get(DcMotor.class, HardwareNames.BACK_RIGHT);
        DriveConfig.apply(frontLeft, backLeft, frontRight, backRight);

        try
        {
            shooter = new Shooter(hardwareMap);
            intake = new Intake(hardwareMap);
        }
        catch (Exception e)
        {
            shooter = null;
            intake = null;
        }

        try
        {
            gate = new Gate(hardwareMap);
        }
        catch (Exception e)
        {
            gate = null;
        }

        cycle = null;
        if (shooter != null && intake != null)
        {
            cycle = new ShootingCycle(shooter, intake, gate);
        }

        try
        {
            turret = new TurretTracker(hardwareMap);
        }
        catch (Exception e)
        {
            turret = null;
        }

        if (cycle != null)
        {
            cycle.setTurret(turret);
        }

        try
        {
            sweeper = new Sweeper(hardwareMap);
        }
        catch (Exception e)
        {
            sweeper = null;
        }

        flowerCycle = null;
        if (sweeper != null && intake != null)
        {
            flowerCycle = new FlowerCycle(sweeper, intake);
        }
    }

    public boolean hasSweeper()
    {
        return sweeper != null;
    }

    public void startSweeper()
    {
        if (sweeper != null)
        {
            sweeper.start();
            sweeperActive = true;
        }
    }

    public Command sweeperDown()
    {
        return sequential(
                instant(() ->
                {
                    if (sweeper != null)
                    {
                        sweeper.deploy();
                    }
                }),
                waitUntil(() -> sweeper == null || !sweeperActive || !sweeper.isMoving()));
    }

    public Command sweeperLower()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.deploy();
            }
        });
    }

    public Command collectFlower()
    {
        if (flowerCycle == null)
        {
            return waitMs(FlowerCycle.COLLECT_S * 1000.0);
        }
        return sequential(
                instant(() -> flowerCycle.start(false)),
                waitUntil(() -> flowerCycle.isDone()));
    }

    public Command shooterOff()
    {
        return instant(() ->
        {
            revving = false;
            if (shooter != null)
            {
                shooter.stopShooter();
            }
        });
    }

    public Command sweeperUp()
    {
        return instant(() ->
        {
            if (sweeper != null)
            {
                sweeper.stow();
            }
        });
    }

    public boolean hasTurret()
    {
        return turret != null;
    }

    public void setAlliance(boolean blue)
    {
        if (turret != null)
        {
            turret.setAlliance(blue);
        }
    }

    public void startTurret()
    {
        if (turret != null)
        {
            turret.start();
            turretActive = true;
        }
    }

    public boolean canLaunch()
    {
        return shooter != null && intake != null;
    }

    public void update()
    {
        if (shooter != null)
        {
            shooter.update();
        }
        if (intake != null)
        {
            intake.update();
        }
        if (cycle != null)
        {
            cycle.update();
        }
        if (flowerCycle != null)
        {
            flowerCycle.update();
        }
        if (turret != null && turretActive)
        {
            turret.track();
        }
        if (sweeper != null && sweeperActive)
        {
            sweeper.update();
        }
    }

    public void stopAll()
    {
        stopDrive();
        revving = false;
        if (cycle != null)
        {
            cycle.cancel();
        }
        if (flowerCycle != null)
        {
            flowerCycle.cancel();
        }
        if (shooter != null)
        {
            shooter.stopAll();
        }
        if (intake != null)
        {
            intake.stop();
        }
        if (gate != null)
        {
            gate.close();
        }
        if (turret != null && turretActive)
        {
            turretActive = false;
            turret.stop();
        }
        if (sweeper != null && sweeperActive)
        {
            sweeper.stow();
        }
    }

    public void setDrive(double axial, double lateral, double yaw)
    {
        double[] power = MecanumWheelPowers.calculate(axial, lateral, yaw);

        frontLeft.setPower(power[0]);
        frontRight.setPower(power[1]);
        backLeft.setPower(power[2]);
        backRight.setPower(power[3]);
    }

    public void stopDrive()
    {
        frontLeft.setPower(0);
        frontRight.setPower(0);
        backLeft.setPower(0);
        backRight.setPower(0);
    }

    public Command nothing()
    {
        return instant(() ->
        {
        });
    }

    public Command rev()
    {
        return instant(this::startRev);
    }

    public Command intakeOn()
    {
        return instant(() ->
        {
            if (intake != null)
            {
                intake.in();
            }
        });
    }

    public Command intakeOff()
    {
        return instant(() ->
        {
            if (intake != null)
            {
                intake.stop();
            }
        });
    }

    public Command driveFor(double axial, double lateral, double seconds)
    {
        return sequential(
                instant(() -> setDrive(axial, lateral, 0.0)),
                waitMs(seconds * 1000.0),
                instant(this::stopDrive));
    }

    public Command launch()
    {
        return sequential(
                instant(() ->
                {
                    double spinningS = 0.0;
                    if (revving)
                    {
                        spinningS = revTimer.seconds();
                    }
                    revving = false;
                    cycle.start(spinningS);
                }),
                waitUntil(() -> cycle.isDone()));
    }

    private void startRev()
    {
        if (!revving && shooter != null)
        {
            shooter.shoot();
            revTimer.reset();
            revving = true;
        }
    }
}
