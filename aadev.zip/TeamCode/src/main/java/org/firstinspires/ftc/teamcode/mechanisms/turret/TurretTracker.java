package org.firstinspires.ftc.teamcode.mechanisms.turret;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.config.HardwareNames;

import java.util.List;

public class TurretTracker
{
    public enum State
    {
        MANUAL,
        TRACKING,
        SEARCHING,
        NO_TAG
    }

    public static final int APRIL_TAG_PIPELINE = 0;

    public static final DcMotorSimple.Direction LEFT_SERVO_DIRECTION = DcMotorSimple.Direction.FORWARD;
    public static final DcMotorSimple.Direction RIGHT_SERVO_DIRECTION = DcMotorSimple.Direction.FORWARD;

    public static final int[] RED_TAG_IDS = {};
    public static final int[] BLUE_TAG_IDS = {};
    public static final double MAX_STALENESS_MS = 150.0;
    public static final double AIM_OFFSET_DEG = 0.0;

    private static final double DERIVATIVE_MIN_DT_S = 0.02;

    public static final double SEARCH_POWER = 0.15;
    public static final double SEARCH_MAX_S = 1.5;
    public static final double SEARCH_MIN_ERROR_DEG = 2.0;

    public static final double LOCK_TOLERANCE_DEG = 1.5;

    public double kP = 0.015;
    public double kD = 0.0008;
    public double minPower = 0.04;
    public double maxPower = 0.4;
    public double deadbandDeg = 0.4;
    public boolean invert = false;

    private final CRServo leftServo;
    private final CRServo rightServo;
    private Limelight3A limelight;

    private final ElapsedTime derivativeTimer = new ElapsedTime();
    private final ElapsedTime lostTimer = new ElapsedTime();
    private int[] allowedIds = new int[0];
    private State state = State.NO_TAG;
    private boolean hadTargetLastLoop = false;
    private double lastSide = 0.0;
    private boolean hasLastError = false;
    private double lastError = 0.0;
    private double derivative = 0.0;

    private boolean hasTarget = false;
    private int targetId = -1;
    private double error = 0.0;
    private double commandedPower = 0.0;

    public TurretTracker(HardwareMap hardwareMap)
    {
        leftServo = hardwareMap.get(CRServo.class, HardwareNames.TURRET_LEFT);
        rightServo = hardwareMap.get(CRServo.class, HardwareNames.TURRET_RIGHT);
        leftServo.setDirection(LEFT_SERVO_DIRECTION);
        rightServo.setDirection(RIGHT_SERVO_DIRECTION);

        limelight = null;
        try
        {
            limelight = hardwareMap.get(Limelight3A.class, HardwareNames.LIMELIGHT);
            limelight.setPollRateHz(100);
            limelight.pipelineSwitch(APRIL_TAG_PIPELINE);
        }
        catch (Exception e)
        {
            limelight = null;
        }
    }

    public boolean hasLimelight()
    {
        return limelight != null;
    }

    public void start()
    {
        if (limelight != null)
        {
            limelight.start();
        }
        state = State.NO_TAG;
        hadTargetLastLoop = false;
        lastSide = 0.0;
    }

    public void stop()
    {
        setPower(0.0);
        if (limelight != null)
        {
            limelight.stop();
        }
        state = State.NO_TAG;
    }

    public State getState()
    {
        return state;
    }

    public void setAlliance(boolean blue)
    {
        if (blue)
        {
            allowedIds = BLUE_TAG_IDS;
        }
        else
        {
            allowedIds = RED_TAG_IDS;
        }
    }

    public void clearAlliance()
    {
        allowedIds = new int[0];
    }

    public boolean isAiming()
    {
        return state == State.TRACKING || state == State.SEARCHING;
    }

    public boolean isLockedOn()
    {
        return state == State.TRACKING && Math.abs(error) <= LOCK_TOLERANCE_DEG;
    }

    public void manual(double power)
    {
        state = State.MANUAL;
        hadTargetLastLoop = false;
        lastSide = 0.0;
        hasLastError = false;
        setPower(power);
    }

    public boolean hasTarget()
    {
        return hasTarget;
    }

    public int getTargetId()
    {
        return targetId;
    }

    public double getError()
    {
        return error;
    }

    public double getCommandedPower()
    {
        return commandedPower;
    }

    public void setPower(double power)
    {
        commandedPower = power;
        double output = invert ? -power : power;
        leftServo.setPower(output);
        rightServo.setPower(output);
    }

    public void track()
    {
        hasTarget = false;
        targetId = -1;

        LLResult result = null;
        if (limelight != null)
        {
            result = limelight.getLatestResult();
        }
        if (result != null && result.isValid() && result.getStaleness() < MAX_STALENESS_MS)
        {
            List<LLResultTypes.FiducialResult> tags = result.getFiducialResults();
            double best = 0.0;
            for (LLResultTypes.FiducialResult tag : tags)
            {
                if (!isAllowed(tag.getFiducialId()))
                {
                    continue;
                }
                double tagError = tag.getTargetXDegrees() - AIM_OFFSET_DEG;
                if (!hasTarget || Math.abs(tagError) < Math.abs(best))
                {
                    hasTarget = true;
                    best = tagError;
                    targetId = tag.getFiducialId();
                }
            }
            error = best;
        }

        if (!hasTarget)
        {
            hasLastError = false;
            derivative = 0.0;
            if (hadTargetLastLoop)
            {
                hadTargetLastLoop = false;
                lostTimer.reset();
            }
            if (lastSide != 0.0 && lostTimer.seconds() < SEARCH_MAX_S)
            {
                state = State.SEARCHING;
                setPower(lastSide * SEARCH_POWER);
            }
            else
            {
                state = State.NO_TAG;
                setPower(0.0);
            }
            return;
        }

        state = State.TRACKING;
        hadTargetLastLoop = true;
        if (Math.abs(error) >= SEARCH_MIN_ERROR_DEG)
        {
            lastSide = Math.signum(error);
        }

        if (!hasLastError)
        {
            hasLastError = true;
            lastError = error;
            derivative = 0.0;
            derivativeTimer.reset();
        }
        else if (derivativeTimer.seconds() >= DERIVATIVE_MIN_DT_S)
        {
            derivative = (error - lastError) / derivativeTimer.seconds();
            lastError = error;
            derivativeTimer.reset();
        }

        if (Math.abs(error) <= deadbandDeg)
        {
            setPower(0.0);
            return;
        }

        double power = kP * error + kD * derivative;
        power = Math.max(-maxPower, Math.min(maxPower, power));
        if (Math.abs(power) < minPower)
        {
            power = Math.signum(error) * minPower;
        }
        setPower(power);
    }

    private boolean isAllowed(int id)
    {
        if (allowedIds.length == 0)
        {
            return true;
        }
        for (int allowed : allowedIds)
        {
            if (allowed == id)
            {
                return true;
            }
        }
        return false;
    }
}
