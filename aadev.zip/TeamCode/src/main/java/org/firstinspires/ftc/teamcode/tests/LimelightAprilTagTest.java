package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.config.HardwareNames;
import org.firstinspires.ftc.teamcode.mechanisms.turret.TurretTracker;

import java.util.List;

@TeleOp(name = "Limelight AprilTag Test", group = "Test")
public class LimelightAprilTagTest extends LinearOpMode
{
    private static final double CAMERA_HEIGHT_IN = 0.0;
    private static final double CAMERA_TILT_UP_DEG = 0.0;
    private static final double TAG_HEIGHT_IN = 0.0;
    private static final int POLL_RATE_HZ = 100;

    @Override
    public void runOpMode()
    {
        Limelight3A limelight;
        try
        {
            limelight = hardwareMap.get(Limelight3A.class, HardwareNames.LIMELIGHT);
        }
        catch (Exception e)
        {
            telemetry.addData("Limelight", "not found in the hardware config (name: limelight)");
            telemetry.update();
            waitForStart();
            return;
        }

        limelight.setPollRateHz(POLL_RATE_HZ);
        limelight.pipelineSwitch(TurretTracker.APRIL_TAG_PIPELINE);

        boolean distanceReady = CAMERA_HEIGHT_IN > 0.0 && TAG_HEIGHT_IN > 0.0;

        telemetry.addLine("Limelight AprilTag Test - point the camera at a tag");
        telemetry.addLine("Pipeline 0 must be the AprilTag pipeline in the Limelight web page.");
        if (!distanceReady)
        {
            telemetry.addLine("Distance is off. Fill in CAMERA_HEIGHT_IN, CAMERA_TILT_UP_DEG, TAG_HEIGHT_IN.");
        }
        telemetry.update();

        waitForStart();
        limelight.start();

        while (opModeIsActive())
        {
            LLResult result = limelight.getLatestResult();
            if (result == null || !result.isValid())
            {
                telemetry.addData("Status", "no AprilTag seen");
                telemetry.update();
                continue;
            }

            List<LLResultTypes.FiducialResult> tags = result.getFiducialResults();
            telemetry.addData("Status", "%d tag(s) seen", tags.size());
            telemetry.addData("Staleness", "%s ms", result.getStaleness());
            telemetry.addData("tx / ty / ta", "%.2f / %.2f / %.3f", result.getTx(), result.getTy(), result.getTa());

            for (LLResultTypes.FiducialResult tag : tags)
            {
                String line = String.format("%.1f deg left/right, %.1f deg up/down",
                        tag.getTargetXDegrees(), tag.getTargetYDegrees());
                if (distanceReady)
                {
                    double angle = Math.toRadians(CAMERA_TILT_UP_DEG + tag.getTargetYDegrees());
                    if (angle > 0.0)
                    {
                        line += String.format(", about %.1f in away", (TAG_HEIGHT_IN - CAMERA_HEIGHT_IN) / Math.tan(angle));
                    }
                }
                telemetry.addData("Tag " + tag.getFiducialId(), line);
            }

            telemetry.update();
        }

        limelight.stop();
    }
}
