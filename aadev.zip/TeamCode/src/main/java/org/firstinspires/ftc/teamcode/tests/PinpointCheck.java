package org.firstinspires.ftc.teamcode.tests;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver.EncoderDirection;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@TeleOp(name = "Pinpoint Check", group = "Test")
public class PinpointCheck extends LinearOpMode
{
    @Override
    public void runOpMode()
    {
        GoBildaPinpointDriver pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");
        pinpoint.setEncoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        EncoderDirection xDir = EncoderDirection.REVERSED;
        EncoderDirection yDir = EncoderDirection.FORWARD;
        pinpoint.setEncoderDirections(xDir, yDir);
        pinpoint.resetPosAndIMU();

        telemetry.addLine("Hold the robot still, then press START.");
        telemetry.update();
        waitForStart();

        boolean lastA = false, lastB = false, lastX = false;
        while (opModeIsActive())
        {
            if (gamepad1.a && !lastA) pinpoint.resetPosAndIMU();
            if (gamepad1.b && !lastB)
            {
                yDir = (yDir == EncoderDirection.FORWARD) ? EncoderDirection.REVERSED : EncoderDirection.FORWARD;
                pinpoint.setEncoderDirections(xDir, yDir);
            }
            if (gamepad1.x && !lastX)
            {
                xDir = (xDir == EncoderDirection.FORWARD) ? EncoderDirection.REVERSED : EncoderDirection.FORWARD;
                pinpoint.setEncoderDirections(xDir, yDir);
            }
            lastA = gamepad1.a; lastB = gamepad1.b; lastX = gamepad1.x;

            pinpoint.update();
            telemetry.addData("X (in)  forward = up", "%.2f", pinpoint.getPosX(DistanceUnit.INCH));
            telemetry.addData("Y (in)  left = up", "%.2f", pinpoint.getPosY(DistanceUnit.INCH));
            telemetry.addData("Heading (deg)  CCW = up", "%.1f", pinpoint.getHeading(AngleUnit.DEGREES));
            telemetry.addData("Raw X pod ticks", pinpoint.getEncoderX());
            telemetry.addData("Raw Y pod ticks", pinpoint.getEncoderY());
            telemetry.addData("X dir / Y dir", xDir + " / " + yDir);
            telemetry.addLine("A=zero  B=flip Y dir  X=flip X dir");
            telemetry.update();
        }
    }
}
