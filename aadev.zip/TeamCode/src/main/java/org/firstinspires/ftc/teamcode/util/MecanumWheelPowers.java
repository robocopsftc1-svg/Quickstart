package org.firstinspires.ftc.teamcode.util;

public class MecanumWheelPowers
{
    // front left - front right - back left - back right
    public static final double[] FORWARD      = { 1.0,  1.0,  1.0,  1.0};
    public static final double[] BACKWARD     = {-1.0, -1.0, -1.0, -1.0};
    public static final double[] SLIDE_RIGHT  = { 1.0, -1.0, -1.0,  1.0};
    public static final double[] SLIDE_LEFT   = {-1.0,  1.0,  1.0, -1.0};
    public static final double[] TURN_RIGHT   = { 1.0, -1.0,  1.0, -1.0};
    public static final double[] TURN_LEFT    = {-1.0,  1.0, -1.0,  1.0};

    public static double[] calculate(double axial, double lateral, double yaw)
    {
        double[] turn = yaw >= 0.0 ? TURN_RIGHT : TURN_LEFT;
        double[] power = new double[4];
        for (int i = 0; i < 4; i++)
        {
            power[i] = axial * FORWARD[i] + lateral * SLIDE_RIGHT[i] + Math.abs(yaw) * turn[i];
        }
        return normalize(power);
    }

    private static double[] normalize(double[] power)
    {
        double max = 0.0;
        for (int i = 0; i < 4; i++)
        {
            max = Math.max(max, Math.abs(power[i]));
        }
        if (max > 1.0)
        {
            for (int i = 0; i < 4; i++)
            {
                power[i] /= max;
            }
        }
        return power;
    }

    public static double[] forward(double speed)    { return calculate(speed, 0.0, 0.0); }
    public static double[] backward(double speed)   { return calculate(-speed, 0.0, 0.0); }
    public static double[] slideRight(double speed) { return calculate(0.0, speed, 0.0); }
    public static double[] slideLeft(double speed)  { return calculate(0.0, -speed, 0.0); }
    public static double[] turnRight(double speed)  { return calculate(0.0, 0.0, speed); }
    public static double[] turnLeft(double speed)   { return calculate(0.0, 0.0, -speed); }
}
